import { db } from '@/lib/db'
import { Transaction, Rule } from '@prisma/client'

export interface RuleCondition {
  field: 'description' | 'amount' | 'type' | 'date'
  operator: 'contains' | 'equals' | 'startsWith' | 'endsWith' | 'greaterThan' | 'lessThan' | 'between'
  value: string | number | [number, number]
  caseSensitive?: boolean
}

export interface RuleAction {
  type: 'categorize' | 'addTag' | 'setNote' | 'skip'
  categoryId?: string
  categoryName?: string
  subcategory?: string
  tags?: string[]
  note?: string
}

export class RuleProcessor {
  static async processTransaction(transaction: Transaction): Promise<Transaction> {
    // Get all active rules for the user, ordered by priority
    const rules = await db.rule.findMany({
      where: {
        userId: transaction.userId,
        isActive: true
      },
      include: {
        category: true
      },
      orderBy: {
        priority: 'desc'
      }
    })

    let updatedTransaction = { ...transaction }

    // Apply rules in order of priority
    for (const rule of rules) {
      try {
        const condition = JSON.parse(rule.condition) as RuleCondition
        const action = JSON.parse(rule.action) as RuleAction

        if (this.evaluateCondition(updatedTransaction, condition)) {
          updatedTransaction = await this.applyAction(updatedTransaction, action, rule)
          
          // If action is 'skip', stop processing further rules
          if (action.type === 'skip') {
            break
          }
        }
      } catch (error) {
        console.error(`Error processing rule ${rule.id}:`, error)
        continue
      }
    }

    return updatedTransaction
  }

  static async processTransactions(transactions: Transaction[]): Promise<Transaction[]> {
    const processedTransactions = []

    for (const transaction of transactions) {
      const processed = await this.processTransaction(transaction)
      processedTransactions.push(processed)
    }

    return processedTransactions
  }

  private static evaluateCondition(transaction: Transaction, condition: RuleCondition): boolean {
    const { field, operator, value, caseSensitive = false } = condition

    let fieldValue: any
    switch (field) {
      case 'description':
        fieldValue = transaction.description
        break
      case 'amount':
        fieldValue = transaction.amount
        break
      case 'type':
        fieldValue = transaction.type
        break
      case 'date':
        fieldValue = transaction.date
        break
      default:
        return false
    }

    // Apply case sensitivity for string fields
    if (typeof fieldValue === 'string' && typeof value === 'string' && !caseSensitive) {
      fieldValue = fieldValue.toLowerCase()
      const conditionValue = value.toLowerCase()
      return this.evaluateOperator(fieldValue, operator, conditionValue)
    }

    return this.evaluateOperator(fieldValue, operator, value)
  }

  private static evaluateOperator(fieldValue: any, operator: string, conditionValue: any): boolean {
    switch (operator) {
      case 'contains':
        return typeof fieldValue === 'string' && fieldValue.includes(conditionValue)
      case 'equals':
        return fieldValue === conditionValue
      case 'startsWith':
        return typeof fieldValue === 'string' && fieldValue.startsWith(conditionValue)
      case 'endsWith':
        return typeof fieldValue === 'string' && fieldValue.endsWith(conditionValue)
      case 'greaterThan':
        return typeof fieldValue === 'number' && fieldValue > conditionValue
      case 'lessThan':
        return typeof fieldValue === 'number' && fieldValue < conditionValue
      case 'between':
        return Array.isArray(conditionValue) && 
               typeof fieldValue === 'number' && 
               fieldValue >= conditionValue[0] && 
               fieldValue <= conditionValue[1]
      default:
        return false
    }
  }

  private static async applyAction(
    transaction: Transaction, 
    action: RuleAction, 
    rule: Rule
  ): Promise<Transaction> {
    switch (action.type) {
      case 'categorize':
        return await this.categorizeTransaction(transaction, action, rule)
      case 'addTag':
        return await this.addTagsToTransaction(transaction, action)
      case 'setNote':
        return await this.setNoteOnTransaction(transaction, action)
      case 'skip':
        return transaction
      default:
        return transaction
    }
  }

  private static async categorizeTransaction(
    transaction: Transaction, 
    action: RuleAction, 
    rule: Rule
  ): Promise<Transaction> {
    let categoryId = action.categoryId

    // If categoryName is provided, find or create the category
    if (action.categoryName && !categoryId) {
      const category = await this.findOrCreateCategory(transaction.userId, action.categoryName)
      categoryId = category.id
    }

    // Update transaction with category
    const updated = await db.transaction.update({
      where: { id: transaction.id },
      data: {
        categoryId,
        subcategory: action.subcategory,
        metadata: JSON.stringify({
          ...JSON.parse(transaction.metadata || '{}'),
          ruleApplied: rule.id,
          ruleName: rule.name
        })
      }
    })

    return updated
  }

  private static async addTagsToTransaction(
    transaction: Transaction, 
    action: RuleAction
  ): Promise<Transaction> {
    if (!action.tags || action.tags.length === 0) {
      return transaction
    }

    const existingMetadata = JSON.parse(transaction.metadata || '{}')
    const existingTags = existingMetadata.tags || []
    const newTags = [...new Set([...existingTags, ...action.tags])]

    const updated = await db.transaction.update({
      where: { id: transaction.id },
      data: {
        metadata: JSON.stringify({
          ...existingMetadata,
          tags: newTags
        })
      }
    })

    return updated
  }

  private static async setNoteOnTransaction(
    transaction: Transaction, 
    action: RuleAction
  ): Promise<Transaction> {
    if (!action.note) {
      return transaction
    }

    const existingMetadata = JSON.parse(transaction.metadata || '{}')

    const updated = await db.transaction.update({
      where: { id: transaction.id },
      data: {
        metadata: JSON.stringify({
          ...existingMetadata,
          note: action.note
        })
      }
    })

    return updated
  }

  private static async findOrCreateCategory(userId: string, categoryName: string) {
    let category = await db.category.findFirst({
      where: {
        userId,
        name: categoryName
      }
    })

    if (!category) {
      category = await db.category.create({
        data: {
          name: categoryName,
          userId,
          type: 'expense', // Default to expense, can be overridden
          color: '#' + Math.floor(Math.random()*16777215).toString(16)
        }
      })
    }

    return category
  }

  static async createRule(data: {
    name: string
    condition: RuleCondition
    action: RuleAction
    priority?: number
    userId: string
    categoryId?: string
  }): Promise<Rule> {
    return await db.rule.create({
      data: {
        name: data.name,
        condition: JSON.stringify(data.condition),
        action: JSON.stringify(data.action),
        priority: data.priority || 0,
        isActive: true,
        userId: data.userId,
        categoryId: data.categoryId
      }
    })
  }

  static validateRule(condition: RuleCondition, action: RuleAction): { valid: boolean; errors: string[] } {
    const errors: string[] = []

    // Validate condition
    if (!condition.field || !['description', 'amount', 'type', 'date'].includes(condition.field)) {
      errors.push('Invalid condition field')
    }

    if (!condition.operator || !['contains', 'equals', 'startsWith', 'endsWith', 'greaterThan', 'lessThan', 'between'].includes(condition.operator)) {
      errors.push('Invalid condition operator')
    }

    if (condition.value === undefined || condition.value === null) {
      errors.push('Condition value is required')
    }

    // Validate action
    if (!action.type || !['categorize', 'addTag', 'setNote', 'skip'].includes(action.type)) {
      errors.push('Invalid action type')
    }

    if (action.type === 'categorize' && !action.categoryId && !action.categoryName) {
      errors.push('Category ID or name is required for categorize action')
    }

    if (action.type === 'addTag' && (!action.tags || action.tags.length === 0)) {
      errors.push('Tags are required for addTag action')
    }

    if (action.type === 'setNote' && !action.note) {
      errors.push('Note is required for setNote action')
    }

    return {
      valid: errors.length === 0,
      errors
    }
  }
}