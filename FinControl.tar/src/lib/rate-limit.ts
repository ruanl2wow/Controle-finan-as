import { NextRequest } from 'next/server'
import { useState, useCallback } from 'react'

interface RateLimitEntry {
  count: number
  resetTime: number
}

class RateLimiter {
  private store = new Map<string, RateLimitEntry>()
  private readonly windowMs: number
  private readonly maxRequests: number

  constructor(windowMs: number, maxRequests: number) {
    this.windowMs = windowMs
    this.maxRequests = maxRequests
    
    // Clean up expired entries every minute
    setInterval(() => this.cleanup(), 60000)
  }

  private cleanup(): void {
    const now = Date.now()
    for (const [key, entry] of this.store.entries()) {
      if (now > entry.resetTime) {
        this.store.delete(key)
      }
    }
  }

  private getKey(identifier: string): string {
    return identifier
  }

  isAllowed(identifier: string): { allowed: boolean; resetTime: number; remaining: number } {
    const key = this.getKey(identifier)
    const now = Date.now()
    const entry = this.store.get(key)

    if (!entry || now > entry.resetTime) {
      // New window
      const newEntry: RateLimitEntry = {
        count: 1,
        resetTime: now + this.windowMs
      }
      this.store.set(key, newEntry)
      return {
        allowed: true,
        resetTime: newEntry.resetTime,
        remaining: this.maxRequests - 1
      }
    }

    // Existing window
    if (entry.count >= this.maxRequests) {
      return {
        allowed: false,
        resetTime: entry.resetTime,
        remaining: 0
      }
    }

    entry.count++
    return {
      allowed: true,
      resetTime: entry.resetTime,
      remaining: this.maxRequests - entry.count
    }
  }

  reset(identifier: string): void {
    this.store.delete(this.getKey(identifier))
  }

  getStats(): { size: number; entries: Array<{ key: string; count: number; resetTime: number }> } {
    const entries = Array.from(this.store.entries()).map(([key, entry]) => ({
      key,
      count: entry.count,
      resetTime: entry.resetTime
    }))
    return {
      size: this.store.size,
      entries
    }
  }
}

// Predefined rate limiters for different use cases
export const authLimiter = new RateLimiter(15 * 60 * 1000, 5) // 5 requests per 15 minutes
export const apiLimiter = new RateLimiter(60 * 1000, 100) // 100 requests per minute
export const uploadLimiter = new RateLimiter(60 * 1000, 10) // 10 uploads per minute
export const exportLimiter = new RateLimiter(60 * 1000, 5) // 5 exports per minute

// Helper functions
export function getClientIdentifier(request: NextRequest): string {
  // Try to get user ID from session first
  const forwarded = request.headers.get('x-forwarded-for')
  const ip = forwarded ? forwarded.split(',')[0] : request.ip || 'unknown'
  
  // Add user agent for better identification
  const userAgent = request.headers.get('user-agent') || 'unknown'
  
  return `${ip}:${userAgent}`
}

export function createRateLimitResponse(
  resetTime: number,
  limit: number,
  windowMs: number
): Response {
  const retryAfter = Math.ceil((resetTime - Date.now()) / 1000)
  
  return new Response(
    JSON.stringify({
      error: 'Too Many Requests',
      message: `Rate limit exceeded. Try again in ${retryAfter} seconds.`,
      retryAfter
    }),
    {
      status: 429,
      headers: {
        'Content-Type': 'application/json',
        'X-RateLimit-Limit': limit.toString(),
        'X-RateLimit-Remaining': '0',
        'X-RateLimit-Reset': resetTime.toString(),
        'Retry-After': retryAfter.toString()
      }
    }
  )
}

export function addRateLimitHeaders(
  response: Response,
  remaining: number,
  limit: number,
  resetTime: number
): Response {
  response.headers.set('X-RateLimit-Limit', limit.toString())
  response.headers.set('X-RateLimit-Remaining', remaining.toString())
  response.headers.set('X-RateLimit-Reset', resetTime.toString())
  return response
}

// Middleware function for rate limiting
export function withRateLimit(
  limiter: RateLimiter,
  getIdentifier: (request: NextRequest) => string = getClientIdentifier
) {
  return (request: NextRequest): { allowed: boolean; response?: Response } => {
    const identifier = getIdentifier(request)
    const result = limiter.isAllowed(identifier)

    if (!result.allowed) {
      const response = createRateLimitResponse(
        result.resetTime,
        (limiter as any).maxRequests,
        (limiter as any).windowMs
      )
      return { allowed: false, response }
    }

    return { allowed: true }
  }
}

// React hook for client-side rate limiting
export function useRateLimit(limit: number, windowMs: number) {
  const [attempts, setAttempts] = useState(0)
  const [resetTime, setResetTime] = useState<number | null>(null)
  const [isBlocked, setIsBlocked] = useState(false)

  const checkLimit = useCallback(() => {
    const now = Date.now()
    
    if (resetTime && now < resetTime) {
      setIsBlocked(true)
      return false
    }
    
    if (resetTime && now >= resetTime) {
      // Reset the window
      setAttempts(0)
      setResetTime(null)
      setIsBlocked(false)
    }
    
    if (attempts >= limit) {
      const newResetTime = now + windowMs
      setResetTime(newResetTime)
      setIsBlocked(true)
      return false
    }
    
    setAttempts(prev => prev + 1)
    return true
  }, [attempts, limit, windowMs, resetTime])

  const reset = useCallback(() => {
    setAttempts(0)
    setResetTime(null)
    setIsBlocked(false)
  }, [])

  const timeUntilReset = resetTime ? Math.max(0, resetTime - Date.now()) : 0

  return {
    canProceed: checkLimit,
    isBlocked,
    attempts,
    remaining: Math.max(0, limit - attempts),
    timeUntilReset,
    reset
  }
}