import { Server } from 'socket.io';

interface NotificationData {
  id: string;
  type: string;
  title: string;
  message: string;
  priority: string;
  read: boolean;
  createdAt: Date;
  data?: any;
}

interface UploadProgress {
  uploadId: string;
  filename: string;
  progress: number;
  status: string;
  error?: string;
}

const connectedUsers = new Map<string, string>(); // userId -> socketId

export const setupSocket = (io: Server) => {
  io.on('connection', (socket) => {
    console.log('Client connected:', socket.id);
    
    // Handle user authentication
    socket.on('authenticate', (userId: string) => {
      connectedUsers.set(userId, socket.id);
      socket.join(`user:${userId}`);
      console.log(`User ${userId} authenticated with socket ${socket.id}`);
    });

    // Handle notifications
    socket.on('mark_notification_read', (data: { notificationId: string; userId: string }) => {
      // Broadcast to all user's sessions
      io.to(`user:${data.userId}`).emit('notification_read', {
        notificationId: data.notificationId,
        timestamp: new Date().toISOString(),
      });
    });

    // Handle upload progress
    socket.on('upload_start', (data: { uploadId: string; userId: string }) => {
      socket.join(`upload:${data.uploadId}`);
    });

    socket.on('disconnect', () => {
      // Remove user from connected users
      for (const [userId, socketId] of connectedUsers.entries()) {
        if (socketId === socket.id) {
          connectedUsers.delete(userId);
          console.log(`User ${userId} disconnected`);
          break;
        }
      }
      console.log('Client disconnected:', socket.id);
    });

    // Send welcome message
    socket.emit('connected', {
      message: 'Connected to financial system WebSocket!',
      timestamp: new Date().toISOString(),
    });
  });
};

// Helper functions to emit events from server-side
export const emitNotification = (userId: string, notification: NotificationData) => {
  const socketId = connectedUsers.get(userId);
  if (socketId) {
    const io = globalThis.io as Server;
    if (io) {
      io.to(`user:${userId}`).emit('notification', {
        ...notification,
        timestamp: new Date().toISOString(),
      });
    }
  }
};

export const emitUploadProgress = (uploadId: string, progress: UploadProgress) => {
  const io = globalThis.io as Server;
  if (io) {
    io.to(`upload:${uploadId}`).emit('upload_progress', {
      ...progress,
      timestamp: new Date().toISOString(),
    });
  }
};

export const emitTransactionUpdate = (userId: string, transaction: any) => {
  const io = globalThis.io as Server;
  if (io) {
    io.to(`user:${userId}`).emit('transaction_update', {
      ...transaction,
      timestamp: new Date().toISOString(),
    });
  }
};

export const emitBudgetAlert = (userId: string, alert: any) => {
  const io = globalThis.io as Server;
  if (io) {
    io.to(`user:${userId}`).emit('budget_alert', {
      ...alert,
      timestamp: new Date().toISOString(),
    });
  }
};

export const emitGoalUpdate = (userId: string, goal: any) => {
  const io = globalThis.io as Server;
  if (io) {
    io.to(`user:${userId}`).emit('goal_update', {
      ...goal,
      timestamp: new Date().toISOString(),
    });
  }
};