import { db } from '@/lib/db'

export interface NotificationData {
  type: 'budget_alert' | 'payment_reminder' | 'goal_achieved' | 'anomaly_detected' | 'insight_ready'
  title: string
  message: string
  priority: 'low' | 'medium' | 'high'
  userId: string
  data?: any
}

export interface NotificationRuleData {
  name: string
  type: string
  enabled: boolean
  channels: string[]
  conditions: any
  userId: string
}

export class NotificationService {
  static async createNotification(data: NotificationData) {
    try {
      const notification = await db.notification.create({
        data: {
          type: data.type,
          title: data.title,
          message: data.message,
          priority: data.priority,
          userId: data.userId,
          data: data.data ? JSON.stringify(data.data) : null,
        },
      })

      // Send real-time notification via WebSocket
      if (typeof window === 'undefined') {
        // Server-side: emit to socket
        const { emitNotification } = await import('./socket')
        emitNotification(data.userId, {
          id: notification.id,
          type: notification.type,
          title: notification.title,
          message: notification.message,
          priority: notification.priority,
          read: notification.read,
          createdAt: notification.createdAt,
          data: data.data,
        })
      }

      return notification
    } catch (error) {
      console.error('Error creating notification:', error)
      throw error
    }
  }

  static async getUserNotifications(userId: string, options: {
    unreadOnly?: boolean
    type?: string
    limit?: number
    offset?: number
  } = {}) {
    try {
      const where: any = { userId }
      
      if (options.unreadOnly) {
        where.read = false
      }
      
      if (options.type) {
        where.type = options.type
      }

      const notifications = await db.notification.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        take: options.limit || 50,
        skip: options.offset || 0,
      })

      return notifications.map(notification => ({
        ...notification,
        data: notification.data ? JSON.parse(notification.data) : null,
      }))
    } catch (error) {
      console.error('Error fetching notifications:', error)
      throw error
    }
  }

  static async markAsRead(notificationId: string, userId: string) {
    try {
      const notification = await db.notification.updateMany({
        where: {
          id: notificationId,
          userId,
        },
        data: {
          read: true,
        },
      })

      return notification
    } catch (error) {
      console.error('Error marking notification as read:', error)
      throw error
    }
  }

  static async markAllAsRead(userId: string) {
    try {
      const result = await db.notification.updateMany({
        where: {
          userId,
          read: false,
        },
        data: {
          read: true,
        },
      })

      return result
    } catch (error) {
      console.error('Error marking all notifications as read:', error)
      throw error
    }
  }

  static async deleteNotification(notificationId: string, userId: string) {
    try {
      const notification = await db.notification.deleteMany({
        where: {
          id: notificationId,
          userId,
        },
      })

      return notification
    } catch (error) {
      console.error('Error deleting notification:', error)
      throw error
    }
  }

  static async getUnreadCount(userId: string) {
    try {
      const count = await db.notification.count({
        where: {
          userId,
          read: false,
        },
      })

      return count
    } catch (error) {
      console.error('Error getting unread count:', error)
      throw error
    }
  }

  static async createNotificationRule(data: NotificationRuleData) {
    try {
      const rule = await db.notificationRule.create({
        data: {
          name: data.name,
          type: data.type,
          enabled: data.enabled,
          channels: JSON.stringify(data.channels),
          conditions: JSON.stringify(data.conditions),
          userId: data.userId,
        },
      })

      return {
        ...rule,
        channels: JSON.parse(rule.channels),
        conditions: JSON.parse(rule.conditions),
      }
    } catch (error) {
      console.error('Error creating notification rule:', error)
      throw error
    }
  }

  static async getUserNotificationRules(userId: string) {
    try {
      const rules = await db.notificationRule.findMany({
        where: {
          userId,
        },
        orderBy: { createdAt: 'desc' },
      })

      return rules.map(rule => ({
        ...rule,
        channels: JSON.parse(rule.channels),
        conditions: JSON.parse(rule.conditions),
      }))
    } catch (error) {
      console.error('Error fetching notification rules:', error)
      throw error
    }
  }

  static async updateNotificationRule(ruleId: string, userId: string, updates: Partial<NotificationRuleData>) {
    try {
      const updateData: any = { ...updates }
      
      if (updates.channels) {
        updateData.channels = JSON.stringify(updates.channels)
      }
      
      if (updates.conditions) {
        updateData.conditions = JSON.stringify(updates.conditions)
      }

      const rule = await db.notificationRule.updateMany({
        where: {
          id: ruleId,
          userId,
        },
        data: updateData,
      })

      return rule
    } catch (error) {
      console.error('Error updating notification rule:', error)
      throw error
    }
  }

  static async deleteNotificationRule(ruleId: string, userId: string) {
    try {
      const rule = await db.notificationRule.deleteMany({
        where: {
          id: ruleId,
          userId,
        },
      })

      return rule
    } catch (error) {
      console.error('Error deleting notification rule:', error)
      throw error
    }
  }

  static async checkAndTriggerNotifications(userId: string) {
    try {
      // Check budget alerts
      await this.checkBudgetAlerts(userId)
      
      // Check payment reminders
      await this.checkPaymentReminders(userId)
      
      // Check goal achievements
      await this.checkGoalAchievements(userId)
      
      // Check for anomalies
      await this.checkAnomalies(userId)
      
    } catch (error) {
      console.error('Error checking and triggering notifications:', error)
    }
  }

  private static async checkBudgetAlerts(userId: string) {
    try {
      const budgets = await db.budget.findMany({
        where: {
          userId,
          isActive: true,
        },
        include: {
          category: true,
        },
      })

      for (const budget of budgets) {
        const spent = await this.calculateBudgetSpending(budget.id, userId)
        const percentage = (spent / budget.amount) * 100

        // Check if budget exceeds threshold (e.g., 80%)
        if (percentage >= 80) {
          const rules = await db.notificationRule.findMany({
            where: {
              userId,
              type: 'budget_alert',
              enabled: true,
            },
          })

          for (const rule of rules) {
            const conditions = JSON.parse(rule.conditions)
            if (percentage >= conditions.threshold) {
              await this.createNotification({
                type: 'budget_alert',
                title: `Orçamento de ${budget.category?.name || 'Geral'} Excedido`,
                message: `Você já utilizou ${percentage.toFixed(1)}% do seu orçamento para ${budget.category?.name || 'geral'} este mês.`,
                priority: percentage >= 100 ? 'high' : 'medium',
                userId,
                data: {
                  budgetId: budget.id,
                  budgetUsed: spent,
                  budgetTotal: budget.amount,
                  percentage,
                },
              })
              break // Only send one notification per budget
            }
          }
        }
      }
    } catch (error) {
      console.error('Error checking budget alerts:', error)
    }
  }

  private static async checkPaymentReminders(userId: string) {
    try {
      // This would typically check for upcoming bills
      // For now, we'll simulate with some logic
      
      const rules = await db.notificationRule.findMany({
        where: {
          userId,
          type: 'payment_reminder',
          enabled: true,
        },
      })

      // Implementation would depend on how bills are stored/tracked
      // This is a placeholder for the actual implementation
      
    } catch (error) {
      console.error('Error checking payment reminders:', error)
    }
  }

  private static async checkGoalAchievements(userId: string) {
    try {
      const goals = await db.goal.findMany({
        where: {
          userId,
          isActive: true,
          status: 'active',
        },
      })

      for (const goal of goals) {
        if (goal.currentAmount >= goal.targetAmount) {
          // Mark goal as completed
          await db.goal.update({
            where: { id: goal.id },
            data: { status: 'completed' },
          })

          // Send notification
          await this.createNotification({
            type: 'goal_achieved',
            title: 'Meta Alcançada! 🎉',
            message: `Parabéns! Você alcançou sua meta de ${goal.name}`,
            priority: 'low',
            userId,
            data: {
              goalId: goal.id,
              goalName: goal.name,
              targetAmount: goal.targetAmount,
              currentAmount: goal.currentAmount,
            },
          })
        }
      }
    } catch (error) {
      console.error('Error checking goal achievements:', error)
    }
  }

  private static async checkAnomalies(userId: string) {
    try {
      // Get recent transactions
      const recentTransactions = await db.transaction.findMany({
        where: {
          userId,
          date: {
            gte: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000), // Last 30 days
          },
        },
        include: {
          category: true,
        },
      })

      // Group by category and calculate averages
      const categoryStats: { [key: string]: { total: number; count: number; avg: number } } = {}
      
      for (const transaction of recentTransactions) {
        if (transaction.category) {
          const categoryName = transaction.category.name
          if (!categoryStats[categoryName]) {
            categoryStats[categoryName] = { total: 0, count: 0, avg: 0 }
          }
          categoryStats[categoryName].total += Math.abs(transaction.amount)
          categoryStats[categoryName].count += 1
        }
      }

      // Calculate averages
      for (const category in categoryStats) {
        categoryStats[category].avg = categoryStats[category].total / categoryStats[category].count
      }

      // Check for anomalies (transactions that are 3x the average)
      for (const transaction of recentTransactions) {
        if (transaction.category && categoryStats[transaction.category.name]) {
          const avgAmount = categoryStats[transaction.category.name].avg
          const currentAmount = Math.abs(transaction.amount)
          
          if (currentAmount > avgAmount * 3 && currentAmount > 100) { // Only for significant amounts
            await this.createNotification({
              type: 'anomaly_detected',
              title: 'Transação Incomum Detectada',
              message: `Detectamos uma transação de R$ ${currentAmount.toFixed(2)} em "${transaction.category.name}" - ${((currentAmount / avgAmount) * 100).toFixed(0)}% acima do normal`,
              priority: 'high',
              userId,
              data: {
                transactionId: transaction.id,
                amount: currentAmount,
                category: transaction.category.name,
                averageAmount: avgAmount,
                percentage: (currentAmount / avgAmount) * 100,
              },
            })
          }
        }
      }
    } catch (error) {
      console.error('Error checking anomalies:', error)
    }
  }

  private static async calculateBudgetSpending(budgetId: string, userId: string) {
    try {
      const budget = await db.budget.findUnique({
        where: { id: budgetId },
        include: { category: true },
      })

      if (!budget) return 0

      const startDate = new Date()
      startDate.setDate(1) // First day of current month
      
      const endDate = new Date()
      endDate.setMonth(endDate.getMonth() + 1)
      endDate.setDate(0) // Last day of current month

      const transactions = await db.transaction.findMany({
        where: {
          userId,
          type: 'expense',
          date: {
            gte: startDate,
            lte: endDate,
          },
          ...(budget.categoryId && { categoryId: budget.categoryId }),
        },
      })

      const totalSpent = transactions.reduce((sum, transaction) => sum + Math.abs(transaction.amount), 0)
      return totalSpent
    } catch (error) {
      console.error('Error calculating budget spending:', error)
      return 0
    }
  }
}