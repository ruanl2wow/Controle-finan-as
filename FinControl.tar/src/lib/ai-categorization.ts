import ZAI from 'z-ai-web-dev-sdk';
import { Transaction } from '@prisma/client';

export interface AICategorization {
  category: string;
  subcategory: string;
  confidence: number;
  reasoning: string;
}

export class AICategorizationService {
  private static readonly CATEGORIES = [
    'Food & Dining',
    'Shopping', 
    'Transportation',
    'Housing',
    'Utilities',
    'Healthcare',
    'Entertainment',
    'Education',
    'Personal Care',
    'Travel',
    'Taxes',
    'Insurance',
    'Savings & Investments',
    'Debt Payments',
    'Income',
    'Other'
  ];

  static async categorizeTransactions(transactions: Transaction[]): Promise<AICategorization[]> {
    if (transactions.length === 0) {
      return [];
    }

    try {
      const zai = await ZAI.create();

      // Prepare transactions for AI analysis
      const transactionsForAI = transactions.map(t => ({
        description: t.description,
        amount: t.amount,
        date: t.date,
        type: t.type
      }));

      // Create AI prompt for categorization
      const prompt = `Categorize these financial transactions into standard categories. 
      For each transaction, provide:
      1. A category from this list: ${this.CATEGORIES.join(', ')}
      2. A subcategory (more specific)
      3. Confidence level (0-1)
      4. Reasoning for the categorization

      Transactions to categorize:
      ${JSON.stringify(transactionsForAI, null, 2)}

      Please respond with a JSON array where each object has the same index as the input transactions and contains:
      {
        "category": "category_name",
        "subcategory": "subcategory_name", 
        "confidence": 0.95,
        "reasoning": "brief explanation"
      }

      Analyze merchant names, transaction amounts, and patterns to determine the most accurate category.`;

      // Get AI categorization
      const completion = await zai.chat.completions.create({
        messages: [
          {
            role: 'system',
            content: 'You are a financial transaction categorization expert. Analyze transaction descriptions and categorize them accurately based on merchant names, amounts, and patterns. Always respond with valid JSON.'
          },
          {
            role: 'user',
            content: prompt
          }
        ],
        temperature: 0.3,
        max_tokens: 4000
      });

      const aiResponse = completion.choices[0]?.message?.content;
      if (!aiResponse) {
        throw new Error('No response from AI');
      }

      // Parse AI response
      let categorizations: AICategorization[];
      try {
        categorizations = JSON.parse(aiResponse);
      } catch (parseError) {
        console.error('Failed to parse AI response:', aiResponse);
        // Fallback to uncategorized
        return transactions.map(() => ({
          category: 'Other',
          subcategory: 'Uncategorized',
          confidence: 0,
          reasoning: 'AI parsing failed'
        }));
      }

      // Validate and ensure we have the right number of categorizations
      if (!Array.isArray(categorizations) || categorizations.length !== transactions.length) {
        console.error('Invalid categorization count');
        return transactions.map(() => ({
          category: 'Other',
          subcategory: 'Uncategorized',
          confidence: 0,
          reasoning: 'AI response validation failed'
        }));
      }

      // Validate each categorization
      return categorizations.map(cat => ({
        category: this.CATEGORIES.includes(cat.category) ? cat.category : 'Other',
        subcategory: cat.subcategory || 'Uncategorized',
        confidence: Math.min(1, Math.max(0, cat.confidence || 0)),
        reasoning: cat.reasoning || 'No reasoning provided'
      }));

    } catch (error) {
      console.error('AI categorization failed:', error);
      // Return fallback categorizations
      return transactions.map(() => ({
        category: 'Other',
        subcategory: 'Uncategorized',
        confidence: 0,
        reasoning: 'AI service unavailable'
      }));
    }
  }

  static async categorizeSingleTransaction(transaction: Transaction): Promise<AICategorization> {
    const categorizations = await this.categorizeTransactions([transaction]);
    return categorizations[0] || {
      category: 'Other',
      subcategory: 'Uncategorized',
      confidence: 0,
      reasoning: 'Categorization failed'
    };
  }

  static getCategorySuggestions(description: string, amount: number): string[] {
    const desc = description.toLowerCase();
    
    // Simple keyword-based suggestions as fallback
    if (desc.includes('restaurant') || desc.includes('food') || desc.includes('coffee')) {
      return ['Food & Dining'];
    }
    if (desc.includes('gas') || desc.includes('uber') || desc.includes('taxi')) {
      return ['Transportation'];
    }
    if (desc.includes('rent') || desc.includes('mortgage')) {
      return ['Housing'];
    }
    if (desc.includes('electric') || desc.includes('water') || desc.includes('internet')) {
      return ['Utilities'];
    }
    if (desc.includes('doctor') || desc.includes('pharmacy')) {
      return ['Healthcare'];
    }
    if (desc.includes('netflix') || desc.includes('spotify') || desc.includes('movie')) {
      return ['Entertainment'];
    }
    if (desc.includes('salary') || desc.includes('payroll')) {
      return ['Income'];
    }
    
    return ['Other'];
  }
}