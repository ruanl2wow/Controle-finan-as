import { NextAuthOptions } from 'next-auth'
import CredentialsProvider from 'next-auth/providers/credentials'
import GoogleProvider from 'next-auth/providers/google'
import GitHubProvider from 'next-auth/providers/github'

// Usuário demo para testes
const demoUser = {
  id: 'demo-user',
  email: 'demo@financas.com',
  name: 'Usuário Demo',
  role: 'user'
}

export const authOptions: NextAuthOptions = {
  providers: [
    CredentialsProvider({
      name: 'credentials',
      credentials: {
        email: { label: 'Email', type: 'email' },
        password: { label: 'Password', type: 'password' }
      },
      async authorize(credentials) {
        if (!credentials?.email || !credentials?.password) {
          return null
        }

        // Verificar usuário demo
        if (credentials.email === demoUser.email && credentials.password === 'demo123') {
          return demoUser
        }

        // Em produção, aqui você verificaria no banco de dados
        // Por enquanto, vamos aceitar qualquer email/senha para demonstração
        if (credentials.password.length >= 6) {
          return {
            id: `user-${Date.now()}`,
            email: credentials.email,
            name: credentials.email.split('@')[0],
            role: 'user'
          }
        }

        return null
      }
    }),
    GoogleProvider({
      clientId: process.env.GOOGLE_CLIENT_ID || 'demo_client_id',
      clientSecret: process.env.GOOGLE_CLIENT_SECRET || 'demo_client_secret',
    }),
    GitHubProvider({
      clientId: process.env.GITHUB_ID || 'demo_client_id',
      clientSecret: process.env.GITHUB_SECRET || 'demo_client_secret',
    }),
  ],
  session: {
    strategy: 'jwt'
  },
  callbacks: {
    async jwt({ token, user }) {
      if (user) {
        token.role = user.role
      }
      return token
    },
    async session({ session, token }) {
      if (token) {
        session.user.id = token.sub!
        session.user.role = token.role as string
      }
      return session
    }
  },
  pages: {
    signIn: '/auth/signin',
    signUp: '/auth/signup',
    error: '/auth/error'
  },
  secret: process.env.NEXTAUTH_SECRET
}