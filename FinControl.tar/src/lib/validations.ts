import { z } from 'zod'

// User validation schemas
export const userSchema = z.object({
  id: z.string().cuid().optional(),
  email: z.string().email('Email inválido'),
  name: z.string().min(2, 'Nome deve ter pelo menos 2 caracteres').optional(),
  password: z.string().min(6, 'Senha deve ter pelo menos 6 caracteres').optional(),
  role: z.enum(['admin', 'user', 'readonly']).default('user'),
  twoFactorEnabled: z.boolean().default(false),
})

export const signInSchema = z.object({
  email: z.string().email('Email inválido'),
  password: z.string().min(1, 'Senha é obrigatória'),
})

export const signUpSchema = userSchema.extend({
  password: z.string().min(6, 'Senha deve ter pelo menos 6 caracteres'),
  confirmPassword: z.string().min(6, 'Confirme a senha'),
}).refine((data) => data.password === data.confirmPassword, {
  message: 'As senhas não coincidem',
  path: ['confirmPassword'],
})

// Transaction validation schemas
export const transactionSchema = z.object({
  id: z.string().cuid().optional(),
  date: z.string().transform((str) => new Date(str)),
  description: z.string().min(1, 'Descrição é obrigatória').max(255, 'Descrição muito longa'),
  amount: z.number().finite('Valor deve ser um número válido'),
  type: z.enum(['income', 'expense']),
  categoryId: z.string().cuid().optional(),
  accountId: z.string().cuid(),
  tags: z.array(z.string()).optional(),
  metadata: z.record(z.any()).optional(),
})

export const transactionUpdateSchema = transactionSchema.partial().omit({
  id: true,
  userId: true,
  createdAt: true,
  updatedAt: true,
})

// Category validation schemas
export const categorySchema = z.object({
  id: z.string().cuid().optional(),
  name: z.string().min(1, 'Nome é obrigatório').max(100, 'Nome muito longo'),
  description: z.string().max(255, 'Descrição muito longa').optional(),
  color: z.string().regex(/^#[0-9A-Fa-f]{6}$/, 'Cor inválida').default('#6B7280'),
  icon: z.string().optional(),
  type: z.enum(['income', 'expense']),
})

export const categoryUpdateSchema = categorySchema.partial().omit({
  id: true,
  userId: true,
  createdAt: true,
  updatedAt: true,
})

// Account validation schemas
export const accountSchema = z.object({
  id: z.string().cuid().optional(),
  name: z.string().min(1, 'Nome é obrigatório').max(100, 'Nome muito longo'),
  type: z.enum(['checking', 'savings', 'credit', 'investment']),
  balance: z.number().finite('Saldo deve ser um número válido').default(0),
  currency: z.string().length(3, 'Moeda inválida').default('BRL'),
})

export const accountUpdateSchema = accountSchema.partial().omit({
  id: true,
  userId: true,
  createdAt: true,
  updatedAt: true,
})

// Rule validation schemas
export const ruleSchema = z.object({
  id: z.string().cuid().optional(),
  name: z.string().min(1, 'Nome é obrigatório').max(100, 'Nome muito longo'),
  condition: z.string().min(1, 'Condição é obrigatória'),
  action: z.string().min(1, 'Ação é obrigatória'),
  priority: z.number().int().min(0).max(100).default(0),
  isActive: z.boolean().default(true),
  categoryId: z.string().cuid().optional(),
})

export const ruleUpdateSchema = ruleSchema.partial().omit({
  id: true,
  userId: true,
  createdAt: true,
  updatedAt: true,
})

// Upload validation schemas
export const uploadSchema = z.object({
  id: z.string().cuid().optional(),
  filename: z.string().min(1, 'Nome do arquivo é obrigatório'),
  originalName: z.string().min(1, 'Nome original é obrigatório'),
  fileType: z.enum(['csv', 'ofx', 'qif', 'pdf']),
  fileSize: z.number().int().positive('Tamanho do arquivo inválido'),
  status: z.enum(['pending', 'processing', 'completed', 'error']).default('pending'),
  error: z.string().optional(),
  accountId: z.string().cuid().optional(),
})

// Query parameter validation schemas
export const paginationSchema = z.object({
  page: z.coerce.number().int().positive().default(1),
  limit: z.coerce.number().int().positive().max(100).default(20),
  search: z.string().optional(),
  sortBy: z.string().optional(),
  sortOrder: z.enum(['asc', 'desc']).default('desc'),
})

export const transactionFilterSchema = paginationSchema.extend({
  categoryId: z.string().cuid().optional(),
  accountId: z.string().cuid().optional(),
  type: z.enum(['income', 'expense']).optional(),
  dateFrom: z.string().transform((str) => new Date(str)).optional(),
  dateTo: z.string().transform((str) => new Date(str)).optional(),
  minAmount: z.number().finite().optional(),
  maxAmount: z.number().finite().optional(),
})

export const dateRangeSchema = z.object({
  from: z.string().transform((str) => new Date(str)),
  to: z.string().transform((str) => new Date(str)),
}).refine((data) => data.from <= data.to, {
  message: 'A data inicial deve ser anterior à data final',
})

// API response schemas
export const apiResponseSchema = <T>(dataSchema: z.ZodType<T>) => z.object({
  success: z.boolean(),
  data: dataSchema.optional(),
  error: z.string().optional(),
  message: z.string().optional(),
  pagination: z.object({
    page: z.number(),
    limit: z.number(),
    total: z.number(),
    totalPages: z.number(),
  }).optional(),
})

// Validation helper functions
export function validateRequest<T>(
  schema: z.ZodSchema<T>,
  data: unknown
): { success: true; data: T } | { success: false; error: string } {
  try {
    const validatedData = schema.parse(data)
    return { success: true, data: validatedData }
  } catch (error) {
    if (error instanceof z.ZodError) {
      const errorMessage = error.errors.map(e => e.message).join(', ')
      return { success: false, error: errorMessage }
    }
    return { success: false, error: 'Erro de validação desconhecido' }
  }
}

export function validateSearchParams(
  schema: z.ZodSchema,
  searchParams: URLSearchParams
) {
  const params: Record<string, any> = {}
  for (const [key, value] of searchParams.entries()) {
    params[key] = value
  }
  return validateRequest(schema, params)
}

// Type exports
export type UserInput = z.infer<typeof userSchema>
export type SignInInput = z.infer<typeof signInSchema>
export type SignUpInput = z.infer<typeof signUpSchema>
export type TransactionInput = z.infer<typeof transactionSchema>
export type TransactionUpdateInput = z.infer<typeof transactionUpdateSchema>
export type CategoryInput = z.infer<typeof categorySchema>
export type CategoryUpdateInput = z.infer<typeof categoryUpdateSchema>
export type AccountInput = z.infer<typeof accountSchema>
export type AccountUpdateInput = z.infer<typeof accountUpdateSchema>
export type RuleInput = z.infer<typeof ruleSchema>
export type RuleUpdateInput = z.infer<typeof ruleUpdateSchema>
export type UploadInput = z.infer<typeof uploadSchema>
export type PaginationParams = z.infer<typeof paginationSchema>
export type TransactionFilterParams = z.infer<typeof transactionFilterSchema>
export type DateRangeInput = z.infer<typeof dateRangeSchema>