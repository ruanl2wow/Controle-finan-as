export type Role = 'admin' | 'user' | 'readonly'

export interface Permission {
  resource: string
  action: 'create' | 'read' | 'update' | 'delete' | 'manage'
}

export const ROLE_PERMISSIONS: Record<Role, Permission[]> = {
  admin: [
    // Users management
    { resource: 'users', action: 'create' },
    { resource: 'users', action: 'read' },
    { resource: 'users', action: 'update' },
    { resource: 'users', action: 'delete' },
    { resource: 'users', action: 'manage' },
    
    // Transactions
    { resource: 'transactions', action: 'create' },
    { resource: 'transactions', action: 'read' },
    { resource: 'transactions', action: 'update' },
    { resource: 'transactions', action: 'delete' },
    { resource: 'transactions', action: 'manage' },
    
    // Categories
    { resource: 'categories', action: 'create' },
    { resource: 'categories', action: 'read' },
    { resource: 'categories', action: 'update' },
    { resource: 'categories', action: 'delete' },
    { resource: 'categories', action: 'manage' },
    
    // Accounts
    { resource: 'accounts', action: 'create' },
    { resource: 'accounts', action: 'read' },
    { resource: 'accounts', action: 'update' },
    { resource: 'accounts', action: 'delete' },
    { resource: 'accounts', action: 'manage' },
    
    // Rules
    { resource: 'rules', action: 'create' },
    { resource: 'rules', action: 'read' },
    { resource: 'rules', action: 'update' },
    { resource: 'rules', action: 'delete' },
    { resource: 'rules', action: 'manage' },
    
    // Uploads
    { resource: 'uploads', action: 'create' },
    { resource: 'uploads', action: 'read' },
    { resource: 'uploads', action: 'update' },
    { resource: 'uploads', action: 'delete' },
    { resource: 'uploads', action: 'manage' },
    
    // Reports
    { resource: 'reports', action: 'create' },
    { resource: 'reports', action: 'read' },
    { resource: 'reports', action: 'update' },
    { resource: 'reports', action: 'delete' },
    { resource: 'reports', action: 'manage' },
    
    // Dashboard
    { resource: 'dashboard', action: 'read' },
    { resource: 'dashboard', action: 'manage' },
    
    // Settings
    { resource: 'settings', action: 'read' },
    { resource: 'settings', action: 'update' },
    { resource: 'settings', action: 'manage' },
  ],
  
  user: [
    // Transactions (own data only)
    { resource: 'transactions', action: 'create' },
    { resource: 'transactions', action: 'read' },
    { resource: 'transactions', action: 'update' },
    { resource: 'transactions', action: 'delete' },
    
    // Categories (own data only)
    { resource: 'categories', action: 'create' },
    { resource: 'categories', action: 'read' },
    { resource: 'categories', action: 'update' },
    { resource: 'categories', action: 'delete' },
    
    // Accounts (own data only)
    { resource: 'accounts', action: 'create' },
    { resource: 'accounts', action: 'read' },
    { resource: 'accounts', action: 'update' },
    { resource: 'accounts', action: 'delete' },
    
    // Rules (own data only)
    { resource: 'rules', action: 'create' },
    { resource: 'rules', action: 'read' },
    { resource: 'rules', action: 'update' },
    { resource: 'rules', action: 'delete' },
    
    // Uploads (own data only)
    { resource: 'uploads', action: 'create' },
    { resource: 'uploads', action: 'read' },
    { resource: 'uploads', action: 'delete' },
    
    // Reports (own data only)
    { resource: 'reports', action: 'create' },
    { resource: 'reports', action: 'read' },
    
    // Dashboard
    { resource: 'dashboard', action: 'read' },
    
    // Settings (own profile only)
    { resource: 'settings', action: 'read' },
    { resource: 'settings', action: 'update' },
  ],
  
  readonly: [
    // Read-only access to most resources
    { resource: 'transactions', action: 'read' },
    { resource: 'categories', action: 'read' },
    { resource: 'accounts', action: 'read' },
    { resource: 'rules', action: 'read' },
    { resource: 'uploads', action: 'read' },
    { resource: 'reports', action: 'read' },
    { resource: 'dashboard', action: 'read' },
    { resource: 'settings', action: 'read' },
  ],
}

export function hasPermission(
  userRole: Role,
  resource: string,
  action: Permission['action']
): boolean {
  const permissions = ROLE_PERMISSIONS[userRole] || []
  return permissions.some(
    permission => 
      permission.resource === resource && 
      (permission.action === action || permission.action === 'manage')
  )
}

export function canAccessRoute(userRole: Role, route: string): boolean {
  const routePermissions: Record<string, Permission> = {
    '/admin': { resource: 'users', action: 'manage' },
    '/dashboard': { resource: 'dashboard', action: 'read' },
    '/planilha': { resource: 'transactions', action: 'read' },
    '/categorias': { resource: 'categories', action: 'read' },
    '/upload': { resource: 'uploads', action: 'create' },
    '/relatorios': { resource: 'reports', action: 'read' },
    '/configuracoes': { resource: 'settings', action: 'read' },
  }

  const permission = routePermissions[route]
  if (!permission) return true // Allow access to undefined routes

  return hasPermission(userRole, permission.resource, permission.action)
}

export function getRoleHierarchy(): Record<Role, number> {
  return {
    readonly: 1,
    user: 2,
    admin: 3,
  }
}

export function canManageRole(managerRole: Role, targetRole: Role): boolean {
  const hierarchy = getRoleHierarchy()
  return hierarchy[managerRole] > hierarchy[targetRole]
}

// React hook for permissions
export function usePermissions(role: Role) {
  return {
    hasPermission: (resource: string, action: Permission['action']) => 
      hasPermission(role, resource, action),
    canAccessRoute: (route: string) => canAccessRoute(role, route),
    canManageRole: (targetRole: Role) => canManageRole(role, targetRole),
    isAdmin: role === 'admin',
    isUser: role === 'user',
    isReadonly: role === 'readonly',
  }
}