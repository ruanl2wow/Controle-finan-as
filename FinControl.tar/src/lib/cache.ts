'use client'

import { useState, useEffect, useCallback } from 'react'

interface CacheItem<T> {
  data: T
  timestamp: number
  ttl: number
}

class MemoryCache {
  private cache = new Map<string, CacheItem<any>>()
  private readonly defaultTTL = 5 * 60 * 1000 // 5 minutes

  set<T>(key: string, data: T, ttl?: number): void {
    this.cache.set(key, {
      data,
      timestamp: Date.now(),
      ttl: ttl || this.defaultTTL
    })
  }

  get<T>(key: string): T | null {
    const item = this.cache.get(key)
    if (!item) return null

    if (Date.now() - item.timestamp > item.ttl) {
      this.cache.delete(key)
      return null
    }

    return item.data
  }

  delete(key: string): boolean {
    return this.cache.delete(key)
  }

  clear(): void {
    this.cache.clear()
  }

  // Clear cache by pattern
  clearByPattern(pattern: string): void {
    const regex = new RegExp(pattern)
    for (const key of this.cache.keys()) {
      if (regex.test(key)) {
        this.cache.delete(key)
      }
    }
  }

  // Get cache statistics
  getStats(): { size: number; keys: string[] } {
    return {
      size: this.cache.size,
      keys: Array.from(this.cache.keys())
    }
  }

  // Clean expired items
  cleanExpired(): void {
    const now = Date.now()
    for (const [key, item] of this.cache.entries()) {
      if (now - item.timestamp > item.ttl) {
        this.cache.delete(key)
      }
    }
  }
}

// Global cache instance
export const cache = new MemoryCache()

// Cache decorator for functions
export function cached<T extends (...args: any[]) => Promise<any>>(
  fn: T,
  keyGenerator: (...args: Parameters<T>) => string,
  ttl?: number
): T {
  return (async (...args: Parameters<T>) => {
    const key = keyGenerator(...args)
    const cached = cache.get(key)
    
    if (cached) {
      return cached
    }

    const result = await fn(...args)
    cache.set(key, result, ttl)
    return result
  }) as T
}

// React hook for cached data
export function useCachedData<T>(
  key: string,
  fetcher: () => Promise<T>,
  ttl?: number
) {
  const [data, setData] = useState<T | null>(() => cache.get(key))
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<Error | null>(null)

  useEffect(() => {
    const cached = cache.get(key)
    if (cached) {
      setData(cached)
      return
    }

    setLoading(true)
    setError(null)

    fetcher()
      .then(result => {
        setData(result)
        cache.set(key, result, ttl)
      })
      .catch(err => {
        setError(err)
      })
      .finally(() => {
        setLoading(false)
      })
  }, [key, fetcher, ttl])

  const refetch = useCallback(() => {
    cache.delete(key)
    setLoading(true)
    setError(null)

    fetcher()
      .then(result => {
        setData(result)
        cache.set(key, result, ttl)
      })
      .catch(err => {
        setError(err)
      })
      .finally(() => {
        setLoading(false)
      })
  }, [key, fetcher, ttl])

  return { data, loading, error, refetch }
}

// Specific cache keys for the application
export const CACHE_KEYS = {
  CATEGORIES: (userId: string) => `categories:${userId}`,
  ACCOUNTS: (userId: string) => `accounts:${userId}`,
  RULES: (userId: string) => `rules:${userId}`,
  TRANSACTIONS: (userId: string, filters?: string) => 
    `transactions:${userId}${filters ? `:${filters}` : ''}`,
  DASHBOARD_STATS: (userId: string, period?: string) => 
    `dashboard:stats:${userId}${period ? `:${period}` : ''}`,
  UPLOADS: (userId: string) => `uploads:${userId}`
}

// Cache TTL values (in milliseconds)
export const CACHE_TTL = {
  SHORT: 2 * 60 * 1000, // 2 minutes
  MEDIUM: 5 * 60 * 1000, // 5 minutes
  LONG: 15 * 60 * 1000, // 15 minutes
  VERY_LONG: 60 * 60 * 1000 // 1 hour
}