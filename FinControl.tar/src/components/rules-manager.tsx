'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select'
import { Switch } from '@/components/ui/switch'
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { 
  Plus, 
  Edit, 
  Trash2, 
  Play, 
  Settings,
  ArrowUp,
  ArrowDown,
  Copy
} from 'lucide-react'
import { toast } from 'sonner'

interface Rule {
  id: string
  name: string
  condition: any
  action: any
  priority: number
  isActive: boolean
  category?: {
    id: string
    name: string
    color: string
  }
  createdAt: string
  updatedAt: string
}

interface RulesManagerProps {
  onRulesChange?: (rules: Rule[]) => void
}

export function RulesManager({ onRulesChange }: RulesManagerProps) {
  const [rules, setRules] = useState<Rule[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false)
  const [editingRule, setEditingRule] = useState<Rule | null>(null)

  useEffect(() => {
    fetchRules()
  }, [])

  const fetchRules = async () => {
    try {
      const response = await fetch('/api/rules')
      if (response.ok) {
        const data = await response.json()
        setRules(data.rules || [])
      }
    } catch (error) {
      console.error('Error fetching rules:', error)
      toast.error('Erro ao carregar regras')
    } finally {
      setIsLoading(false)
    }
  }

  const handleCreateRule = async (ruleData: any) => {
    try {
      const response = await fetch('/api/rules', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(ruleData)
      })

      if (response.ok) {
        const data = await response.json()
        setRules(prev => [...prev, data.rule])
        toast.success('Regra criada com sucesso')
        setIsCreateDialogOpen(false)
        onRulesChange?.([...rules, data.rule])
      } else {
        const error = await response.json()
        toast.error(error.error || 'Erro ao criar regra')
      }
    } catch (error) {
      console.error('Error creating rule:', error)
      toast.error('Erro ao criar regra')
    }
  }

  const handleUpdateRule = async (ruleData: any) => {
    if (!editingRule) return

    try {
      const response = await fetch('/api/rules', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: editingRule.id, ...ruleData })
      })

      if (response.ok) {
        const data = await response.json()
        setRules(prev => prev.map(r => r.id === editingRule.id ? data.rule : r))
        toast.success('Regra atualizada com sucesso')
        setEditingRule(null)
        onRulesChange?.(rules.map(r => r.id === editingRule.id ? data.rule : r))
      } else {
        const error = await response.json()
        toast.error(error.error || 'Erro ao atualizar regra')
      }
    } catch (error) {
      console.error('Error updating rule:', error)
      toast.error('Erro ao atualizar regra')
    }
  }

  const handleDeleteRule = async (ruleId: string) => {
    try {
      const response = await fetch(`/api/rules?id=${ruleId}`, {
        method: 'DELETE'
      })

      if (response.ok) {
        setRules(prev => prev.filter(r => r.id !== ruleId))
        toast.success('Regra excluída com sucesso')
        onRulesChange?.(rules.filter(r => r.id !== ruleId))
      } else {
        const error = await response.json()
        toast.error(error.error || 'Erro ao excluir regra')
      }
    } catch (error) {
      console.error('Error deleting rule:', error)
      toast.error('Erro ao excluir regra')
    }
  }

  const handleToggleRule = async (ruleId: string, isActive: boolean) => {
    try {
      const response = await fetch('/api/rules', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: ruleId, isActive })
      })

      if (response.ok) {
        const data = await response.json()
        setRules(prev => prev.map(r => r.id === ruleId ? data.rule : r))
        onRulesChange?.(rules.map(r => r.id === ruleId ? data.rule : r))
      } else {
        const error = await response.json()
        toast.error(error.error || 'Erro ao atualizar regra')
      }
    } catch (error) {
      console.error('Error toggling rule:', error)
      toast.error('Erro ao atualizar regra')
    }
  }

  const handleApplyRules = async () => {
    try {
      const response = await fetch('/api/rules/apply', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ applyToAll: true })
      })

      if (response.ok) {
        const data = await response.json()
        toast.success(data.message || 'Regras aplicadas com sucesso')
      } else {
        const error = await response.json()
        toast.error(error.error || 'Erro ao aplicar regras')
      }
    } catch (error) {
      console.error('Error applying rules:', error)
      toast.error('Erro ao aplicar regras')
    }
  }

  const duplicateRule = (rule: Rule) => {
    const duplicatedRule = {
      ...rule,
      name: `${rule.name} (cópia)`,
      id: undefined,
      createdAt: undefined,
      updatedAt: undefined
    }
    setEditingRule(duplicatedRule as any)
  }

  const getConditionDescription = (condition: any) => {
    if (!condition) return 'Sem condição'
    
    const { field, operator, value } = condition
    const fieldNames = {
      description: 'Descrição',
      amount: 'Valor',
      type: 'Tipo',
      date: 'Data'
    }
    const operatorNames = {
      contains: 'contém',
      equals: 'igual a',
      startsWith: 'começa com',
      endsWith: 'termina com',
      greaterThan: 'maior que',
      lessThan: 'menor que',
      between: 'entre'
    }

    return `${fieldNames[field as keyof typeof fieldNames] || field} ${operatorNames[operator as keyof typeof operatorNames] || operator} "${value}"`
  }

  const getActionDescription = (action: any) => {
    if (!action) return 'Sem ação'
    
    switch (action.type) {
      case 'categorize':
        return `Categorizar como "${action.categoryName || action.categoryId || 'Não especificado'}"`
      case 'addTag':
        return `Adicionar tags: ${action.tags?.join(', ') || 'Nenhuma'}`
      case 'setNote':
        return `Adicionar nota: "${action.note || 'Não especificado'}"`
      case 'skip':
        return 'Pular outras regras'
      default:
        return 'Ação desconhecida'
    }
  }

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Regras de Automação</CardTitle>
          <CardDescription>Carregando regras...</CardDescription>
        </CardHeader>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Settings className="h-5 w-5" />
              Regras de Automação
            </CardTitle>
            <CardDescription>
              Configure regras automáticas para categorizar transações
            </CardDescription>
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={handleApplyRules}
              className="flex items-center gap-2"
            >
              <Play className="h-4 w-4" />
              Aplicar Regras
            </Button>
            <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
              <DialogTrigger asChild>
                <Button size="sm" className="flex items-center gap-2">
                  <Plus className="h-4 w-4" />
                  Nova Regra
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle>Criar Nova Regra</DialogTitle>
                  <DialogDescription>
                    Configure uma regra automática para processar transações
                  </DialogDescription>
                </DialogHeader>
                <RuleForm
                  onSubmit={handleCreateRule}
                  onCancel={() => setIsCreateDialogOpen(false)}
                />
              </DialogContent>
            </Dialog>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {rules.length === 0 ? (
          <div className="text-center py-8">
            <Settings className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-medium mb-2">Nenhuma regra configurada</h3>
            <p className="text-muted-foreground mb-4">
              Crie regras automáticas para categorizar suas transações de forma inteligente
            </p>
            <Button onClick={() => setIsCreateDialogOpen(true)}>
              <Plus className="mr-2 h-4 w-4" />
              Criar Primeira Regra
            </Button>
          </div>
        ) : (
          <div className="space-y-4">
            {rules.map((rule) => (
              <div
                key={rule.id}
                className={`p-4 border rounded-lg ${
                  rule.isActive ? 'bg-background' : 'bg-muted/30 opacity-60'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-3">
                    <h4 className="font-medium">{rule.name}</h4>
                    <Badge variant={rule.isActive ? 'default' : 'secondary'}>
                      {rule.isActive ? 'Ativa' : 'Inativa'}
                    </Badge>
                    <Badge variant="outline">Prioridade {rule.priority}</Badge>
                  </div>
                  <div className="flex items-center gap-2">
                    <Switch
                      checked={rule.isActive}
                      onCheckedChange={(checked) => handleToggleRule(rule.id, checked)}
                    />
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => duplicateRule(rule)}
                    >
                      <Copy className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setEditingRule(rule)}
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleDeleteRule(rule.id)}
                      className="text-destructive hover:text-destructive"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                
                <div className="space-y-2 text-sm">
                  <div className="flex items-center gap-2">
                    <span className="font-medium">Condição:</span>
                    <span className="text-muted-foreground">
                      {getConditionDescription(rule.condition)}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="font-medium">Ação:</span>
                    <span className="text-muted-foreground">
                      {getActionDescription(rule.action)}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Edit Rule Dialog */}
        <Dialog open={!!editingRule} onOpenChange={() => setEditingRule(null)}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Editar Regra</DialogTitle>
              <DialogDescription>
                Modifique a configuração da regra automática
              </DialogDescription>
            </DialogHeader>
            {editingRule && (
              <RuleForm
                rule={editingRule}
                onSubmit={handleUpdateRule}
                onCancel={() => setEditingRule(null)}
              />
            )}
          </DialogContent>
        </Dialog>
      </CardContent>
    </Card>
  )
}

// Rule Form Component
function RuleForm({ 
  rule, 
  onSubmit, 
  onCancel 
}: { 
  rule?: Rule
  onSubmit: (data: any) => void
  onCancel: () => void 
}) {
  const [formData, setFormData] = useState({
    name: rule?.name || '',
    priority: rule?.priority || 0,
    isActive: rule?.isActive ?? true,
    condition: rule?.condition || {
      field: 'description',
      operator: 'contains',
      value: '',
      caseSensitive: false
    },
    action: rule?.action || {
      type: 'categorize',
      categoryName: '',
      subcategory: ''
    }
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    onSubmit(formData)
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="name">Nome da Regra</Label>
          <Input
            id="name"
            value={formData.name}
            onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
            placeholder="Ex: Supermercados"
            required
          />
        </div>
        <div>
          <Label htmlFor="priority">Prioridade</Label>
          <Input
            id="priority"
            type="number"
            value={formData.priority}
            onChange={(e) => setFormData(prev => ({ ...prev, priority: parseInt(e.target.value) || 0 }))}
            placeholder="0 (maior prioridade)"
          />
        </div>
      </div>

      <div>
        <Label>Condição</Label>
        <div className="grid grid-cols-3 gap-2 mt-2">
          <Select
            value={formData.condition.field}
            onValueChange={(value) => setFormData(prev => ({
              ...prev,
              condition: { ...prev.condition, field: value }
            }))}
          >
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="description">Descrição</SelectItem>
              <SelectItem value="amount">Valor</SelectItem>
              <SelectItem value="type">Tipo</SelectItem>
            </SelectContent>
          </Select>

          <Select
            value={formData.condition.operator}
            onValueChange={(value) => setFormData(prev => ({
              ...prev,
              condition: { ...prev.condition, operator: value }
            }))}
          >
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="contains">Contém</SelectItem>
              <SelectItem value="equals">Igual a</SelectItem>
              <SelectItem value="startsWith">Começa com</SelectItem>
              <SelectItem value="endsWith">Termina com</SelectItem>
              <SelectItem value="greaterThan">Maior que</SelectItem>
              <SelectItem value="lessThan">Menor que</SelectItem>
            </SelectContent>
          </Select>

          <Input
            value={formData.condition.value}
            onChange={(e) => setFormData(prev => ({
              ...prev,
              condition: { ...prev.condition, value: e.target.value }
            }))}
            placeholder="Valor da condição"
          />
        </div>
      </div>

      <div>
        <Label>Ação</Label>
        <div className="grid grid-cols-2 gap-2 mt-2">
          <Select
            value={formData.action.type}
            onValueChange={(value) => setFormData(prev => ({
              ...prev,
              action: { ...prev.action, type: value }
            }))}
          >
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="categorize">Categorizar</SelectItem>
              <SelectItem value="addTag">Adicionar Tag</SelectItem>
              <SelectItem value="setNote">Adicionar Nota</SelectItem>
            </SelectContent>
          </Select>

          {formData.action.type === 'categorize' && (
            <>
              <Input
                value={formData.action.categoryName}
                onChange={(e) => setFormData(prev => ({
                  ...prev,
                  action: { ...prev.action, categoryName: e.target.value }
                }))}
                placeholder="Nome da categoria"
              />
              <Input
                value={formData.action.subcategory}
                onChange={(e) => setFormData(prev => ({
                  ...prev,
                  action: { ...prev.action, subcategory: e.target.value }
                }))}
                placeholder="Subcategoria (opcional)"
              />
            </>
          )}

          {formData.action.type === 'addTag' && (
            <Input
              value={formData.action.tags?.join(', ') || ''}
              onChange={(e) => setFormData(prev => ({
              ...prev,
              action: { ...prev.action, tags: e.target.value.split(',').map(t => t.trim()).filter(t => t) }
              }))}
              placeholder="Tags separadas por vírgula"
            />
          )}

          {formData.action.type === 'setNote' && (
            <Input
              value={formData.action.note || ''}
              onChange={(e) => setFormData(prev => ({
              ...prev,
              action: { ...prev.action, note: e.target.value }
              }))}
              placeholder="Nota da transação"
            />
          )}
        </div>
      </div>

      <div className="flex items-center gap-2">
        <Switch
          id="isActive"
          checked={formData.isActive}
          onCheckedChange={(checked) => setFormData(prev => ({ ...prev, isActive: checked }))}
        />
        <Label htmlFor="isActive">Regra ativa</Label>
      </div>

      <div className="flex justify-end gap-2">
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancelar
        </Button>
        <Button type="submit">
          {rule ? 'Atualizar' : 'Criar'} Regra
        </Button>
      </div>
    </form>
  )
}