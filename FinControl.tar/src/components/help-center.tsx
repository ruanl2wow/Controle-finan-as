'use client'

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion'
import { 
  Search, 
  BookOpen, 
  Video, 
  MessageCircle, 
  Mail, 
  Phone,
  ExternalLink,
  ChevronRight,
  Star,
  Clock,
  Users
} from 'lucide-react'

const faqItems = [
  {
    question: "Como faço upload dos meus dados financeiros?",
    answer: "Vá para a aba 'Upload' e selecione o arquivo CSV ou OFX do seu banco. O sistema irá processar automaticamente suas transações.",
    category: "Upload",
    popular: true
  },
  {
    question: "Meus dados estão seguros?",
    answer: "Sim! Todos os seus dados são criptografados e armazenados localmente. Utilizamos criptografia de ponta a ponta e nunca compartilhamos suas informações.",
    category: "Segurança",
    popular: true
  },
  {
    question: "Como funciona a categorização automática?",
    answer: "Nossa IA analisa suas transações e as categoriza automaticamente com base na descrição e histórico. Você pode criar regras personalizadas para melhorar a precisão.",
    category: "Recursos",
    popular: false
  },
  {
    question: "Posso exportar meus dados?",
    answer: "Sim! Na aba 'Exportar Dados' você pode exportar suas informações em vários formatos como CSV, PDF e Excel.",
    category: "Exportação",
    popular: false
  },
  {
    question: "Como configuro metas e orçamentos?",
    answer: "Acesse a aba 'Metas e Orçamentos' para definir limites de gastos por categoria e metas de economia. O sistema irá alertar você quando estiver próximo dos limites.",
    category: "Metas",
    popular: true
  },
  {
    question: "O sistema suporta múltiplos bancos?",
    answer: "Sim! Você pode conectar múltiplas contas de diferentes bancos. O sistema irá consolidar todas as informações em um único dashboard.",
    category: "Integração",
    popular: false
  }
]

const tutorialVideos = [
  {
    title: "Primeiros Passos",
    description: "Aprenda a configurar sua conta e fazer o primeiro upload",
    duration: "5:30",
    thumbnail: "📹",
    level: "Iniciante"
  },
  {
    title: "Análise Avançada",
    description: "Explore nossos recursos de análise e relatórios",
    duration: "8:15",
    thumbnail: "📊",
    level: "Intermediário"
  },
  {
    title: "Configurando Metas",
    description: "Defina metas financeiras e acompanhe seu progresso",
    duration: "6:45",
    thumbnail: "🎯",
    level: "Iniciante"
  }
]

const contactOptions = [
  {
    icon: MessageCircle,
    title: "Chat ao Vivo",
    description: "Fale com nossa equipe em tempo útil",
    availability: "Seg-Sex, 9h-18h",
    action: "Iniciar Chat",
    color: "text-green-600"
  },
  {
    icon: Mail,
    title: "E-mail",
    description: "Envie suas dúvidas por e-mail",
    availability: "Resposta em 24h",
    action: "Enviar E-mail",
    color: "text-blue-600"
  },
  {
    icon: Phone,
    title: "Telefone",
    description: "Suporte telefônico prioritário",
    availability: "Seg-Sex, 9h-17h",
    action: "Ligar Agora",
    color: "text-purple-600"
  }
]

export function HelpCenter() {
  const [searchQuery, setSearchQuery] = useState('')
  const [selectedCategory, setSelectedCategory] = useState('Todos')

  const filteredFAQ = faqItems.filter(item => {
    const matchesSearch = item.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         item.answer.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesCategory = selectedCategory === 'Todos' || item.category === selectedCategory
    return matchesSearch && matchesCategory
  })

  const categories = ['Todos', ...Array.from(new Set(faqItems.map(item => item.category)))]

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="text-center space-y-4">
        <h1 className="text-3xl font-bold tracking-tight">Central de Ajuda</h1>
        <p className="text-muted-foreground max-w-2xl mx-auto">
          Encontre respostas rápidas, tutoriais e entre em contato com nossa equipe de suporte
        </p>
      </div>

      {/* Search Bar */}
      <Card className="max-w-2xl mx-auto">
        <CardContent className="pt-6">
          <div className="relative">
            <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Buscar por palavras-chave..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
        </CardContent>
      </Card>

      {/* Quick Stats */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center space-x-2">
              <BookOpen className="h-5 w-5 text-blue-500" />
              <div>
                <p className="text-2xl font-bold">{faqItems.length}</p>
                <p className="text-sm text-muted-foreground">Artigos</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center space-x-2">
              <Video className="h-5 w-5 text-green-500" />
              <div>
                <p className="text-2xl font-bold">{tutorialVideos.length}</p>
                <p className="text-sm text-muted-foreground">Vídeos</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center space-x-2">
              <Users className="h-5 w-5 text-purple-500" />
              <div>
                <p className="text-2xl font-bold">24/7</p>
                <p className="text-sm text-muted-foreground">Suporte</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center space-x-2">
              <Star className="h-5 w-5 text-yellow-500" />
              <div>
                <p className="text-2xl font-bold">4.9</p>
                <p className="text-sm text-muted-foreground">Avaliação</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content Grid */}
      <div className="grid gap-6 lg:grid-cols-3">
        {/* FAQ Section */}
        <div className="lg:col-span-2 space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BookOpen className="h-5 w-5" />
                Perguntas Frequentes
              </CardTitle>
              <CardDescription>
                Encontre respostas para as dúvidas mais comuns
              </CardDescription>
            </CardHeader>
            <CardContent>
              {/* Category Filter */}
              <div className="flex flex-wrap gap-2 mb-6">
                {categories.map((category) => (
                  <Button
                    key={category}
                    variant={selectedCategory === category ? "default" : "outline"}
                    size="sm"
                    onClick={() => setSelectedCategory(category)}
                  >
                    {category}
                  </Button>
                ))}
              </div>

              {/* FAQ Accordion */}
              <Accordion type="single" collapsible className="space-y-2">
                {filteredFAQ.map((item, index) => (
                  <AccordionItem key={index} value={`item-${index}`} className="border rounded-lg px-4">
                    <AccordionTrigger className="hover:no-underline">
                      <div className="flex items-center justify-between w-full mr-4">
                        <span className="text-left font-medium">{item.question}</span>
                        <div className="flex items-center gap-2">
                          {item.popular && (
                            <Badge variant="secondary" className="text-xs">
                              Popular
                            </Badge>
                          )}
                          <Badge variant="outline" className="text-xs">
                            {item.category}
                          </Badge>
                        </div>
                      </div>
                    </AccordionTrigger>
                    <AccordionContent className="text-muted-foreground">
                      {item.answer}
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>

              {filteredFAQ.length === 0 && (
                <div className="text-center py-8 text-muted-foreground">
                  <Search className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>Nenhum resultado encontrado para "{searchQuery}"</p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Video Tutorials */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Video className="h-5 w-5" />
                Tutoriais em Vídeo
              </CardTitle>
              <CardDescription>
                Aprenda a usar nossos recursos com vídeos curtos
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4">
                {tutorialVideos.map((video, index) => (
                  <div key={index} className="flex items-center space-x-4 p-4 border rounded-lg hover:bg-muted/50 transition-colors cursor-pointer">
                    <div className="text-3xl">{video.thumbnail}</div>
                    <div className="flex-1">
                      <h4 className="font-medium">{video.title}</h4>
                      <p className="text-sm text-muted-foreground">{video.description}</p>
                      <div className="flex items-center gap-4 mt-2">
                        <span className="text-xs text-muted-foreground flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          {video.duration}
                        </span>
                        <Badge variant="outline" className="text-xs">
                          {video.level}
                        </Badge>
                      </div>
                    </div>
                    <ChevronRight className="h-4 w-4 text-muted-foreground" />
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Contact Section */}
        <div className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Entre em Contato</CardTitle>
              <CardDescription>
                Precisa de ajuda personalizada?
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {contactOptions.map((option, index) => {
                const Icon = option.icon
                return (
                  <div key={index} className="p-4 border rounded-lg hover:bg-muted/50 transition-colors">
                    <div className="flex items-start space-x-3">
                      <Icon className={`h-5 w-5 mt-0.5 ${option.color}`} />
                      <div className="flex-1">
                        <h4 className="font-medium">{option.title}</h4>
                        <p className="text-sm text-muted-foreground">{option.description}</p>
                        <p className="text-xs text-muted-foreground mt-1">{option.availability}</p>
                        <Button variant="outline" size="sm" className="mt-2">
                          {option.action}
                          <ExternalLink className="h-3 w-3 ml-1" />
                        </Button>
                      </div>
                    </div>
                  </div>
                )
              })}
            </CardContent>
          </Card>

          {/* Quick Links */}
          <Card>
            <CardHeader>
              <CardTitle>Links Rápidos</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button variant="ghost" className="w-full justify-between" asChild>
                <span>
                  Documentação Completa
                  <ExternalLink className="h-4 w-4" />
                </span>
              </Button>
              <Button variant="ghost" className="w-full justify-between" asChild>
                <span>
                  Guia de Integração
                  <ExternalLink className="h-4 w-4" />
                </span>
              </Button>
              <Button variant="ghost" className="w-full justify-between" asChild>
                <span>
                  Comunidade
                  <ExternalLink className="h-4 w-4" />
                </span>
              </Button>
              <Button variant="ghost" className="w-full justify-between" asChild>
                <span>
                  Status do Sistema
                  <ExternalLink className="h-4 w-4" />
                </span>
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}