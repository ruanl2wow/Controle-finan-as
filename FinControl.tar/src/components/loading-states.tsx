'use client'

import { useState, useEffect } from 'react'
import { Loader2, RefreshCw } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Skeleton } from '@/components/ui/skeleton'
import { Card, CardContent, CardHeader } from '@/components/ui/card'

// Loading skeleton for dashboard cards
export function DashboardCardSkeleton() {
  return (
    <Card>
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <div className="space-y-2">
            <Skeleton className="h-4 w-20" />
            <Skeleton className="h-8 w-32" />
          </div>
          <Skeleton className="h-8 w-8 rounded-full" />
        </div>
      </CardContent>
    </Card>
  )
}

// Loading skeleton for transaction table
export function TransactionTableSkeleton({ rows = 10 }: { rows?: number }) {
  return (
    <Card>
      <CardHeader>
        <Skeleton className="h-6 w-32" />
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {Array.from({ length: rows }).map((_, i) => (
            <div key={i} className="flex items-center space-x-4 p-2">
              <Skeleton className="h-4 w-4" />
              <Skeleton className="h-4 w-20" />
              <Skeleton className="h-4 w-48" />
              <Skeleton className="h-4 w-24" />
              <Skeleton className="h-4 w-20" />
              <Skeleton className="h-4 w-16 justify-self-end" />
              <Skeleton className="h-8 w-8" />
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}

// Loading skeleton for categories
export function CategoryGridSkeleton({ items = 8 }: { items?: number }) {
  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      {Array.from({ length: items }).map((_, i) => (
        <Card key={i}>
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <Skeleton className="h-10 w-10 rounded-full" />
              <div className="space-y-2">
                <Skeleton className="h-4 w-24" />
                <Skeleton className="h-3 w-16" />
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}

// Loading spinner component
export function LoadingSpinner({ size = 'sm', text }: { size?: 'sm' | 'md' | 'lg'; text?: string }) {
  const sizeClasses = {
    sm: 'h-4 w-4',
    md: 'h-6 w-6',
    lg: 'h-8 w-8'
  }

  return (
    <div className="flex items-center space-x-2">
      <Loader2 className={`animate-spin ${sizeClasses[size]}`} />
      {text && <span className="text-sm text-muted-foreground">{text}</span>}
    </div>
  )
}

// Full page loading
export function FullPageLoading({ text = 'Carregando...' }: { text?: string }) {
  return (
    <div className="flex min-h-screen items-center justify-center">
      <div className="text-center space-y-4">
        <Loader2 className="mx-auto h-12 w-12 animate-spin" />
        <p className="text-lg text-muted-foreground">{text}</p>
      </div>
    </div>
  )
}

// Inline loading for buttons
export function LoadingButton({ 
  children, 
  loading, 
  ...props 
}: { 
  children: React.ReactNode
  loading: boolean
} & React.ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <Button disabled={loading} {...props}>
      {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
      {children}
    </Button>
  )
}

// Loading overlay for cards
export function LoadingOverlay({ loading, text }: { loading: boolean; text?: string }) {
  if (!loading) return null

  return (
    <div className="absolute inset-0 flex items-center justify-center bg-background/80 backdrop-blur-sm z-10 rounded-lg">
      <div className="text-center space-y-2">
        <Loader2 className="mx-auto h-6 w-6 animate-spin" />
        {text && <p className="text-sm text-muted-foreground">{text}</p>}
      </div>
    </div>
  )
}

// Progress loading for file uploads
export function ProgressLoading({ 
  progress, 
  text 
}: { 
  progress: number
  text?: string 
}) {
  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between text-sm">
        <span>{text || 'Processando...'}</span>
        <span>{Math.round(progress)}%</span>
      </div>
      <div className="w-full bg-secondary rounded-full h-2">
        <div 
          className="bg-primary h-2 rounded-full transition-all duration-300 ease-out"
          style={{ width: `${progress}%` }}
        />
      </div>
    </div>
  )
}

// Skeleton for charts
export function ChartSkeleton({ height = 300 }: { height?: number }) {
  return (
    <Card>
      <CardHeader>
        <Skeleton className="h-6 w-32" />
      </CardHeader>
      <CardContent>
        <Skeleton 
          className="w-full" 
          style={{ height: `${height}px` }}
        />
      </CardContent>
    </Card>
  )
}

// Error state with retry
export function ErrorState({ 
  error, 
  onRetry, 
  retryText = 'Tentar novamente' 
}: { 
  error: string
  onRetry?: () => void
  retryText?: string 
}) {
  return (
    <Card className="border-destructive/50 bg-destructive/5">
      <CardContent className="p-6 text-center">
        <div className="space-y-4">
          <div className="text-destructive">
            <p className="font-medium">Erro</p>
            <p className="text-sm text-muted-foreground">{error}</p>
          </div>
          {onRetry && (
            <Button variant="outline" onClick={onRetry}>
              <RefreshCw className="mr-2 h-4 w-4" />
              {retryText}
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  )
}

// Empty state
export function EmptyState({ 
  title, 
  description, 
  action 
}: { 
  title: string
  description: string
  action?: React.ReactNode 
}) {
  return (
    <Card>
      <CardContent className="p-6 text-center">
        <div className="space-y-4">
          <div className="text-muted-foreground">
            <p className="font-medium text-foreground">{title}</p>
            <p className="text-sm">{description}</p>
          </div>
          {action}
        </div>
      </CardContent>
    </Card>
  )
}

// Lazy loading wrapper component
export function LazyLoad({ 
  children, 
  fallback, 
  delay = 200 
}: { 
  children: React.ReactNode
  fallback?: React.ReactNode
  delay?: number 
}) {
  const [show, setShow] = useState(false)

  useEffect(() => {
    const timer = setTimeout(() => setShow(true), delay)
    return () => clearTimeout(timer)
  }, [delay])

  if (!show) {
    return fallback || <LoadingSpinner />
  }

  return <>{children}</>
}

// Staggered loading for lists
export function StaggeredLoading<T>({ 
  items, 
  renderItem, 
  renderItemSkeleton,
  staggerDelay = 100 
}: { 
  items: T[]
  renderItem: (item: T, index: number) => React.ReactNode
  renderItemSkeleton: (index: number) => React.ReactNode
  staggerDelay?: number 
}) {
  const [visibleItems, setVisibleItems] = useState(0)

  useEffect(() => {
    if (visibleItems < items.length) {
      const timer = setTimeout(() => {
        setVisibleItems(prev => prev + 1)
      }, staggerDelay)
      return () => clearTimeout(timer)
    }
  }, [visibleItems, items.length, staggerDelay])

  return (
    <>
      {items.slice(0, visibleItems).map((item, index) => renderItem(item, index))}
      {items.slice(visibleItems).map((_, index) => 
        renderItemSkeleton(visibleItems + index)
      )}
    </>
  )
}