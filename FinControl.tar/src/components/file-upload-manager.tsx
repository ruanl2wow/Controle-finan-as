'use client'

import { useState, useCallback } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'
import { Badge } from '@/components/ui/badge'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { 
  Upload, 
  FileText, 
  CheckCircle, 
  XCircle, 
  Clock, 
  AlertCircle,
  Download,
  Trash2,
  RefreshCw
} from 'lucide-react'
import { useDropzone } from 'react-dropzone'

interface FileUpload {
  id: string
  filename: string
  originalName: string
  fileType: string
  fileSize: number
  status: 'pending' | 'processing' | 'completed' | 'error'
  processedAt?: Date
  error?: string
  transactionCount?: number
  createdAt: Date
}

export function FileUploadManager() {
  const [uploads, setUploads] = useState<FileUpload[]>([
    {
      id: '1',
      filename: '1718456400000-extrato-junho.csv',
      originalName: 'extrato-junho.csv',
      fileType: 'csv',
      fileSize: 15420,
      status: 'completed',
      processedAt: new Date('2024-06-15T10:30:00'),
      transactionCount: 47,
      createdAt: new Date('2024-06-15T10:25:00')
    },
    {
      id: '2',
      filename: '1718456300000-cartao-credito.ofx',
      originalName: 'cartao-credito.ofx',
      fileType: 'ofx',
      fileSize: 8750,
      status: 'processing',
      createdAt: new Date('2024-06-15T10:20:00')
    },
    {
      id: '3',
      filename: '1718456200000-fatura.pdf',
      originalName: 'fatura.pdf',
      fileType: 'pdf',
      fileSize: 24500,
      status: 'error',
      error: 'PDF processing not yet implemented. Please use CSV, OFX, or QIF files.',
      createdAt: new Date('2024-06-15T10:15:00')
    }
  ])

  const [selectedAccount, setSelectedAccount] = useState<string>('')
  const [uploadProgress, setUploadProgress] = useState(0)
  const [isUploading, setIsUploading] = useState(false)

  const onDrop = useCallback(async (acceptedFiles: File[]) => {
    if (acceptedFiles.length === 0) return

    setIsUploading(true)
    setUploadProgress(0)

    for (const file of acceptedFiles) {
      try {
        const formData = new FormData()
        formData.append('file', file)
        if (selectedAccount) {
          formData.append('accountId', selectedAccount)
        }

        // Simulate upload progress
        const progressInterval = setInterval(() => {
          setUploadProgress(prev => {
            if (prev >= 90) {
              clearInterval(progressInterval)
              return 90
            }
            return prev + 10
          })
        }, 200)

        const response = await fetch('/api/upload', {
          method: 'POST',
          body: formData,
        })

        clearInterval(progressInterval)
        setUploadProgress(100)

        if (!response.ok) {
          throw new Error('Upload failed')
        }

        const result = await response.json()
        
        // Add to uploads list
        const newUpload: FileUpload = {
          id: result.uploadId,
          filename: `${Date.now()}-${result.filename}`,
          originalName: result.filename,
          fileType: result.type,
          fileSize: result.size,
          status: result.status,
          createdAt: new Date()
        }

        setUploads(prev => [newUpload, ...prev])

        // Start polling for status updates
        pollUploadStatus(result.uploadId)

      } catch (error) {
        console.error('Upload error:', error)
      }
    }

    setTimeout(() => {
      setIsUploading(false)
      setUploadProgress(0)
    }, 1000)
  }, [selectedAccount])

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'text/csv': ['.csv'],
      'application/xml': ['.ofx'],
      'application/ofx': ['.ofx'],
      'application/qif': ['.qif'],
      'application/pdf': ['.pdf']
    },
    multiple: true
  })

  const pollUploadStatus = async (uploadId: string) => {
    const poll = async () => {
      try {
        const response = await fetch('/api/upload')
        const data = await response.json()
        
        const updatedUpload = data.uploads.find((u: FileUpload) => u.id === uploadId)
        if (updatedUpload) {
          setUploads(prev => 
            prev.map(u => u.id === uploadId ? { ...u, ...updatedUpload } : u)
          )

          // Stop polling if completed or error
          if (updatedUpload.status === 'completed' || updatedUpload.status === 'error') {
            return
          }
        }

        // Continue polling
        setTimeout(poll, 2000)
      } catch (error) {
        console.error('Polling error:', error)
      }
    }

    setTimeout(poll, 1000)
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="h-4 w-4 text-green-500" />
      case 'processing':
        return <RefreshCw className="h-4 w-4 text-blue-500 animate-spin" />
      case 'error':
        return <XCircle className="h-4 w-4 text-red-500" />
      default:
        return <Clock className="h-4 w-4 text-yellow-500" />
    }
  }

  const getStatusBadge = (status: string) => {
    const variants: { [key: string]: 'default' | 'secondary' | 'destructive' | 'outline' } = {
      completed: 'default',
      processing: 'secondary',
      error: 'destructive',
      pending: 'outline'
    }

    const labels: { [key: string]: string } = {
      completed: 'Concluído',
      processing: 'Processando',
      error: 'Erro',
      pending: 'Pendente'
    }

    return (
      <Badge variant={variants[status] || 'outline'}>
        {labels[status] || status}
      </Badge>
    )
  }

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes'
    const k = 1024
    const sizes = ['Bytes', 'KB', 'MB', 'GB']
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i]
  }

  const deleteUpload = async (uploadId: string) => {
    try {
      await fetch(`/api/upload/${uploadId}`, { method: 'DELETE' })
      setUploads(prev => prev.filter(u => u.id !== uploadId))
    } catch (error) {
      console.error('Delete error:', error)
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">Upload de Arquivos</h2>
        <p className="text-muted-foreground">
          Importe extratos bancários em CSV, OFX, QIF ou PDF
        </p>
      </div>

      {/* Upload Area */}
      <Card>
        <CardHeader>
          <CardTitle>Novo Upload</CardTitle>
          <CardDescription>
            Arraste arquivos ou clique para selecionar. Formatos suportados: CSV, OFX, QIF, PDF
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium mb-2 block">Conta Bancária</label>
              <Select value={selectedAccount} onValueChange={setSelectedAccount}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione uma conta (opcional)" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="acc1">Conta Corrente - Banco do Brasil</SelectItem>
                  <SelectItem value="acc2">Cartão de Crédito - Nubank</SelectItem>
                  <SelectItem value="acc3">Poupança - Caixa</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div
              {...getRootProps()}
              className={`border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-colors ${
                isDragActive 
                  ? 'border-primary bg-primary/5' 
                  : 'border-muted-foreground/25 hover:border-primary/50'
              } ${isUploading ? 'pointer-events-none opacity-50' : ''}`}
            >
              <input {...getInputProps()} />
              <Upload className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
              {isDragActive ? (
                <p className="text-lg font-medium">Solte os arquivos aqui...</p>
              ) : (
                <div>
                  <p className="text-lg font-medium mb-2">
                    {isUploading ? 'Enviando arquivos...' : 'Arraste arquivos ou clique para selecionar'}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    CSV, OFX, QIF, PDF (máx. 10MB por arquivo)
                  </p>
                </div>
              )}
            </div>

            {isUploading && (
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Progresso do upload</span>
                  <span>{uploadProgress}%</span>
                </div>
                <Progress value={uploadProgress} className="h-2" />
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Upload History */}
      <Card>
        <CardHeader>
          <CardTitle>Histórico de Uploads</CardTitle>
          <CardDescription>
            Acompanhe o status dos seus arquivos enviados
          </CardDescription>
        </CardHeader>
        <CardContent>
          {uploads.length === 0 ? (
            <div className="text-center py-8">
              <FileText className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
              <h3 className="text-lg font-semibold mb-2">Nenhum upload ainda</h3>
              <p className="text-muted-foreground">
                Envie seu primeiro arquivo para começar a importar transações.
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {uploads.map((upload) => (
                <div key={upload.id} className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex items-center space-x-4">
                    <div className="p-2 bg-muted rounded">
                      <FileText className="h-5 w-5" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <p className="font-medium">{upload.originalName}</p>
                        {getStatusBadge(upload.status)}
                      </div>
                      <div className="flex items-center gap-4 text-sm text-muted-foreground">
                        <span>{formatFileSize(upload.fileSize)}</span>
                        <span>{upload.fileType.toUpperCase()}</span>
                        <span>
                          {upload.createdAt.toLocaleDateString('pt-BR')} às{' '}
                          {upload.createdAt.toLocaleTimeString('pt-BR', { 
                            hour: '2-digit', 
                            minute: '2-digit' 
                          })}
                        </span>
                        {upload.transactionCount && (
                          <span>{upload.transactionCount} transações</span>
                        )}
                      </div>
                      {upload.error && (
                        <div className="flex items-center gap-2 mt-2 text-sm text-red-600">
                          <AlertCircle className="h-4 w-4" />
                          <span>{upload.error}</span>
                        </div>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {getStatusIcon(upload.status)}
                    <Button 
                      variant="ghost" 
                      size="sm"
                      onClick={() => deleteUpload(upload.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}