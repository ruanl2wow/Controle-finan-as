'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { 
  Brain, 
  Sparkles, 
  CheckCircle, 
  AlertCircle, 
  Loader2,
  Eye,
  EyeOff
} from 'lucide-react'
import { toast } from 'sonner'

interface Transaction {
  id: string
  description: string
  amount: number
  type: string
  date: string
  category?: string
  subcategory?: string
  aiCategorized?: boolean
  aiConfidence?: number
  aiReasoning?: string
}

interface AICategorizationProps {
  transactions: Transaction[]
  onCategorizationComplete?: (updatedTransactions: Transaction[]) => void
}

export function AICategorization({ transactions, onCategorizationComplete }: AICategorizationProps) {
  const [isCategorizing, setIsCategorizing] = useState(false)
  const [progress, setProgress] = useState(0)
  const [results, setResults] = useState<any>(null)
  const [showReasoning, setShowReasoning] = useState(false)

  const uncategorizedTransactions = transactions.filter(t => !t.aiCategorized)
  const categorizedCount = transactions.filter(t => t.aiCategorized).length
  const totalCount = transactions.length

  const handleCategorize = async () => {
    if (uncategorizedTransactions.length === 0) {
      toast.info('Não há transações para categorizar')
      return
    }

    setIsCategorizing(true)
    setProgress(0)

    try {
      // Simulate progress
      const progressInterval = setInterval(() => {
        setProgress(prev => {
          if (prev >= 90) {
            clearInterval(progressInterval)
            return 90
          }
          return prev + 10
        })
      }, 200)

      const response = await fetch('/api/categorize', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          transactions: uncategorizedTransactions
        })
      })

      clearInterval(progressInterval)
      setProgress(100)

      if (!response.ok) {
        const error = await response.json()
        throw new Error(error.error || 'Falha na categorização')
      }

      const data = await response.json()
      setResults(data)
      
      toast.success(`Categorização concluída! ${data.transactions.length} transações processadas`)
      
      if (onCategorizationComplete) {
        onCategorizationComplete(data.transactions)
      }

    } catch (error) {
      console.error('Categorization error:', error)
      toast.error(error instanceof Error ? error.message : 'Erro na categorização')
    } finally {
      setIsCategorizing(false)
      setTimeout(() => setProgress(0), 1000)
    }
  }

  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 0.8) return 'text-green-600'
    if (confidence >= 0.6) return 'text-yellow-600'
    return 'text-red-600'
  }

  const getConfidenceBadge = (confidence: number) => {
    if (confidence >= 0.8) return 'bg-green-100 text-green-800'
    if (confidence >= 0.6) return 'bg-yellow-100 text-yellow-800'
    return 'bg-red-100 text-red-800'
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Brain className="h-5 w-5 text-purple-500" />
            <CardTitle>Categorização com IA</CardTitle>
          </div>
          <Badge variant="outline" className="text-xs">
            {categorizedCount}/{totalCount} categorizadas
          </Badge>
        </div>
        <CardDescription>
          Use inteligência artificial para categorizar automaticamente suas transações
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Status */}
        <div className="flex items-center justify-between p-4 bg-muted/50 rounded-lg">
          <div className="flex items-center gap-3">
            <div className="relative">
              <Brain className="h-8 w-8 text-purple-500" />
              {categorizedCount > 0 && (
                <CheckCircle className="h-4 w-4 text-green-500 absolute -bottom-1 -right-1" />
              )}
            </div>
            <div>
              <p className="font-medium">Status da Categorização</p>
              <p className="text-sm text-muted-foreground">
                {uncategorizedTransactions.length === 0 
                  ? 'Todas as transações foram categorizadas'
                  : `${uncategorizedTransactions.length} transações pendentes de categorização`
                }
              </p>
            </div>
          </div>
          <div className="text-right">
            <p className="text-2xl font-bold">{Math.round((categorizedCount / totalCount) * 100)}%</p>
            <p className="text-xs text-muted-foreground">completo</p>
          </div>
        </div>

        {/* Progress */}
        {isCategorizing && (
          <div className="space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span className="flex items-center gap-2">
                <Loader2 className="h-4 w-4 animate-spin" />
                Categorizando transações...
              </span>
              <span>{progress}%</span>
            </div>
            <Progress value={progress} className="h-2" />
          </div>
        )}

        {/* Action Button */}
        <div className="flex items-center gap-2">
          <Button 
            onClick={handleCategorize}
            disabled={isCategorizing || uncategorizedTransactions.length === 0}
            className="flex-1"
          >
            {isCategorizing ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Processando...
              </>
            ) : (
              <>
                <Sparkles className="mr-2 h-4 w-4" />
                Categorizar {uncategorizedTransactions.length} Transações
              </>
            )}
          </Button>
          
          {results && (
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowReasoning(!showReasoning)}
            >
              {showReasoning ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            </Button>
          )}
        </div>

        {/* Results */}
        {results && (
          <div className="space-y-3">
            <div className="flex items-center gap-2 p-3 bg-green-50 border border-green-200 rounded-lg">
              <CheckCircle className="h-5 w-5 text-green-600" />
              <div>
                <p className="font-medium text-green-800">Categorização Concluída</p>
                <p className="text-sm text-green-600">
                  {results.transactions.length} transações processadas com sucesso
                </p>
              </div>
            </div>

            {/* Categorization Details */}
            {showReasoning && results.categorizations && (
              <div className="space-y-2 max-h-64 overflow-y-auto">
                <p className="text-sm font-medium">Detalhes da Categorização:</p>
                {results.categorizations.map((cat: any, index: number) => (
                  <div key={index} className="p-3 bg-muted/30 rounded-lg text-sm">
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-medium">{uncategorizedTransactions[index]?.description}</span>
                      <Badge className={getConfidenceBadge(cat.confidence)}>
                        {Math.round(cat.confidence * 100)}% confiança
                      </Badge>
                    </div>
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <span>{cat.category}</span>
                      <span>•</span>
                      <span>{cat.subcategory}</span>
                    </div>
                    {cat.reasoning && (
                      <p className="text-xs text-muted-foreground mt-1 italic">
                        "{cat.reasoning}"
                      </p>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Info */}
        <div className="flex items-start gap-2 p-3 bg-blue-50 border border-blue-200 rounded-lg">
          <AlertCircle className="h-4 w-4 text-blue-600 mt-0.5" />
          <div className="text-xs text-blue-700">
            <p className="font-medium mb-1">Como funciona a categorização com IA:</p>
            <ul className="space-y-1">
              <li>• Análise inteligente da descrição e valor da transação</li>
              <li>• Categorização baseada em padrões e reconhecimento de estabelecimentos</li>
              <li>• Nível de confiança para cada categorização</li>
              <li>• Você pode revisar e ajustar as categorias manualmente</li>
            </ul>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}