'use client'

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select'
import { 
  Download, 
  FileText, 
  Database, 
  Target, 
  Wallet,
  PieChart,
  Calendar,
  Filter,
  CheckCircle,
  AlertCircle
} from 'lucide-react'
import { format } from 'date-fns'
import { ptBR } from 'date-fns/locale'
import { toast } from 'sonner'

interface ExportFilters {
  startDate: string
  endDate: string
  category: string
  account: string
  type: string
}

interface ExportOption {
  id: string
  name: string
  description: string
  icon: React.ReactNode
  formats: string[]
  filters: boolean
}

export function DataExport() {
  const [exportType, setExportType] = useState('transactions')
  const [format, setFormat] = useState('excel')
  const [isExporting, setIsExporting] = useState(false)
  const [filters, setFilters] = useState<ExportFilters>({
    startDate: '',
    endDate: '',
    category: 'all',
    account: 'all',
    type: 'all'
  })

  const exportOptions: ExportOption[] = [
    {
      id: 'transactions',
      name: 'Transações',
      description: 'Exportar todas as transações com detalhes completos',
      icon: <Database className="h-5 w-5" />,
      formats: ['excel', 'csv'],
      filters: true
    },
    {
      id: 'categories',
      name: 'Categorias',
      description: 'Exportar categorias e estatísticas',
      icon: <PieChart className="h-5 w-5" />,
      formats: ['excel', 'csv'],
      filters: false
    },
    {
      id: 'goals',
      name: 'Metas',
      description: 'Exportar metas e progresso',
      icon: <Target className="h-5 w-5" />,
      formats: ['excel', 'csv'],
      filters: false
    },
    {
      id: 'budgets',
      name: 'Orçamentos',
      description: 'Exportar orçamentos e status',
      icon: <Wallet className="h-5 w-5" />,
      formats: ['excel', 'csv'],
      filters: false
    },
    {
      id: 'full',
      name: 'Backup Completo',
      description: 'Exportar todos os dados do sistema',
      icon: <Database className="h-5 w-5" />,
      formats: ['excel', 'json'],
      filters: false
    }
  ]

  const currentOption = exportOptions.find(opt => opt.id === exportType)

  const handleExport = async () => {
    setIsExporting(true)
    
    try {
      const response = await fetch('/api/export', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          format,
          exportType,
          filters: currentOption?.filters ? filters : undefined
        })
      })

      if (response.ok) {
        const blob = await response.blob()
        const url = window.URL.createObjectURL(blob)
        const a = document.createElement('a')
        a.href = url
        
        // Get filename from headers or create default
        const contentDisposition = response.headers.get('content-disposition')
        let filename = `export_${format}_${new Date().toISOString().split('T')[0]}`
        
        if (contentDisposition) {
          const filenameMatch = contentDisposition.match(/filename="?([^"]+)"?/)
          if (filenameMatch) {
            filename = filenameMatch[1]
          }
        }
        
        a.download = filename
        document.body.appendChild(a)
        a.click()
        document.body.removeChild(a)
        window.URL.revokeObjectURL(url)
        
        toast.success('Dados exportados com sucesso!')
      } else {
        const error = await response.json()
        toast.error(error.error || 'Erro ao exportar dados')
      }
    } catch (error) {
      console.error('Export error:', error)
      toast.error('Erro ao exportar dados')
    } finally {
      setIsExporting(false)
    }
  }

  const getFormatDescription = (formatValue: string) => {
    switch (formatValue) {
      case 'excel':
        return 'Planilha Excel com múltiplas abas e formatação'
      case 'csv':
        return 'Arquivo CSV compatível com Excel e outras planilhas'
      case 'json':
        return 'Arquivo JSON estruturado para integrações'
      default:
        return ''
    }
  }

  const getQuickDateRange = (range: string) => {
    const today = new Date()
    let startDate: Date
    
    switch (range) {
      case 'this-month':
        startDate = new Date(today.getFullYear(), today.getMonth(), 1)
        break
      case 'last-month':
        startDate = new Date(today.getFullYear(), today.getMonth() - 1, 1)
        break
      case 'this-year':
        startDate = new Date(today.getFullYear(), 0, 1)
        break
      case 'last-3-months':
        startDate = new Date(today.getFullYear(), today.getMonth() - 3, 1)
        break
      default:
        return
    }
    
    let endDate: Date
    if (range === 'last-month') {
      endDate = new Date(today.getFullYear(), today.getMonth(), 0)
    } else {
      endDate = today
    }
    
    setFilters(prev => ({
      ...prev,
      startDate: format(startDate, 'yyyy-MM-dd'),
      endDate: format(endDate, 'yyyy-MM-dd')
    }))
  }

  return (
    <div className="space-y-6">
      {/* Export Options */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Download className="h-5 w-5" />
            Exportar Dados
          </CardTitle>
          <CardDescription>
            Escolha o tipo de dados que deseja exportar e o formato do arquivo
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {exportOptions.map((option) => (
              <div
                key={option.id}
                className={`p-4 border rounded-lg cursor-pointer transition-colors ${
                  exportType === option.id 
                    ? 'border-primary bg-primary/5' 
                    : 'border-border hover:bg-muted/50'
                }`}
                onClick={() => setExportType(option.id)}
              >
                <div className="flex items-center gap-3 mb-2">
                  <div className={`p-2 rounded-lg ${
                    exportType === option.id ? 'bg-primary text-primary-foreground' : 'bg-muted'
                  }`}>
                    {option.icon}
                  </div>
                  <div className="flex-1">
                    <h3 className="font-medium">{option.name}</h3>
                    <p className="text-sm text-muted-foreground">
                      {option.description}
                    </p>
                  </div>
                </div>
                <div className="flex flex-wrap gap-1">
                  {option.formats.map((fmt) => (
                    <Badge key={fmt} variant="secondary" className="text-xs">
                      {fmt.toUpperCase()}
                    </Badge>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Export Configuration */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Format Selection */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5" />
              Formato de Exportação
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="format">Formato do Arquivo</Label>
              <Select value={format} onValueChange={setFormat}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {currentOption?.formats.map((fmt) => (
                    <SelectItem key={fmt} value={fmt}>
                      {fmt.toUpperCase()}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <p className="text-sm text-muted-foreground mt-2">
                {getFormatDescription(format)}
              </p>
            </div>

            <div className="p-4 bg-muted/30 rounded-lg">
              <h4 className="font-medium mb-2">Resumo da Exportação</h4>
              <div className="space-y-1 text-sm">
                <div className="flex justify-between">
                  <span>Tipo:</span>
                  <span className="font-medium">{currentOption?.name}</span>
                </div>
                <div className="flex justify-between">
                  <span>Formato:</span>
                  <span className="font-medium">{format.toUpperCase()}</span>
                </div>
                {currentOption?.filters && (
                  <div className="flex justify-between">
                    <span>Filtros:</span>
                    <span className="font-medium">
                      {(filters.startDate || filters.endDate || filters.category !== 'all' || 
                        filters.account !== 'all' || filters.type !== 'all') ? 'Aplicados' : 'Nenhum'}
                    </span>
                  </div>
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Filters */}
        {currentOption?.filters && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Filter className="h-5 w-5" />
                Filtros
              </CardTitle>
              <CardDescription>
                Refine os dados que serão exportados
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Quick Date Ranges */}
              <div>
                <Label>Período Rápido</Label>
                <div className="flex flex-wrap gap-2 mt-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => getQuickDateRange('this-month')}
                  >
                    Este Mês
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => getQuickDateRange('last-month')}
                  >
                    Mês Anterior
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => getQuickDateRange('this-year')}
                  >
                    Este Ano
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => getQuickDateRange('last-3-months')}
                  >
                    Últimos 3 Meses
                  </Button>
                </div>
              </div>

              {/* Custom Date Range */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="startDate">Data Inicial</Label>
                  <Input
                    id="startDate"
                    type="date"
                    value={filters.startDate}
                    onChange={(e) => setFilters(prev => ({ ...prev, startDate: e.target.value }))}
                  />
                </div>
                <div>
                  <Label htmlFor="endDate">Data Final</Label>
                  <Input
                    id="endDate"
                    type="date"
                    value={filters.endDate}
                    onChange={(e) => setFilters(prev => ({ ...prev, endDate: e.target.value }))}
                  />
                </div>
              </div>

              {/* Category and Type Filters */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="category">Categoria</Label>
                  <Select
                    value={filters.category}
                    onValueChange={(value) => setFilters(prev => ({ ...prev, category: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todas</SelectItem>
                      <SelectItem value="food">Alimentação</SelectItem>
                      <SelectItem value="transport">Transporte</SelectItem>
                      <SelectItem value="shopping">Compras</SelectItem>
                      <SelectItem value="bills">Contas</SelectItem>
                      <SelectItem value="entertainment">Lazer</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="type">Tipo</Label>
                  <Select
                    value={filters.type}
                    onValueChange={(value) => setFilters(prev => ({ ...prev, type: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todos</SelectItem>
                      <SelectItem value="income">Receitas</SelectItem>
                      <SelectItem value="expense">Despesas</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Account Filter */}
              <div>
                <Label htmlFor="account">Conta</Label>
                <Select
                  value={filters.account}
                  onValueChange={(value) => setFilters(prev => ({ ...prev, account: value }))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todas</SelectItem>
                    <SelectItem value="checking">Conta Corrente</SelectItem>
                    <SelectItem value="savings">Poupança</SelectItem>
                    <SelectItem value="credit">Cartão de Crédito</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Export Actions */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <h3 className="font-medium">Pronto para Exportar</h3>
              <p className="text-sm text-muted-foreground">
                {currentOption?.filters 
                  ? 'Os dados serão filtrados de acordo com sua configuração'
                  : 'Todos os dados serão exportados'
                }
              </p>
            </div>
            <Button 
              onClick={handleExport}
              disabled={isExporting}
              size="lg"
              className="flex items-center gap-2"
            >
              {isExporting ? (
                <>
                  <div className="h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent" />
                  Exportando...
                </>
              ) : (
                <>
                  <Download className="h-4 w-4" />
                  Exportar {currentOption?.name}
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Export Tips */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertCircle className="h-5 w-5" />
            Dicas de Exportação
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-3">
              <div className="flex items-start gap-3">
                <CheckCircle className="h-5 w-5 text-green-600 mt-0.5" />
                <div>
                  <h4 className="font-medium">Formato Excel</h4>
                  <p className="text-sm text-muted-foreground">
                    Ideal para análise detalhada com múltiplas abas e gráficos
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <CheckCircle className="h-5 w-5 text-green-600 mt-0.5" />
                <div>
                  <h4 className="font-medium">Formato CSV</h4>
                  <p className="text-sm text-muted-foreground">
                    Perfeito para importar em outros sistemas e planilhas
                  </p>
                </div>
              </div>
            </div>
            <div className="space-y-3">
              <div className="flex items-start gap-3">
                <CheckCircle className="h-5 w-5 text-green-600 mt-0.5" />
                <div>
                  <h4 className="font-medium">Backup Completo</h4>
                  <p className="text-sm text-muted-foreground">
                    Exporte todos os dados para manter um backup seguro
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <CheckCircle className="h-5 w-5 text-green-600 mt-0.5" />
                <div>
                  <h4 className="font-medium">Filtros Avançados</h4>
                  <p className="text-sm text-muted-foreground">
                    Use filtros para exportar apenas os dados necessários
                  </p>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}