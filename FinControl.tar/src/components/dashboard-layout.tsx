import { Sidebar } from '@/components/sidebar'
import { Header } from '@/components/header'

interface DashboardLayoutProps {
  children: React.ReactNode
}

export default function DashboardLayout({ children }: DashboardLayoutProps) {
  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar className="w-64" />
      <div className="flex flex-1 flex-col">
        <Header />
        <main className="flex-1 space-y-4 p-4 md:p-8 pt-6">
          {children}
        </main>
      </div>
    </div>
  )
}