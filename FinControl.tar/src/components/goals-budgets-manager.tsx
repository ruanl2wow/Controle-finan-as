'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select'
import { Switch } from '@/components/ui/switch'
import { Textarea } from '@/components/ui/textarea'
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from '@/components/ui/tabs'
import { 
  Target, 
  Plus, 
  Edit, 
  Trash2, 
  TrendingUp,
  TrendingDown,
  DollarSign,
  Calendar,
  AlertTriangle,
  CheckCircle,
  Clock,
  PiggyBank,
  Wallet,
  Award
} from 'lucide-react'
import { format } from 'date-fns'
import { ptBR } from 'date-fns/locale'
import { toast } from 'sonner'

interface Goal {
  id: string
  name: string
  description?: string
  targetAmount: number
  currentAmount: number
  targetDate: string
  priority: string
  status: string
  category?: string
  isActive: boolean
  progress: number
  daysRemaining: number
  isCompleted: boolean
  isOverdue: boolean
  requiredMonthly: number
  remainingAmount: number
  createdAt: string
  updatedAt: string
}

interface Budget {
  id: string
  name: string
  description?: string
  amount: number
  spent: number
  remaining: number
  percentageUsed: number
  isOverBudget: boolean
  period: string
  startDate: string
  endDate: string
  isActive: boolean
  category?: {
    id: string
    name: string
    color: string
  }
  createdAt: string
  updatedAt: string
}

export function GoalsBudgetsManager() {
  const [goals, setGoals] = useState<Goal[]>([])
  const [budgets, setBudgets] = useState<Budget[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [activeTab, setActiveTab] = useState('goals')
  const [isGoalDialogOpen, setIsGoalDialogOpen] = useState(false)
  const [isBudgetDialogOpen, setIsBudgetDialogOpen] = useState(false)
  const [editingGoal, setEditingGoal] = useState<Goal | null>(null)
  const [editingBudget, setEditingBudget] = useState<Budget | null>(null)

  useEffect(() => {
    fetchData()
  }, [activeTab])

  const fetchData = async () => {
    try {
      setIsLoading(true)
      
      if (activeTab === 'goals' || activeTab === 'overview') {
        const goalsResponse = await fetch('/api/goals')
        if (goalsResponse.ok) {
          const data = await goalsResponse.json()
          setGoals(data.goals || [])
        }
      }
      
      if (activeTab === 'budgets' || activeTab === 'overview') {
        const budgetsResponse = await fetch('/api/budgets')
        if (budgetsResponse.ok) {
          const data = await budgetsResponse.json()
          setBudgets(data.budgets || [])
        }
      }
    } catch (error) {
      console.error('Error fetching data:', error)
      toast.error('Erro ao carregar dados')
    } finally {
      setIsLoading(false)
    }
  }

  const handleCreateGoal = async (goalData: any) => {
    try {
      const response = await fetch('/api/goals', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(goalData)
      })

      if (response.ok) {
        const data = await response.json()
        setGoals(prev => [...prev, data.goal])
        toast.success('Meta criada com sucesso')
        setIsGoalDialogOpen(false)
      } else {
        const error = await response.json()
        toast.error(error.error || 'Erro ao criar meta')
      }
    } catch (error) {
      console.error('Error creating goal:', error)
      toast.error('Erro ao criar meta')
    }
  }

  const handleCreateBudget = async (budgetData: any) => {
    try {
      const response = await fetch('/api/budgets', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(budgetData)
      })

      if (response.ok) {
        const data = await response.json()
        setBudgets(prev => [...prev, data.budget])
        toast.success('Orçamento criado com sucesso')
        setIsBudgetDialogOpen(false)
      } else {
        const error = await response.json()
        toast.error(error.error || 'Erro ao criar orçamento')
      }
    } catch (error) {
      console.error('Error creating budget:', error)
      toast.error('Erro ao criar orçamento')
    }
  }

  const handleUpdateGoalProgress = async (goalId: string, amount: number, operation: string = 'add') => {
    try {
      const response = await fetch('/api/goals', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: goalId, amount, operation })
      })

      if (response.ok) {
        const data = await response.json()
        setGoals(prev => prev.map(g => g.id === goalId ? data.goal : g))
        toast.success('Progresso atualizado com sucesso')
      } else {
        const error = await response.json()
        toast.error(error.error || 'Erro ao atualizar progresso')
      }
    } catch (error) {
      console.error('Error updating goal progress:', error)
      toast.error('Erro ao atualizar progresso')
    }
  }

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value)
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'text-red-600 bg-red-50'
      case 'medium': return 'text-yellow-600 bg-yellow-50'
      case 'low': return 'text-green-600 bg-green-50'
      default: return 'text-gray-600 bg-gray-50'
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'text-green-600 bg-green-50'
      case 'active': return 'text-blue-600 bg-blue-50'
      case 'paused': return 'text-yellow-600 bg-yellow-50'
      case 'cancelled': return 'text-red-600 bg-red-50'
      default: return 'text-gray-600 bg-gray-50'
    }
  }

  const getBudgetStatusColor = (budget: Budget) => {
    if (budget.isOverBudget) return 'text-red-600 bg-red-50'
    if (budget.percentageUsed > 80) return 'text-yellow-600 bg-yellow-50'
    return 'text-green-600 bg-green-50'
  }

  const activeGoals = goals.filter(g => g.isActive && g.status === 'active')
  const completedGoals = goals.filter(g => g.status === 'completed')
  const activeBudgets = budgets.filter(b => b.isActive)
  const overBudgetBudgets = activeBudgets.filter(b => b.isOverBudget)

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Metas e Orçamentos</CardTitle>
          <CardDescription>Carregando...</CardDescription>
        </CardHeader>
      </Card>
    )
  }

  return (
    <div className="space-y-6">
      {/* Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Target className="h-8 w-8 text-blue-500" />
              <div>
                <p className="text-sm text-muted-foreground">Metas Ativas</p>
                <p className="text-2xl font-bold">{activeGoals.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <CheckCircle className="h-8 w-8 text-green-500" />
              <div>
                <p className="text-sm text-muted-foreground">Metas Concluídas</p>
                <p className="text-2xl font-bold">{completedGoals.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Wallet className="h-8 w-8 text-purple-500" />
              <div>
                <p className="text-sm text-muted-foreground">Orçamentos Ativos</p>
                <p className="text-2xl font-bold">{activeBudgets.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <AlertTriangle className="h-8 w-8 text-red-500" />
              <div>
                <p className="text-sm text-muted-foreground">Orçamentos Estourados</p>
                <p className="text-2xl font-bold">{overBudgetBudgets.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <div className="flex items-center justify-between">
          <TabsList>
            <TabsTrigger value="overview">Visão Geral</TabsTrigger>
            <TabsTrigger value="goals">Metas</TabsTrigger>
            <TabsTrigger value="budgets">Orçamentos</TabsTrigger>
          </TabsList>

          <div className="flex gap-2">
            {activeTab === 'goals' && (
              <Dialog open={isGoalDialogOpen} onOpenChange={setIsGoalDialogOpen}>
                <DialogTrigger asChild>
                  <Button>
                    <Plus className="mr-2 h-4 w-4" />
                    Nova Meta
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-md">
                  <DialogHeader>
                    <DialogTitle>Criar Nova Meta</DialogTitle>
                    <DialogDescription>
                      Defina um novo objetivo financeiro
                    </DialogDescription>
                  </DialogHeader>
                  <GoalForm
                    onSubmit={handleCreateGoal}
                    onCancel={() => setIsGoalDialogOpen(false)}
                  />
                </DialogContent>
              </Dialog>
            )}

            {activeTab === 'budgets' && (
              <Dialog open={isBudgetDialogOpen} onOpenChange={setIsBudgetDialogOpen}>
                <DialogTrigger asChild>
                  <Button>
                    <Plus className="mr-2 h-4 w-4" />
                    Novo Orçamento
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-md">
                  <DialogHeader>
                    <DialogTitle>Criar Novo Orçamento</DialogTitle>
                    <DialogDescription>
                      Defina um limite de gastos para uma categoria
                    </DialogDescription>
                  </DialogHeader>
                  <BudgetForm
                    onSubmit={handleCreateBudget}
                    onCancel={() => setIsBudgetDialogOpen(false)}
                  />
                </DialogContent>
              </Dialog>
            )}
          </div>
        </div>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Recent Goals */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="h-5 w-5" />
                  Metas em Andamento
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {activeGoals.slice(0, 3).map((goal) => (
                    <div key={goal.id} className="space-y-2">
                      <div className="flex items-center justify-between">
                        <div>
                          <h4 className="font-medium">{goal.name}</h4>
                          <p className="text-sm text-muted-foreground">
                            {formatCurrency(goal.currentAmount)} / {formatCurrency(goal.targetAmount)}
                          </p>
                        </div>
                        <Badge className={getPriorityColor(goal.priority)}>
                          {goal.priority}
                        </Badge>
                      </div>
                      <Progress value={goal.progress} className="h-2" />
                      <div className="flex items-center justify-between text-xs text-muted-foreground">
                        <span>{goal.progress.toFixed(1)}% completo</span>
                        <span>{goal.daysRemaining} dias restantes</span>
                      </div>
                    </div>
                  ))}
                  {activeGoals.length === 0 && (
                    <p className="text-center text-muted-foreground py-4">
                      Nenhuma meta ativa no momento
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Budget Status */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Wallet className="h-5 w-5" />
                  Status dos Orçamentos
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {activeBudgets.slice(0, 3).map((budget) => (
                    <div key={budget.id} className="space-y-2">
                      <div className="flex items-center justify-between">
                        <div>
                          <h4 className="font-medium">{budget.name}</h4>
                          <p className="text-sm text-muted-foreground">
                            {formatCurrency(budget.spent)} / {formatCurrency(budget.amount)}
                          </p>
                        </div>
                        <Badge className={getBudgetStatusColor(budget)}>
                          {budget.percentageUsed.toFixed(0)}%
                        </Badge>
                      </div>
                      <Progress 
                        value={Math.min(100, budget.percentageUsed)} 
                        className={`h-2 ${budget.isOverBudget ? 'bg-red-100' : ''}`}
                      />
                      <div className="flex items-center justify-between text-xs text-muted-foreground">
                        <span>Restante: {formatCurrency(budget.remaining)}</span>
                        <span>{budget.period}</span>
                      </div>
                    </div>
                  ))}
                  {activeBudgets.length === 0 && (
                    <p className="text-center text-muted-foreground py-4">
                      Nenhum orçamento ativo no momento
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="goals" className="space-y-4">
          <GoalsList 
            goals={goals} 
            onUpdateProgress={handleUpdateGoalProgress}
            onRefresh={fetchData}
          />
        </TabsContent>

        <TabsContent value="budgets" className="space-y-4">
          <BudgetsList 
            budgets={budgets}
            onRefresh={fetchData}
          />
        </TabsContent>
      </Tabs>
    </div>
  )
}

// Goal Form Component
function GoalForm({ 
  onSubmit, 
  onCancel 
}: { 
  onSubmit: (data: any) => void
  onCancel: () => void 
}) {
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    targetAmount: '',
    currentAmount: '0',
    targetDate: '',
    priority: 'medium',
    category: 'savings',
    isActive: true
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    onSubmit({
      ...formData,
      targetAmount: parseFloat(formData.targetAmount),
      currentAmount: parseFloat(formData.currentAmount)
    })
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <Label htmlFor="name">Nome da Meta</Label>
        <Input
          id="name"
          value={formData.name}
          onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
          placeholder="Ex: Fundo de Emergência"
          required
        />
      </div>

      <div>
        <Label htmlFor="description">Descrição (opcional)</Label>
        <Textarea
          id="description"
          value={formData.description}
          onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
          placeholder="Descreva sua meta..."
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="targetAmount">Valor Alvo</Label>
          <Input
            id="targetAmount"
            type="number"
            step="0.01"
            value={formData.targetAmount}
            onChange={(e) => setFormData(prev => ({ ...prev, targetAmount: e.target.value }))}
            placeholder="R$ 0,00"
            required
          />
        </div>
        <div>
          <Label htmlFor="currentAmount">Valor Atual</Label>
          <Input
            id="currentAmount"
            type="number"
            step="0.01"
            value={formData.currentAmount}
            onChange={(e) => setFormData(prev => ({ ...prev, currentAmount: e.target.value }))}
            placeholder="R$ 0,00"
          />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="targetDate">Data Alvo</Label>
          <Input
            id="targetDate"
            type="date"
            value={formData.targetDate}
            onChange={(e) => setFormData(prev => ({ ...prev, targetDate: e.target.value }))}
            required
          />
        </div>
        <div>
          <Label htmlFor="priority">Prioridade</Label>
          <Select
            value={formData.priority}
            onValueChange={(value) => setFormData(prev => ({ ...prev, priority: value }))}
          >
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="high">Alta</SelectItem>
              <SelectItem value="medium">Média</SelectItem>
              <SelectItem value="low">Baixa</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div>
        <Label htmlFor="category">Categoria</Label>
        <Select
          value={formData.category}
          onValueChange={(value) => setFormData(prev => ({ ...prev, category: value }))}
        >
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="savings">Poupança</SelectItem>
            <SelectItem value="investment">Investimento</SelectItem>
            <SelectItem value="debt_payment">Pagamento de Dívida</SelectItem>
            <SelectItem value="purchase">Compra</SelectItem>
            <SelectItem value="other">Outro</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="flex items-center gap-2">
        <Switch
          id="isActive"
          checked={formData.isActive}
          onCheckedChange={(checked) => setFormData(prev => ({ ...prev, isActive: checked }))}
        />
        <Label htmlFor="isActive">Meta ativa</Label>
      </div>

      <div className="flex justify-end gap-2">
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancelar
        </Button>
        <Button type="submit">
          Criar Meta
        </Button>
      </div>
    </form>
  )
}

// Budget Form Component
function BudgetForm({ 
  onSubmit, 
  onCancel 
}: { 
  onSubmit: (data: any) => void
  onCancel: () => void 
}) {
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    amount: '',
    period: 'monthly',
    startDate: '',
    endDate: '',
    isActive: true
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    onSubmit({
      ...formData,
      amount: parseFloat(formData.amount)
    })
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <Label htmlFor="name">Nome do Orçamento</Label>
        <Input
          id="name"
          value={formData.name}
          onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
          placeholder="Ex: Alimentação Mensal"
          required
        />
      </div>

      <div>
        <Label htmlFor="description">Descrição (opcional)</Label>
        <Textarea
          id="description"
          value={formData.description}
          onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
          placeholder="Descreva seu orçamento..."
        />
      </div>

      <div>
        <Label htmlFor="amount">Valor do Orçamento</Label>
        <Input
          id="amount"
          type="number"
          step="0.01"
          value={formData.amount}
          onChange={(e) => setFormData(prev => ({ ...prev, amount: e.target.value }))}
          placeholder="R$ 0,00"
          required
        />
      </div>

      <div>
        <Label htmlFor="period">Período</Label>
        <Select
          value={formData.period}
          onValueChange={(value) => setFormData(prev => ({ ...prev, period: value }))}
        >
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="weekly">Semanal</SelectItem>
            <SelectItem value="monthly">Mensal</SelectItem>
            <SelectItem value="yearly">Anual</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="startDate">Data de Início</Label>
          <Input
            id="startDate"
            type="date"
            value={formData.startDate}
            onChange={(e) => setFormData(prev => ({ ...prev, startDate: e.target.value }))}
            required
          />
        </div>
        <div>
          <Label htmlFor="endDate">Data de Término</Label>
          <Input
            id="endDate"
            type="date"
            value={formData.endDate}
            onChange={(e) => setFormData(prev => ({ ...prev, endDate: e.target.value }))}
            required
          />
        </div>
      </div>

      <div className="flex items-center gap-2">
        <Switch
          id="isActive"
          checked={formData.isActive}
          onCheckedChange={(checked) => setFormData(prev => ({ ...prev, isActive: checked }))}
        />
        <Label htmlFor="isActive">Orçamento ativo</Label>
      </div>

      <div className="flex justify-end gap-2">
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancelar
        </Button>
        <Button type="submit">
          Criar Orçamento
        </Button>
      </div>
    </form>
  )
}

// Goals List Component
function GoalsList({ 
  goals, 
  onUpdateProgress, 
  onRefresh 
}: { 
  goals: Goal[]
  onUpdateProgress: (id: string, amount: number, operation?: string) => void
  onRefresh: () => void
}) {
  const [updateAmount, setUpdateAmount] = useState<{ [key: string]: string }>({})

  const handleUpdateProgress = (goalId: string) => {
    const amount = parseFloat(updateAmount[goalId] || '0')
    if (amount > 0) {
      onUpdateProgress(goalId, amount)
      setUpdateAmount(prev => ({ ...prev, [goalId]: '' }))
    }
  }

  return (
    <div className="space-y-4">
      {goals.map((goal) => (
        <Card key={goal.id}>
          <CardContent className="p-6">
            <div className="flex items-start justify-between mb-4">
              <div>
                <h3 className="text-lg font-semibold">{goal.name}</h3>
                {goal.description && (
                  <p className="text-sm text-muted-foreground mt-1">{goal.description}</p>
                )}
              </div>
              <div className="flex items-center gap-2">
                <Badge className={goal.isCompleted ? 'bg-green-100 text-green-800' : 'bg-blue-100 text-blue-800'}>
                  {goal.status}
                </Badge>
                <Badge className={goal.priority === 'high' ? 'bg-red-100 text-red-800' : 
                               goal.priority === 'medium' ? 'bg-yellow-100 text-yellow-800' : 
                               'bg-green-100 text-green-800'}>
                  {goal.priority}
                </Badge>
              </div>
            </div>

            <div className="space-y-4">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium">Progresso</span>
                  <span className="text-sm text-muted-foreground">
                    {goal.progress.toFixed(1)}% • {formatCurrency(goal.currentAmount)} / {formatCurrency(goal.targetAmount)}
                  </span>
                </div>
                <Progress value={goal.progress} className="h-2" />
              </div>

              <div className="grid grid-cols-3 gap-4 text-sm">
                <div>
                  <p className="text-muted-foreground">Restante</p>
                  <p className="font-medium">{formatCurrency(goal.remainingAmount)}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Dias Restantes</p>
                  <p className="font-medium">{goal.daysRemaining}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Mensal Necessário</p>
                  <p className="font-medium">{formatCurrency(goal.requiredMonthly)}</p>
                </div>
              </div>

              {!goal.isCompleted && (
                <div className="flex items-center gap-2">
                  <Input
                    type="number"
                    step="0.01"
                    placeholder="Valor para adicionar"
                    value={updateAmount[goal.id] || ''}
                    onChange={(e) => setUpdateAmount(prev => ({ 
                      ...prev, 
                      [goal.id]: e.target.value 
                    }))}
                    className="flex-1"
                  />
                  <Button 
                    size="sm"
                    onClick={() => handleUpdateProgress(goal.id)}
                    disabled={!updateAmount[goal.id] || parseFloat(updateAmount[goal.id] || '0') <= 0}
                  >
                    Adicionar
                  </Button>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      ))}
      
      {goals.length === 0 && (
        <Card>
          <CardContent className="p-6 text-center">
            <Target className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-medium mb-2">Nenhuma meta encontrada</h3>
            <p className="text-muted-foreground">
              Crie sua primeira meta para começar a acompanhar seus objetivos financeiros
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  )
}

// Budgets List Component
function BudgetsList({ 
  budgets, 
  onRefresh 
}: { 
  budgets: Budget[]
  onRefresh: () => void
}) {
  return (
    <div className="space-y-4">
      {budgets.map((budget) => (
        <Card key={budget.id}>
          <CardContent className="p-6">
            <div className="flex items-start justify-between mb-4">
              <div>
                <h3 className="text-lg font-semibold">{budget.name}</h3>
                {budget.description && (
                  <p className="text-sm text-muted-foreground mt-1">{budget.description}</p>
                )}
                {budget.category && (
                  <div className="flex items-center gap-2 mt-2">
                    <div 
                      className="w-3 h-3 rounded-full" 
                      style={{ backgroundColor: budget.category.color }}
                    />
                    <span className="text-sm text-muted-foreground">{budget.category.name}</span>
                  </div>
                )}
              </div>
              <div className="flex items-center gap-2">
                <Badge className={budget.isOverBudget ? 'bg-red-100 text-red-800' : 
                               budget.percentageUsed > 80 ? 'bg-yellow-100 text-yellow-800' : 
                               'bg-green-100 text-green-800'}>
                  {budget.percentageUsed.toFixed(0)}% usado
                </Badge>
                <Badge variant="outline">{budget.period}</Badge>
              </div>
            </div>

            <div className="space-y-4">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium">Gastos</span>
                  <span className="text-sm text-muted-foreground">
                    {formatCurrency(budget.spent)} / {formatCurrency(budget.amount)}
                  </span>
                </div>
                <Progress 
                  value={Math.min(100, budget.percentageUsed)} 
                  className={`h-2 ${budget.isOverBudget ? 'bg-red-100' : ''}`}
                />
              </div>

              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="text-muted-foreground">Restante</p>
                  <p className={`font-medium ${budget.isOverBudget ? 'text-red-600' : 'text-green-600'}`}>
                    {formatCurrency(budget.remaining)}
                  </p>
                </div>
                <div>
                  <p className="text-muted-foreground">Período</p>
                  <p className="font-medium">
                    {format(new Date(budget.startDate), 'dd/MM/yyyy')} - {format(new Date(budget.endDate), 'dd/MM/yyyy')}
                  </p>
                </div>
              </div>

              {budget.isOverBudget && (
                <div className="flex items-center gap-2 p-3 bg-red-50 border border-red-200 rounded-lg">
                  <AlertTriangle className="h-4 w-4 text-red-600" />
                  <span className="text-sm text-red-700">
                    Orçamento estourado em {formatCurrency(Math.abs(budget.remaining))}
                  </span>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      ))}
      
      {budgets.length === 0 && (
        <Card>
          <CardContent className="p-6 text-center">
            <Wallet className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-medium mb-2">Nenhum orçamento encontrado</h3>
            <p className="text-muted-foreground">
              Crie seu primeiro orçamento para começar a controlar seus gastos
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  )
}