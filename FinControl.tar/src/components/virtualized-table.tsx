'use client'

import { useState, useEffect, useCallback, useMemo } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Checkbox } from '@/components/ui/checkbox'
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select'
import { 
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from '@/components/ui/dropdown-menu'
import { 
  Search, 
  Upload, 
  Download, 
  Filter,
  Edit,
  Trash2,
  MoreHorizontal,
  ChevronLeft,
  ChevronRight,
  Plus,
  ChevronDown,
  Loader2
} from 'lucide-react'
import { Skeleton } from '@/components/ui/skeleton'

interface Transaction {
  id: string
  date: string
  description: string
  category: string
  amount: number
  type: 'income' | 'expense'
  account: string
  tags: string[]
}

interface VirtualizedTableProps {
  transactions: Transaction[]
  categories: string[]
  accounts: string[]
  onTransactionUpdate?: (transaction: Transaction) => void
  onTransactionDelete?: (id: string) => void
  onBulkDelete?: (ids: string[]) => void
  onBulkReclassify?: (ids: string[], category: string) => void
}

const ITEM_HEIGHT = 60
const BUFFER_SIZE = 5
const VISIBLE_ITEMS = 15

export function VirtualizedTable({
  transactions,
  categories,
  accounts,
  onTransactionUpdate,
  onTransactionDelete,
  onBulkDelete,
  onBulkReclassify
}: VirtualizedTableProps) {
  const [selectedIds, setSelectedIds] = useState<string[]>([])
  const [searchTerm, setSearchTerm] = useState('')
  const [filterCategory, setFilterCategory] = useState<string>('all')
  const [filterAccount, setFilterAccount] = useState<string>('all')
  const [editingCell, setEditingCell] = useState<{ id: string; field: keyof Transaction } | null>(null)
  const [editValue, setEditValue] = useState('')
  const [scrollTop, setScrollTop] = useState(0)
  const [isLoading, setIsLoading] = useState(false)
  const [cachedTransactions, setCachedTransactions] = useState<Transaction[]>([])

  // Memoized filtered transactions
  const filteredTransactions = useMemo(() => {
    return transactions.filter(transaction => {
      const matchesSearch = transaction.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           transaction.category.toLowerCase().includes(searchTerm.toLowerCase())
      const matchesCategory = filterCategory === 'all' || transaction.category === filterCategory
      const matchesAccount = filterAccount === 'all' || transaction.account === filterAccount
      return matchesSearch && matchesCategory && matchesAccount
    })
  }, [transactions, searchTerm, filterCategory, filterAccount])

  // Virtual scrolling calculations
  const { startIndex, endIndex, visibleTransactions, totalHeight } = useMemo(() => {
    const startIndex = Math.max(0, Math.floor(scrollTop / ITEM_HEIGHT) - BUFFER_SIZE)
    const endIndex = Math.min(
      filteredTransactions.length,
      startIndex + VISIBLE_ITEMS + BUFFER_SIZE * 2
    )
    const visibleTransactions = filteredTransactions.slice(startIndex, endIndex)
    const totalHeight = filteredTransactions.length * ITEM_HEIGHT

    return { startIndex, endIndex, visibleTransactions, totalHeight }
  }, [filteredTransactions, scrollTop])

  // Performance metrics
  const performanceMetrics = useMemo(() => {
    const totalIncome = filteredTransactions
      .filter(t => t.type === 'income')
      .reduce((sum, t) => sum + t.amount, 0)

    const totalExpenses = Math.abs(filteredTransactions
      .filter(t => t.type === 'expense')
      .reduce((sum, t) => sum + t.amount, 0))

    return {
      totalIncome,
      totalExpenses,
      balance: totalIncome - totalExpenses,
      totalTransactions: filteredTransactions.length
    }
  }, [filteredTransactions])

  const handleScroll = useCallback((e: React.UIEvent<HTMLDivElement>) => {
    setScrollTop(e.currentTarget.scrollTop)
  }, [])

  const handleSelectAll = useCallback((checked: boolean) => {
    if (checked) {
      setSelectedIds(visibleTransactions.map(t => t.id))
    } else {
      setSelectedIds([])
    }
  }, [visibleTransactions])

  const handleSelectOne = useCallback((id: string, checked: boolean) => {
    if (checked) {
      setSelectedIds(prev => [...prev, id])
    } else {
      setSelectedIds(prev => prev.filter(selectedId => selectedId !== id))
    }
  }, [])

  const startEditing = useCallback((id: string, field: keyof Transaction, value: any) => {
    setEditingCell({ id, field })
    setEditValue(String(value))
  }, [])

  const saveEdit = useCallback(async () => {
    if (editingCell && onTransactionUpdate) {
      setIsLoading(true)
      try {
        const transaction = transactions.find(t => t.id === editingCell.id)
        if (transaction) {
          const updatedTransaction = { ...transaction }
          
          if (editingCell.field === 'amount') {
            updatedTransaction[editingCell.field] = parseFloat(editValue) || 0
            updatedTransaction.type = parseFloat(editValue) >= 0 ? 'income' : 'expense'
          } else {
            (updatedTransaction as any)[editingCell.field] = editValue
          }
          
          await onTransactionUpdate(updatedTransaction)
        }
      } catch (error) {
        console.error('Error updating transaction:', error)
      } finally {
        setIsLoading(false)
      }
    }
    setEditingCell(null)
    setEditValue('')
  }, [editingCell, editValue, transactions, onTransactionUpdate])

  const cancelEdit = useCallback(() => {
    setEditingCell(null)
    setEditValue('')
  }, [])

  const deleteTransaction = useCallback(async (id: string) => {
    if (onTransactionDelete) {
      setIsLoading(true)
      try {
        await onTransactionDelete(id)
        setSelectedIds(prev => prev.filter(selectedId => selectedId !== id))
      } catch (error) {
        console.error('Error deleting transaction:', error)
      } finally {
        setIsLoading(false)
      }
    }
  }, [onTransactionDelete])

  const bulkDelete = useCallback(async () => {
    if (onBulkDelete && selectedIds.length > 0) {
      setIsLoading(true)
      try {
        await onBulkDelete(selectedIds)
        setSelectedIds([])
      } catch (error) {
        console.error('Error bulk deleting transactions:', error)
      } finally {
        setIsLoading(false)
      }
    }
  }, [onBulkDelete, selectedIds])

  const handleKeyDown = useCallback((e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      saveEdit()
    } else if (e.key === 'Escape') {
      cancelEdit()
    }
  }, [saveEdit, cancelEdit])

  const renderCell = useCallback((transaction: Transaction, field: keyof Transaction) => {
    const isEditing = editingCell?.id === transaction.id && editingCell?.field === field

    if (field === 'date') {
      if (isEditing) {
        return (
          <Input
            value={editValue}
            onChange={(e) => setEditValue(e.target.value)}
            onBlur={saveEdit}
            onKeyDown={handleKeyDown}
            className="h-8 w-28"
            autoFocus
            disabled={isLoading}
          />
        )
      }
      return (
        <div 
          className="cursor-pointer hover:bg-muted/50 px-2 py-1 rounded"
          onClick={() => startEditing(transaction.id, 'date', transaction.date)}
        >
          {new Date(transaction.date).toLocaleDateString('pt-BR')}
        </div>
      )
    }

    if (field === 'description') {
      if (isEditing) {
        return (
          <Input
            value={editValue}
            onChange={(e) => setEditValue(e.target.value)}
            onBlur={saveEdit}
            onKeyDown={handleKeyDown}
            className="h-8 min-w-[200px]"
            autoFocus
            disabled={isLoading}
          />
        )
      }
      return (
        <div 
          className="cursor-pointer hover:bg-muted/50 px-2 py-1 rounded"
          onClick={() => startEditing(transaction.id, 'description', transaction.description)}
        >
          {transaction.description}
        </div>
      )
    }

    if (field === 'category') {
      if (isEditing) {
        return (
          <Select value={editValue} onValueChange={setEditValue}>
            <SelectTrigger className="h-8 w-32" onBlur={saveEdit}>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {categories.map(category => (
                <SelectItem key={category} value={category}>{category}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        )
      }
      return (
        <div 
          className="cursor-pointer hover:bg-muted/50 px-2 py-1 rounded"
          onClick={() => startEditing(transaction.id, 'category', transaction.category)}
        >
          <Badge variant="secondary">{transaction.category}</Badge>
        </div>
      )
    }

    if (field === 'account') {
      if (isEditing) {
        return (
          <Select value={editValue} onValueChange={setEditValue}>
            <SelectTrigger className="h-8 w-32" onBlur={saveEdit}>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {accounts.map(account => (
                <SelectItem key={account} value={account}>{account}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        )
      }
      return (
        <div 
          className="cursor-pointer hover:bg-muted/50 px-2 py-1 rounded"
          onClick={() => startEditing(transaction.id, 'account', transaction.account)}
        >
          {transaction.account}
        </div>
      )
    }

    if (field === 'amount') {
      if (isEditing) {
        return (
          <Input
            value={editValue}
            onChange={(e) => setEditValue(e.target.value)}
            onBlur={saveEdit}
            onKeyDown={handleKeyDown}
            className="h-8 w-24 text-right"
            autoFocus
            disabled={isLoading}
          />
        )
      }
      return (
        <div 
          className={`cursor-pointer hover:bg-muted/50 px-2 py-1 rounded text-right font-medium ${
            transaction.amount >= 0 ? 'text-green-600' : 'text-red-600'
          }`}
          onClick={() => startEditing(transaction.id, 'amount', transaction.amount)}
        >
          {transaction.amount >= 0 ? '+' : ''}R$ {Math.abs(transaction.amount).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
        </div>
      )
    }

    return null
  }, [editingCell, editValue, isLoading, categories, accounts, startEditing, saveEdit, handleKeyDown])

  return (
    <div className="space-y-6">
      {/* Filtros e Busca */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <Filter className="h-5 w-5" />
            Filtros e Busca
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-4">
            <div className="flex-1 min-w-[200px]">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  placeholder="Buscar transações..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Select value={filterCategory} onValueChange={setFilterCategory}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Categoria" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todas Categorias</SelectItem>
                {categories.map(category => (
                  <SelectItem key={category} value={category}>{category}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={filterAccount} onValueChange={setFilterAccount}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Conta" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todas Contas</SelectItem>
                {accounts.map(account => (
                  <SelectItem key={account} value={account}>{account}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Resumo */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Transações</p>
                <p className="text-2xl font-bold">
                  {performanceMetrics.totalTransactions}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Receitas</p>
                <p className="text-2xl font-bold text-green-600">
                  +R$ {performanceMetrics.totalIncome.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Despesas</p>
                <p className="text-2xl font-bold text-red-600">
                  -R$ {performanceMetrics.totalExpenses.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Saldo</p>
                <p className={`text-2xl font-bold ${performanceMetrics.balance >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                  R$ {performanceMetrics.balance.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Ações em Lote */}
      {selectedIds.length > 0 && (
        <Card className="border-blue-200 bg-blue-50/50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <p className="text-sm text-blue-700">
                {selectedIds.length} transação(ões) selecionada(s)
              </p>
              <div className="flex gap-2">
                <Select onValueChange={(value) => onBulkReclassify?.(selectedIds, value)}>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Reclassificar" />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map(category => (
                      <SelectItem key={category} value={category}>{category}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Button variant="outline" size="sm" onClick={bulkDelete} disabled={isLoading}>
                  {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Trash2 className="mr-2 h-4 w-4" />}
                  Excluir
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Tabela Virtualizada */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>Transações ({filteredTransactions.length})</span>
            {isLoading && <Loader2 className="h-4 w-4 animate-spin" />}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-12">
                    <Checkbox
                      checked={selectedIds.length === visibleTransactions.length && visibleTransactions.length > 0}
                      onCheckedChange={handleSelectAll}
                    />
                  </TableHead>
                  <TableHead>Data</TableHead>
                  <TableHead>Descrição</TableHead>
                  <TableHead>Categoria</TableHead>
                  <TableHead>Conta</TableHead>
                  <TableHead className="text-right">Valor</TableHead>
                  <TableHead className="w-12"></TableHead>
                </TableRow>
              </TableHeader>
            </Table>
            
            <div 
              className="relative overflow-auto"
              style={{ height: `${VISIBLE_ITEMS * ITEM_HEIGHT}px` }}
              onScroll={handleScroll}
            >
              <div style={{ height: `${totalHeight}px`, position: 'relative' }}>
                <div style={{ transform: `translateY(${startIndex * ITEM_HEIGHT}px)` }}>
                  <Table>
                    <TableBody>
                      {visibleTransactions.map((transaction) => (
                        <TableRow 
                          key={transaction.id} 
                          className="hover:bg-muted/50 absolute w-full"
                          style={{ height: `${ITEM_HEIGHT}px` }}
                        >
                          <TableCell className="w-12">
                            <Checkbox
                              checked={selectedIds.includes(transaction.id)}
                              onCheckedChange={(checked) => handleSelectOne(transaction.id, checked as boolean)}
                            />
                          </TableCell>
                          <TableCell>{renderCell(transaction, 'date')}</TableCell>
                          <TableCell>{renderCell(transaction, 'description')}</TableCell>
                          <TableCell>{renderCell(transaction, 'category')}</TableCell>
                          <TableCell>{renderCell(transaction, 'account')}</TableCell>
                          <TableCell className="text-right">{renderCell(transaction, 'amount')}</TableCell>
                          <TableCell className="w-12">
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="sm">
                                  <MoreHorizontal className="h-4 w-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuItem onClick={() => deleteTransaction(transaction.id)}>
                                  <Trash2 className="mr-2 h-4 w-4" />
                                  Excluir
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}