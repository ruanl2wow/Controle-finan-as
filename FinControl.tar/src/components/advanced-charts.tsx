'use client'

import { useMemo } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { 
  LineChart, 
  Line, 
  AreaChart, 
  Area,
  BarChart, 
  Bar,
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
  ComposedChart,
  Scatter,
  ScatterChart,
  Legend,
  ReferenceLine,
  Brush
} from 'recharts'
import { format } from 'date-fns'
import { ptBR } from 'date-fns/locale'

interface AdvancedChartsProps {
  data: any
  period: string
}

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8', '#82CA9D', '#FFC658', '#FF7C7C']

export function AdvancedCharts({ data, period }: AdvancedChartsProps) {
  // Enhanced monthly trend data with predictions
  const enhancedMonthlyData = useMemo(() => {
    if (!data?.monthlyTrends) return []
    
    return data.monthlyTrends.map((trend: any, index: number) => ({
      ...trend,
      monthName: format(new Date(trend.month + '-01'), 'MMM/yyyy', { locale: ptBR }),
      balance: trend.income - trend.expenses,
      savingsRate: trend.income > 0 ? ((trend.income - trend.expenses) / trend.income * 100) : 0,
      // Add prediction for next months (simplified)
      predicted: index >= data.monthlyTrends.length - 2
    }))
  }, [data])

  // Cash flow analysis
  const cashFlowData = useMemo(() => {
    if (!data?.monthlyTrends) return []
    
    return data.monthlyTrends.map((trend: any) => ({
      month: format(new Date(trend.month + '-01'), 'MMM', { locale: ptBR }),
      inflow: trend.income,
      outflow: trend.expenses,
      netCashFlow: trend.income - trend.expenses,
      cumulative: 0 // Will be calculated
    })).reduce((acc: any[], curr: any, index: number) => {
      if (index === 0) {
        curr.cumulative = curr.netCashFlow
      } else {
        curr.cumulative = acc[index - 1].cumulative + curr.netCashFlow
      }
      acc.push(curr)
      return acc
    }, [])
  }, [data])

  // Category distribution with subcategories
  const categoryDistribution = useMemo(() => {
    if (!data?.categoryBreakdown) return []
    
    return data.categoryBreakdown.map((cat: any, index: number) => ({
      name: cat.name,
      value: cat.expenses,
      income: cat.income,
      net: cat.income - cat.expenses,
      percentage: data.summary.totalExpenses > 0 ? (cat.expenses / data.summary.totalExpenses * 100) : 0,
      color: COLORS[index % COLORS.length]
    })).sort((a: any, b: any) => b.value - a.value)
  }, [data])

  // Spending pattern analysis
  const spendingPatterns = useMemo(() => {
    if (!data?.dailyPatterns) return []
    
    return data.dailyPatterns.map((pattern: any) => ({
      day: pattern.day,
      spending: pattern.expenses,
      income: pattern.income,
      net: pattern.income - pattern.expenses,
      transactions: pattern.count,
      avgTransaction: pattern.count > 0 ? pattern.expenses / pattern.count : 0
    }))
  }, [data])

  // Financial health radar data
  const financialHealthRadar = useMemo(() => {
    if (!data?.financialHealth) return []
    
    const { savingsRate, debtToIncome, avgTransactionSize, transactionFrequency } = data.financialHealth
    
    return [
      {
        metric: 'Taxa de Economia',
        value: Math.min(100, Math.max(0, savingsRate * 5)), // Scale to 0-100
        fullMark: 100
      },
      {
        metric: 'Controle de Dívidas',
        value: Math.max(0, 100 - debtToIncome), // Invert: lower debt is better
        fullMark: 100
      },
      {
        metric: 'Tamanho Transação',
        value: Math.min(100, Math.max(0, (avgTransactionSize / 1000) * 20)), // Scale appropriately
        fullMark: 100
      },
      {
        metric: 'Frequência',
        value: Math.min(100, Math.max(0, transactionFrequency * 10)), // Scale to 0-100
        fullMark: 100
      },
      {
        metric: 'Diversificação',
        value: Math.min(100, data.categoryBreakdown?.length * 10 || 0), // More categories = better
        fullMark: 100
      }
    ]
  }, [data])

  // Transaction size distribution
  const transactionSizeDistribution = useMemo(() => {
    // This would normally come from the API
    return [
      { range: 'R$ 0-50', count: 45, percentage: 45 },
      { range: 'R$ 50-100', count: 25, percentage: 25 },
      { range: 'R$ 100-200', count: 15, percentage: 15 },
      { range: 'R$ 200-500', count: 10, percentage: 10 },
      { range: 'R$ 500+', count: 5, percentage: 5 }
    ]
  }, [])

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-background border rounded-lg p-3 shadow-lg">
          <p className="font-medium">{label}</p>
          {payload.map((entry: any, index: number) => (
            <p key={index} style={{ color: entry.color }} className="text-sm">
              {entry.name}: R$ {entry.value.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
            </p>
          ))}
        </div>
      )
    }
    return null
  }

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value)
  }

  return (
    <div className="space-y-6">
      {/* Cash Flow Analysis */}
      <Card>
        <CardHeader>
          <CardTitle>Análise de Fluxo de Caixa</CardTitle>
          <CardDescription>
            Entradas, saídas e fluxo de caixa acumulado ao longo do tempo
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={400}>
            <ComposedChart data={cashFlowData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis yAxisId="left" />
              <YAxis yAxisId="right" orientation="right" />
              <Tooltip content={<CustomTooltip />} />
              <Legend />
              <Bar yAxisId="left" dataKey="inflow" fill="#10B981" name="Entradas" />
              <Bar yAxisId="left" dataKey="outflow" fill="#EF4444" name="Saídas" />
              <Line 
                yAxisId="right" 
                type="monotone" 
                dataKey="cumulative" 
                stroke="#3B82F6" 
                strokeWidth={3}
                name="Fluxo Acumulado"
              />
              <ReferenceLine yAxisId="right" y={0} stroke="#666" strokeDasharray="5 5" />
            </ComposedChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Enhanced Category Distribution */}
        <Card>
          <CardHeader>
            <CardTitle>Distribuição de Gastos</CardTitle>
            <CardDescription>
              Análise detalhada por categoria com percentuais
            </CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={categoryDistribution}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percentage }) => `${name} ${percentage.toFixed(1)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {categoryDistribution.map((entry: any, index: number) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip 
                  formatter={(value: number) => [formatCurrency(value), 'Valor']}
                />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Financial Health Radar */}
        <Card>
          <CardHeader>
            <CardTitle>Saúde Financeira</CardTitle>
            <CardDescription>
              Visão geral dos indicadores financeiros
            </CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <RadarChart data={financialHealthRadar}>
                <PolarGrid />
                <PolarAngleAxis dataKey="metric" />
                <PolarRadiusAxis angle={90} domain={[0, 100]} />
                <Radar
                  name="Saúde Financeira"
                  dataKey="value"
                  stroke="#3B82F6"
                  fill="#3B82F6"
                  fillOpacity={0.6}
                />
                <Tooltip />
              </RadarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Spending Patterns */}
      <Card>
        <CardHeader>
          <CardTitle>Padrões de Gastos Semanais</CardTitle>
          <CardDescription>
            Análise de comportamento de gastos por dia da semana
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={spendingPatterns}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="day" />
              <YAxis />
              <Tooltip 
                content={({ active, payload, label }) => {
                  if (active && payload && payload.length) {
                    const data = payload[0].payload
                    return (
                      <div className="bg-background border rounded-lg p-3 shadow-lg">
                        <p className="font-medium">{label}</p>
                        <p className="text-sm text-red-600">
                          Gastos: {formatCurrency(data.spending)}
                        </p>
                        <p className="text-sm text-green-600">
                          Receitas: {formatCurrency(data.income)}
                        </p>
                        <p className="text-sm">
                          Transações: {data.transactions}
                        </p>
                        <p className="text-sm">
                          Média: {formatCurrency(data.avgTransaction)}
                        </p>
                      </div>
                    )
                  }
                  return null
                }}
              />
              <Bar dataKey="spending" fill="#EF4444" name="Gastos" />
              <Bar dataKey="income" fill="#10B981" name="Receitas" />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Transaction Size Distribution */}
      <Card>
        <CardHeader>
          <CardTitle>Distribuição de Tamanho de Transações</CardTitle>
          <CardDescription>
            Análise da frequência de transações por faixa de valor
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={transactionSizeDistribution} layout="horizontal">
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis type="number" />
              <YAxis dataKey="range" type="category" />
              <Tooltip 
                content={({ active, payload, label }) => {
                  if (active && payload && payload.length) {
                    const data = payload[0].payload
                    return (
                      <div className="bg-background border rounded-lg p-3 shadow-lg">
                        <p className="font-medium">{label}</p>
                        <p className="text-sm">
                          Transações: {data.count}
                        </p>
                        <p className="text-sm">
                          Percentual: {data.percentage}%
                        </p>
                      </div>
                    )
                  }
                  return null
                }}
              />
              <Bar dataKey="count" fill="#3B82F6" />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Trend Analysis with Predictions */}
      <Card>
        <CardHeader>
          <CardTitle>Análise de Tendências com Previsões</CardTitle>
          <CardDescription>
            Tendências históricas e projeções para os próximos meses
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={400}>
            <AreaChart data={enhancedMonthlyData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="monthName" />
              <YAxis />
              <Tooltip content={<CustomTooltip />} />
              <Legend />
              <Area
                type="monotone"
                dataKey="income"
                stackId="1"
                stroke="#10B981"
                fill="#10B981"
                fillOpacity={0.6}
                name="Receitas"
              />
              <Area
                type="monotone"
                dataKey="expenses"
                stackId="2"
                stroke="#EF4444"
                fill="#EF4444"
                fillOpacity={0.6}
                name="Despesas"
              />
              <Line
                type="monotone"
                dataKey="balance"
                stroke="#3B82F6"
                strokeWidth={3}
                name="Saldo"
              />
              <Brush dataKey="monthName" height={30} stroke="#3B82F6" />
            </AreaChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
    </div>
  )
}