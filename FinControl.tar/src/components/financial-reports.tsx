'use client'

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select'
import { 
  Download, 
  FileText, 
  TrendingUp, 
  TrendingDown,
  DollarSign,
  Calendar,
  Target,
  AlertTriangle,
  CheckCircle,
  BarChart3,
  PieChart,
  Activity
} from 'lucide-react'
import { format } from 'date-fns'
import { ptBR } from 'date-fns/locale'

interface FinancialReportsProps {
  data?: any
  onExport?: (type: string, format: string) => void
}

export function FinancialReports({ data, onExport }: FinancialReportsProps) {
  const [reportType, setReportType] = useState('monthly')
  const [reportFormat, setReportFormat] = useState('pdf')
  const [isGenerating, setIsGenerating] = useState(false)

  const handleGenerateReport = async () => {
    setIsGenerating(true)
    try {
      // Simulate report generation
      await new Promise(resolve => setTimeout(resolve, 2000))
      onExport?.(reportType, reportFormat)
    } finally {
      setIsGenerating(false)
    }
  }

  // Sample data for demonstration
  const reportData = {
    monthly: {
      title: 'Relatório Mensal',
      period: format(new Date(), 'MMMM yyyy', { locale: ptBR }),
      summary: {
        totalIncome: 8500,
        totalExpenses: 6200,
        netIncome: 2300,
        savingsRate: 27.1,
        transactionCount: 124,
        topCategory: 'Alimentação',
        topCategoryAmount: 1850
      },
      insights: [
        {
          type: 'positive',
          title: 'Meta de Economia Atingida',
          description: 'Você economizou 27.1% este mês, acima da meta de 20%.'
        },
        {
          type: 'warning',
          title: 'Aumento em Transporte',
          description: 'Gastos com transporte aumentaram 15% em relação ao mês anterior.'
        },
        {
          type: 'info',
          title: 'Distribuição Equilibrada',
          description: 'Seus gastos estão bem distribuídos entre as categorias principais.'
        }
      ],
      recommendations: [
        'Considere investir o excedente de R$ 2.300',
        'Revise assinaturas e serviços recorrentes',
        'Crie um fundo de emergência se ainda não tiver'
      ]
    },
    annual: {
      title: 'Relatório Anual',
      period: format(new Date(), 'yyyy'),
      summary: {
        totalIncome: 102000,
        totalExpenses: 74400,
        netIncome: 27600,
        savingsRate: 27.1,
        transactionCount: 1488,
        topCategory: 'Alimentação',
        topCategoryAmount: 22200
      },
      insights: [
        {
          type: 'positive',
          title: 'Consistência Financeira',
          description: 'Manteve uma taxa de economia saudável durante todo o ano.'
        },
        {
          type: 'warning',
          title: 'Inflação Impact',
          description: 'Gastos com alimentação aumentaram 8% no acumulado do ano.'
        },
        {
          type: 'positive',
          title: 'Crescimento Patrimonial',
          description: 'Seu patrimônio líquido cresceu R$ 27.600 este ano.'
        }
      ],
      recommendations: [
        'Diversifique investimentos para melhor rentabilidade',
        'Planeje metas financeiras de longo prazo',
        'Considere renegociar dívidas com juros altos'
      ]
    }
  }

  const currentReport = reportData[reportType as keyof typeof reportData] || reportData.monthly

  const getInsightIcon = (type: string) => {
    switch (type) {
      case 'positive':
        return <CheckCircle className="h-5 w-5 text-green-600" />
      case 'warning':
        return <AlertTriangle className="h-5 w-5 text-yellow-600" />
      case 'info':
        return <Activity className="h-5 w-5 text-blue-600" />
      default:
        return <Activity className="h-5 w-5 text-gray-600" />
    }
  }

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value)
  }

  return (
    <div className="space-y-6">
      {/* Report Configuration */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Gerador de Relatórios
          </CardTitle>
          <CardDescription>
            Crie relatórios detalhados da sua vida financeira
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-4">
            <div className="flex-1">
              <label className="text-sm font-medium mb-2 block">Tipo de Relatório</label>
              <Select value={reportType} onValueChange={setReportType}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="monthly">Relatório Mensal</SelectItem>
                  <SelectItem value="annual">Relatório Anual</SelectItem>
                  <SelectItem value="custom">Período Personalizado</SelectItem>
                  <SelectItem value="category">Por Categoria</SelectItem>
                  <SelectItem value="investment">Relatório de Investimentos</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex-1">
              <label className="text-sm font-medium mb-2 block">Formato</label>
              <Select value={reportFormat} onValueChange={setReportFormat}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="pdf">PDF</SelectItem>
                  <SelectItem value="excel">Excel</SelectItem>
                  <SelectItem value="csv">CSV</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-end">
              <Button 
                onClick={handleGenerateReport}
                disabled={isGenerating}
                className="flex items-center gap-2"
              >
                {isGenerating ? (
                  <>
                    <div className="h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent" />
                    Gerando...
                  </>
                ) : (
                  <>
                    <Download className="h-4 w-4" />
                    Gerar Relatório
                  </>
                )}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Report Preview */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>{currentReport.title}</CardTitle>
              <CardDescription>{currentReport.period}</CardDescription>
            </div>
            <Badge variant="outline">
              <Calendar className="h-3 w-3 mr-1" />
              {format(new Date(), 'dd/MM/yyyy')}
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Summary Cards */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="p-4 bg-green-50 rounded-lg border border-green-200">
              <div className="flex items-center gap-2 mb-2">
                <TrendingUp className="h-4 w-4 text-green-600" />
                <span className="text-sm font-medium text-green-800">Receitas</span>
              </div>
              <div className="text-2xl font-bold text-green-700">
                {formatCurrency(currentReport.summary.totalIncome)}
              </div>
            </div>
            
            <div className="p-4 bg-red-50 rounded-lg border border-red-200">
              <div className="flex items-center gap-2 mb-2">
                <TrendingDown className="h-4 w-4 text-red-600" />
                <span className="text-sm font-medium text-red-800">Despesas</span>
              </div>
              <div className="text-2xl font-bold text-red-700">
                {formatCurrency(currentReport.summary.totalExpenses)}
              </div>
            </div>
            
            <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
              <div className="flex items-center gap-2 mb-2">
                <DollarSign className="h-4 w-4 text-blue-600" />
                <span className="text-sm font-medium text-blue-800">Saldo</span>
              </div>
              <div className="text-2xl font-bold text-blue-700">
                {formatCurrency(currentReport.summary.netIncome)}
              </div>
            </div>
            
            <div className="p-4 bg-purple-50 rounded-lg border border-purple-200">
              <div className="flex items-center gap-2 mb-2">
                <Target className="h-4 w-4 text-purple-600" />
                <span className="text-sm font-medium text-purple-800">Taxa de Economia</span>
              </div>
              <div className="text-2xl font-bold text-purple-700">
                {currentReport.summary.savingsRate}%
              </div>
            </div>
          </div>

          {/* Key Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Total de Transações</p>
                    <p className="text-2xl font-bold">{currentReport.summary.transactionCount}</p>
                  </div>
                  <BarChart3 className="h-8 w-8 text-muted-foreground" />
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Categoria Principal</p>
                    <p className="text-lg font-bold">{currentReport.summary.topCategory}</p>
                    <p className="text-sm text-muted-foreground">
                      {formatCurrency(currentReport.summary.topCategoryAmount)}
                    </p>
                  </div>
                  <PieChart className="h-8 w-8 text-muted-foreground" />
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Economia Mensal</p>
                    <p className="text-2xl font-bold text-green-600">
                      {formatCurrency(currentReport.summary.netIncome)}
                    </p>
                  </div>
                  <TrendingUp className="h-8 w-8 text-green-600" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Insights */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Insights Financeiros</h3>
            <div className="space-y-3">
              {currentReport.insights.map((insight, index) => (
                <div 
                  key={index}
                  className={`p-4 rounded-lg border ${
                    insight.type === 'positive' ? 'bg-green-50 border-green-200' :
                    insight.type === 'warning' ? 'bg-yellow-50 border-yellow-200' :
                    'bg-blue-50 border-blue-200'
                  }`}
                >
                  <div className="flex items-start gap-3">
                    {getInsightIcon(insight.type)}
                    <div>
                      <h4 className="font-medium">{insight.title}</h4>
                      <p className="text-sm text-muted-foreground mt-1">
                        {insight.description}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Recommendations */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Recomendações</h3>
            <div className="space-y-2">
              {currentReport.recommendations.map((recommendation, index) => (
                <div key={index} className="flex items-center gap-3 p-3 bg-muted/30 rounded-lg">
                  <Target className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                  <p className="text-sm">{recommendation}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Savings Progress */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Progresso das Metas</h3>
            <div className="space-y-4">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium">Meta de Economia (20%)</span>
                  <span className="text-sm font-medium text-green-600">
                    {currentReport.summary.savingsRate}% atingido
                  </span>
                </div>
                <Progress 
                  value={Math.min(100, currentReport.summary.savingsRate * 5)} 
                  className="h-2"
                />
              </div>
              
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium">Meta de Despesas (R$ 7.000)</span>
                  <span className="text-sm font-medium">
                    {formatCurrency(currentReport.summary.totalExpenses)}
                  </span>
                </div>
                <Progress 
                  value={(currentReport.summary.totalExpenses / 7000) * 100} 
                  className="h-2"
                />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}