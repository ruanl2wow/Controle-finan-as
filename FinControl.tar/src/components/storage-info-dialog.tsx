'use client'

import { useState } from 'react'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { 
  Database, 
  HardDrive, 
  Shield, 
  FileText, 
  Server,
  Lock,
  Backup,
  Info,
  Cloud,
  Folder
} from 'lucide-react'

export function StorageInfoDialog() {
  const [open, setOpen] = useState(false)

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm">
          <Info className="h-4 w-4 mr-2" />
          Onde os dados ficam armazenados?
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5 text-blue-500" />
            Armazenamento de Dados Financeiros
          </DialogTitle>
          <DialogDescription>
            Entenda onde e como seus dados são armazenados com segurança
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Resumo */}
          <div className="bg-blue-50 p-4 rounded-lg">
            <h3 className="font-medium text-blue-900 mb-2">🔒 Seus dados estão seguros e privados</h3>
            <p className="text-sm text-blue-700">
              Todos os seus dados financeiros são armazenados localmente em nosso servidor, 
              com criptografia e isolamento completos. Nenhuma informação é compartilhada 
              com terceiros.
            </p>
          </div>

          {/* Banco de Dados */}
          <div>
            <h4 className="font-medium mb-3 flex items-center gap-2">
              <Database className="h-4 w-4 text-blue-500" />
              Banco de Dados Principal
            </h4>
            <div className="space-y-3 pl-6">
              <div className="flex items-center gap-3">
                <Server className="h-4 w-4 text-muted-foreground" />
                <div>
                  <div className="text-sm font-medium">Tipo: SQLite</div>
                  <div className="text-xs text-muted-foreground">
                    Banco de dados leve, rápido e confiável
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <HardDrive className="h-4 w-4 text-muted-foreground" />
                <div>
                  <div className="text-sm font-medium">Localização: Servidor Local</div>
                  <div className="text-xs text-muted-foreground">
                    Arquivo de banco armazenado no servidor da aplicação
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Lock className="h-4 w-4 text-muted-foreground" />
                <div>
                  <div className="text-sm font-medium">Acesso: Exclusivo</div>
                  <div className="text-xs text-muted-foreground">
                    Apenas você tem acesso aos seus dados através da sua conta
                  </div>
                </div>
              </div>
            </div>
          </div>

          <Separator />

          {/* Arquivos de Extratos */}
          <div>
            <h4 className="font-medium mb-3 flex items-center gap-2">
              <FileText className="h-4 w-4 text-green-500" />
              Arquivos de Extratos Bancários
            </h4>
            <div className="space-y-3 pl-6">
              <div className="flex items-center gap-3">
                <Folder className="h-4 w-4 text-muted-foreground" />
                <div>
                  <div className="text-sm font-medium">Local: Sistema de Arquivos</div>
                  <div className="text-xs text-muted-foreground">
                    Pasta segura no servidor com permissões restritas
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Cloud className="h-4 w-4 text-muted-foreground" />
                <div>
                  <div className="text-sm font-medium">Processamento: Local</div>
                  <div className="text-xs text-muted-foreground">
                    Arquivos são processados e armazenados localmente
                  </div>
                </div>
              </div>
            </div>
          </div>

          <Separator />

          {/* Tipos de Dados Armazenados */}
          <div>
            <h4 className="font-medium mb-3">O que é armazenado?</h4>
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-gray-50 p-3 rounded-lg">
                <div className="text-sm font-medium mb-1">📊 Transações</div>
                <div className="text-xs text-muted-foreground">
                  Data, descrição, valor, categoria, conta
                </div>
              </div>
              <div className="bg-gray-50 p-3 rounded-lg">
                <div className="text-sm font-medium mb-1">🏦 Contas</div>
                <div className="text-xs text-muted-foreground">
                  Nome, tipo, saldo, moeda
                </div>
              </div>
              <div className="bg-gray-50 p-3 rounded-lg">
                <div className="text-sm font-medium mb-1">🏷️ Categorias</div>
                <div className="text-xs text-muted-foreground">
                  Nome, cor, ícone, tipo (receita/despesa)
                </div>
              </div>
              <div className="bg-gray-50 p-3 rounded-lg">
                <div className="text-sm font-medium mb-1">📋 Uploads</div>
                <div className="text-xs text-muted-foreground">
                  Metadados dos arquivos enviados
                </div>
              </div>
            </div>
          </div>

          <Separator />

          {/* Medidas de Segurança */}
          <div>
            <h4 className="font-medium mb-3 flex items-center gap-2">
              <Shield className="h-4 w-4 text-red-500" />
              Medidas de Segurança
            </h4>
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <Badge variant="outline" className="text-green-600 border-green-600">
                  ✓
                </Badge>
                <span className="text-sm">Isolamento completo por usuário</span>
              </div>
              <div className="flex items-center gap-2">
                <Badge variant="outline" className="text-green-600 border-green-600">
                  ✓
                </Badge>
                <span className="text-sm">Criptografia de dados sensíveis</span>
              </div>
              <div className="flex items-center gap-2">
                <Badge variant="outline" className="text-green-600 border-green-600">
                  ✓
                </Badge>
                <span className="text-sm">Backup automático diário</span>
              </div>
              <div className="flex items-center gap-2">
                <Badge variant="outline" className="text-green-600 border-green-600">
                  ✓
                </Badge>
                <span className="text-sm">Acesso restrito e autenticado</span>
              </div>
              <div className="flex items-center gap-2">
                <Badge variant="outline" className="text-green-600 border-green-600">
                  ✓
                </Badge>
                <span className="text-sm">Nenhum compartilhamento com terceiros</span>
              </div>
            </div>
          </div>

          {/* Fluxo de Dados */}
          <div>
            <h4 className="font-medium mb-3">Fluxo do Upload até o Armazenamento</h4>
            <div className="flex items-center justify-between text-xs">
              <div className="text-center">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-1">
                  📤
                </div>
                <div>Upload</div>
              </div>
              <div className="flex-1 h-0.5 bg-gray-300 mx-2"></div>
              <div className="text-center">
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-1">
                  🔍
                </div>
                <div>Parse</div>
              </div>
              <div className="flex-1 h-0.5 bg-gray-300 mx-2"></div>
              <div className="text-center">
                <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-1">
                  💾
                </div>
                <div>Banco</div>
              </div>
              <div className="flex-1 h-0.5 bg-gray-300 mx-2"></div>
              <div className="text-center">
                <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-1">
                  🔒
                </div>
                <div>Seguro</div>
              </div>
            </div>
          </div>

          {/* Controle do Usuário */}
          <div className="bg-amber-50 p-4 rounded-lg">
            <h4 className="font-medium text-amber-900 mb-2">🎯 Seu Controle</h4>
            <div className="text-sm text-amber-700 space-y-1">
              <p>• Você pode exportar todos seus dados a qualquer momento</p>
              <p>• Você pode solicitar a exclusão completa dos seus dados</p>
              <p>• Você tem acesso total a todas as informações armazenadas</p>
            </div>
          </div>
        </div>

        <div className="flex justify-end pt-4">
          <Button onClick={() => setOpen(false)}>
            Entendido
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}