'use client'

import React, { lazy, Suspense, startTransition, useEffect } from 'react'
import { Loader2 } from 'lucide-react'
import { useTabContext } from '@/contexts/tab-context'
import { OptimizedSuspense } from '@/components/ui/virtualized-loader'

// Componentes lazy loaded
const AnalyticsDashboard = lazy(() => 
  import('@/components/analytics-dashboard').then(module => ({
    default: module.AnalyticsDashboard
  }))
)

const NotificationCenter = lazy(() => 
  import('@/components/notification-center').then(module => ({
    default: module.NotificationCenter
  }))
)

const FileUploadManager = lazy(() => 
  import('@/components/file-upload-manager').then(module => ({
    default: module.FileUploadManager
  }))
)

const GoalsBudgetsManager = lazy(() => 
  import('@/components/goals-budgets-manager').then(module => ({
    default: module.GoalsBudgetsManager
  }))
)

const DataExport = lazy(() => 
  import('@/components/data-export').then(module => ({
    default: module.DataExport
  }))
)

const SettingsPage = lazy(() => 
  import('@/components/settings-page').then(module => ({
    default: module.SettingsPage
  }))
)

const HelpCenter = lazy(() => 
  import('@/components/help-center').then(module => ({
    default: module.HelpCenter
  }))
)

// Wrapper para componentes lazy com cache
function LazyTabWrapper({ 
  tabKey, 
  children 
}: { 
  tabKey: string
  children: React.ReactNode 
}) {
  const { getCachedTab, cacheTab, isTabLoaded } = useTabContext()

  // Cache o componente quando renderizado
  useEffect(() => {
    cacheTab(tabKey, children)
  }, [tabKey, children, cacheTab])

  // Verificar se já está cacheado
  if (isTabLoaded(tabKey)) {
    const cached = getCachedTab(tabKey)
    if (cached) {
      return <>{cached}</>
    }
  }

  return <>{children}</>
}

// Componente de conteúdo otimizado
export function OptimizedTabContent({ 
  value, 
  children 
}: { 
  value: string
  children: React.ReactNode 
}) {
  const { activeTab } = useTabContext()
  const isActive = activeTab === value

  if (!isActive) return null

  return (
    <div className="animate-in fade-in-0 slide-in-from-bottom-2 duration-300 ease-out">
      <LazyTabWrapper tabKey={value}>
        {children}
      </LazyTabWrapper>
    </div>
  )
}

// Função para pré-carregar componentes
export function preloadComponents() {
  // Pré-carregar componentes mais usados imediatamente
  requestIdleCallback(() => {
    import('@/components/analytics-dashboard')
    import('@/components/help-center')
  })
  
  // Pré-carregar outros componentes
  setTimeout(() => {
    requestIdleCallback(() => {
      import('@/components/file-upload-manager')
      import('@/components/notification-center')
    })
  }, 1000)
  
  setTimeout(() => {
    requestIdleCallback(() => {
      import('@/components/goals-budgets-manager')
      import('@/components/data-export')
    })
  }, 2000)
  
  setTimeout(() => {
    requestIdleCallback(() => {
      import('@/components/settings-page')
    })
  }, 3000)
}

// Componentes lazy exportados
export {
  AnalyticsDashboard,
  NotificationCenter,
  FileUploadManager,
  GoalsBudgetsManager,
  DataExport,
  SettingsPage,
  HelpCenter
}

// Componente wrapper com Suspense otimizado
export function SuspenseWrapper({ children }: { children: React.ReactNode }) {
  return (
    <OptimizedSuspense delay={100}>
      {children}
    </OptimizedSuspense>
  )
}