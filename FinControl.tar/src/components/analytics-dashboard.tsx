'use client';

import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { CalendarIcon, TrendingUp, TrendingDown, DollarSign, CreditCard, Activity, Download, BarChart3, PieChart, LineChart as LineChartIcon, FileText } from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { cn } from '@/lib/utils';
import { FinancialReports } from '@/components/financial-reports';
import { AdvancedCharts } from '@/components/advanced-charts';
import '@/components/ui/tab-animations.css';

interface AnalyticsData {
  summary: {
    totalIncome: number;
    totalExpenses: number;
    netIncome: number;
    transactionCount: number;
    avgIncome: number;
    avgExpense: number;
  };
  categoryBreakdown: Array<{
    name: string;
    income: number;
    expenses: number;
    count: number;
  }>;
  monthlyTrends: Array<{
    month: string;
    income: number;
    expenses: number;
    count: number;
  }>;
  topCategories: Array<{
    name: string;
    income: number;
    expenses: number;
    count: number;
  }>;
  dailyPatterns: Array<{
    day: string;
    income: number;
    expenses: number;
    count: number;
  }>;
  financialHealth: {
    savingsRate: number;
    debtToIncome: number;
    avgTransactionSize: number;
    transactionFrequency: number;
  };
  period: string;
  dateRange: {
    start: Date;
    end: Date;
  };
}

export function AnalyticsDashboard() {
  const [data, setData] = useState<AnalyticsData | null>(null);
  const [loading, setLoading] = useState(true);
  const [period, setPeriod] = useState('month');
  const [startDate, setStartDate] = useState<Date | undefined>();
  const [endDate, setEndDate] = useState<Date | undefined>();
  const [activeTab, setActiveTab] = useState('overview');
  const [cache, setCache] = useState<Map<string, AnalyticsData>>(new Map());
  const [loadedTabs, setLoadedTabs] = useState<Set<string>>(new Set(['overview']));

  // Memoizar a função de fetch para evitar recriações
  const fetchAnalytics = useCallback(async () => {
    try {
      setLoading(true);
      const params = new URLSearchParams();
      params.append('period', period);
      if (startDate && endDate) {
        params.append('startDate', startDate.toISOString());
        params.append('endDate', endDate.toISOString());
      }

      const cacheKey = params.toString();
      
      // Verificar cache primeiro
      if (cache.has(cacheKey)) {
        setData(cache.get(cacheKey)!);
        setLoading(false);
        return;
      }

      const response = await fetch(`/api/analytics?${params}`);
      if (response.ok) {
        const analyticsData = await response.json();
        setData(analyticsData);
        
        // Atualizar cache
        setCache(prev => new Map(prev).set(cacheKey, analyticsData));
      }
    } catch (error) {
      console.error('Failed to fetch analytics:', error);
    } finally {
      setLoading(false);
    }
  }, [period, startDate, endDate, cache]);

  useEffect(() => {
    fetchAnalytics();
  }, [fetchAnalytics]);

  // Memoizar formatação de moeda para evitar recriações
  const formatCurrency = useMemo(() => (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value);
  }, []);

  // Memoizar função de cor de saúde
  const getHealthColor = useMemo(() => (value: number, type: 'savings' | 'debt' | 'positive') => {
    if (type === 'savings') {
      if (value >= 20) return 'text-green-600';
      if (value >= 10) return 'text-yellow-600';
      return 'text-red-600';
    }
    if (type === 'debt') {
      if (value <= 30) return 'text-green-600';
      if (value <= 50) return 'text-yellow-600';
      return 'text-red-600';
    }
    return value >= 0 ? 'text-green-600' : 'text-red-600';
  }, []);

  // Memoizar função de export
  const exportReport = useCallback(async () => {
    try {
      const response = await fetch('/api/export/analytics', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ data }),
      });

      if (response.ok) {
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `financial-analytics-${format(new Date(), 'yyyy-MM-dd')}.pdf`;
        a.click();
        window.URL.revokeObjectURL(url);
      }
    } catch (error) {
      console.error('Failed to export report:', error);
    }
  }, [data]);

  // Lazy loading de tabs
  const handleTabChange = useCallback((value: string) => {
    setActiveTab(value);
    if (!loadedTabs.has(value)) {
      setLoadedTabs(prev => new Set(prev).add(value));
    }
  }, [loadedTabs]);

  // Memoizar componentes das abas para evitar re-renderização
  const OverviewTab = useMemo(() => {
    if (!loadedTabs.has('overview')) return null;
    
    return (
      <div className="space-y-4 animate-in fade-in-50 duration-200">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <PieChart className="h-5 w-5" />
                Principais Categorias
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {data?.topCategories.map((category, index) => (
                  <div key={index} className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Badge variant="outline">{category.name}</Badge>
                      <span className="text-sm text-muted-foreground">
                        {category.count} transações
                      </span>
                    </div>
                    <div className="text-right">
                      <div className="font-medium">{formatCurrency(category.expenses)}</div>
                      <div className="text-sm text-muted-foreground">
                        {((category.expenses / data.summary.totalExpenses) * 100).toFixed(1)}%
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5" />
                Padrões Diários
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {data?.dailyPatterns.map((pattern, index) => (
                  <div key={index} className="flex items-center justify-between">
                    <span className="text-sm font-medium">{pattern.day}</span>
                    <div className="flex items-center gap-4">
                      <div className="text-right">
                        <div className="text-sm text-green-600">
                          +{formatCurrency(pattern.income)}
                        </div>
                        <div className="text-sm text-red-600">
                          -{formatCurrency(pattern.expenses)}
                        </div>
                      </div>
                      <Badge variant="outline">{pattern.count}</Badge>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }, [data, loadedTabs, formatCurrency]);

  const CategoriesTab = useMemo(() => {
    if (!loadedTabs.has('categories')) return null;
    
    return (
      <div className="space-y-4 animate-in fade-in-50 duration-200">
        <Card>
          <CardHeader>
            <CardTitle>Análise por Categoria</CardTitle>
            <CardDescription>
              Detalhamento completo de receitas e despesas por categoria
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {data?.categoryBreakdown.map((category, index) => (
                <div key={index} className="border rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-medium">{category.name}</h4>
                    <Badge variant="outline">{category.count} transações</Badge>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-muted-foreground">Receitas</p>
                      <p className="text-lg font-medium text-green-600">
                        {formatCurrency(category.income)}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Despesas</p>
                      <p className="text-lg font-medium text-red-600">
                        {formatCurrency(category.expenses)}
                      </p>
                    </div>
                  </div>
                  <div className="mt-2">
                    <p className="text-sm text-muted-foreground">Saldo</p>
                    <p className={cn("text-lg font-medium", getHealthColor(category.income - category.expenses, 'positive'))}>
                      {formatCurrency(category.income - category.expenses)}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }, [data, loadedTabs, formatCurrency, getHealthColor]);

  const TrendsTab = useMemo(() => {
    if (!loadedTabs.has('trends')) return null;
    
    return (
      <div className="space-y-4 animate-in fade-in-50 duration-200">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <LineChartIcon className="h-5 w-5" />
              Tendências Mensais
            </CardTitle>
            <CardDescription>
              Evolução das receitas e despesas ao longo do tempo
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {data?.monthlyTrends.map((trend, index) => {
                const [year, month] = trend.month.split('-');
                const monthName = new Date(parseInt(year), parseInt(month) - 1).toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' });
                
                return (
                  <div key={index} className="border rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-medium">{monthName}</h4>
                      <Badge variant="outline">{trend.count} transações</Badge>
                    </div>
                    <div className="grid grid-cols-3 gap-4">
                      <div>
                        <p className="text-sm text-muted-foreground">Receitas</p>
                        <p className="text-lg font-medium text-green-600">
                          {formatCurrency(trend.income)}
                        </p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Despesas</p>
                        <p className="text-lg font-medium text-red-600">
                          {formatCurrency(trend.expenses)}
                        </p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Saldo</p>
                        <p className={cn("text-lg font-medium", getHealthColor(trend.income - trend.expenses, 'positive'))}>
                          {formatCurrency(trend.income - trend.expenses)}
                        </p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }, [data, loadedTabs, formatCurrency, getHealthColor]);

  const HealthTab = useMemo(() => {
    if (!loadedTabs.has('health')) return null;
    
    return (
      <div className="space-y-4 animate-in fade-in-50 duration-200">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Indicadores de Saúde Financeira</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium">Taxa de Economia</span>
                  <span className={cn("text-sm font-medium", getHealthColor(data?.financialHealth.savingsRate || 0, 'savings'))}>
                    {data?.financialHealth.savingsRate.toFixed(1)}%
                  </span>
                </div>
                <Progress value={Math.min(100, data?.financialHealth.savingsRate || 0)} />
                <p className="text-xs text-muted-foreground mt-1">
                  Ideal: acima de 20%
                </p>
              </div>

              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium">Relação Dívida/Renda</span>
                  <span className={cn("text-sm font-medium", getHealthColor(data?.financialHealth.debtToIncome || 0, 'debt'))}>
                    {data?.financialHealth.debtToIncome.toFixed(1)}%
                  </span>
                </div>
                <Progress value={Math.min(100, data?.financialHealth.debtToIncome || 0)} className="bg-red-100" />
                <p className="text-xs text-muted-foreground mt-1">
                  Ideal: abaixo de 30%
                </p>
              </div>

              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium">Tamanho Médio da Transação</span>
                  <span className="text-sm font-medium">
                    {formatCurrency(data?.financialHealth.avgTransactionSize || 0)}
                  </span>
                </div>
                <p className="text-xs text-muted-foreground">
                  Valor médio por transação
                </p>
              </div>

              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium">Frequência de Transações</span>
                  <span className="text-sm font-medium">
                    {data?.financialHealth.transactionFrequency.toFixed(1)}/dia
                  </span>
                </div>
                <p className="text-xs text-muted-foreground">
                  Média de transações por dia
                </p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Recomendações Financeiras</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {data?.financialHealth.savingsRate && data.financialHealth.savingsRate < 20 && (
                  <div className="flex items-start gap-3 p-3 bg-yellow-50 rounded-lg">
                    <TrendingDown className="h-5 w-5 text-yellow-600 mt-0.5" />
                    <div>
                      <p className="text-sm font-medium text-yellow-800">
                        Aumentar Taxa de Economia
                      </p>
                      <p className="text-xs text-yellow-700">
                        Sua taxa de economia está abaixo do recomendado. Tente reduzir despesas ou aumentar receitas.
                      </p>
                    </div>
                  </div>
                )}

                {data?.financialHealth.debtToIncome && data.financialHealth.debtToIncome > 50 && (
                  <div className="flex items-start gap-3 p-3 bg-red-50 rounded-lg">
                    <CreditCard className="h-5 w-5 text-red-600 mt-0.5" />
                    <div>
                      <p className="text-sm font-medium text-red-800">
                        Reduzir Relação Dívida/Renda
                      </p>
                      <p className="text-xs text-red-700">
                        Sua relação dívida/renda está alta. Considere renegociar dívidas ou reduzir despesas.
                      </p>
                    </div>
                  </div>
                )}

                {data?.financialHealth.savingsRate && data.financialHealth.savingsRate >= 20 && 
                 data?.financialHealth.debtToIncome && data.financialHealth.debtToIncome <= 30 && (
                  <div className="flex items-start gap-3 p-3 bg-green-50 rounded-lg">
                    <TrendingUp className="h-5 w-5 text-green-600 mt-0.5" />
                    <div>
                      <p className="text-sm font-medium text-green-800">
                        Saúde Financeira Excelente
                      </p>
                      <p className="text-xs text-green-700">
                        Seus indicadores financeiros estão dentro dos parâmetros recomendados!
                      </p>
                    </div>
                  </div>
                )}

                <div className="flex items-start gap-3 p-3 bg-blue-50 rounded-lg">
                  <Activity className="h-5 w-5 text-blue-600 mt-0.5" />
                  <div>
                    <p className="text-sm font-medium text-blue-800">
                      Dica de Otimização
                    </p>
                    <p className="text-xs text-blue-700">
                      Analise suas categorias de maior despesa para identificar oportunidades de economia.
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }, [data, loadedTabs, formatCurrency, getHealthColor]);

  const ReportsTab = useMemo(() => {
    if (!loadedTabs.has('reports')) return null;
    
    return (
      <div className="animate-in fade-in-50 duration-200">
        <FinancialReports />
      </div>
    );
  }, [loadedTabs]);

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[...Array(4)].map((_, i) => (
            <Card key={i} className="animate-pulse">
              <CardHeader className="pb-2">
                <div className="h-4 bg-gray-200 rounded w-3/4"></div>
              </CardHeader>
              <CardContent>
                <div className="h-8 bg-gray-200 rounded w-1/2"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  if (!data) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center h-64">
          <p className="text-muted-foreground">Nenhum dado disponível</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header Controls */}
      <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
        <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center">
          <Select value={period} onValueChange={setPeriod}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Selecione o período" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="week">Última Semana</SelectItem>
              <SelectItem value="month">Último Mês</SelectItem>
              <SelectItem value="quarter">Último Trimestre</SelectItem>
              <SelectItem value="year">Último Ano</SelectItem>
            </SelectContent>
          </Select>

          <div className="flex gap-2">
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" className={cn(!startDate && "text-muted-foreground")}>
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {startDate ? format(startDate, "dd/MM/yyyy", { locale: ptBR }) : "Data Início"}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0">
                <Calendar
                  mode="single"
                  selected={startDate}
                  onSelect={setStartDate}
                  initialFocus
                />
              </PopoverContent>
            </Popover>

            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" className={cn(!endDate && "text-muted-foreground")}>
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {endDate ? format(endDate, "dd/MM/yyyy", { locale: ptBR }) : "Data Fim"}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0">
                <Calendar
                  mode="single"
                  selected={endDate}
                  onSelect={setEndDate}
                  initialFocus
                />
              </PopoverContent>
            </Popover>
          </div>
        </div>

        <Button onClick={exportReport} variant="outline">
          <Download className="mr-2 h-4 w-4" />
          Exportar Relatório
        </Button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="analytics-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Receita Total</CardTitle>
            <TrendingUp className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
              {formatCurrency(data.summary.totalIncome)}
            </div>
            <p className="text-xs text-muted-foreground">
              Média: {formatCurrency(data.summary.avgIncome)}
            </p>
          </CardContent>
        </Card>

        <Card className="analytics-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Despesa Total</CardTitle>
            <TrendingDown className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">
              {formatCurrency(data.summary.totalExpenses)}
            </div>
            <p className="text-xs text-muted-foreground">
              Média: {formatCurrency(data.summary.avgExpense)}
            </p>
          </CardContent>
        </Card>

        <Card className="analytics-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Receita Líquida</CardTitle>
            <DollarSign className="h-4 w-4" />
          </CardHeader>
          <CardContent>
            <div className={cn("text-2xl font-bold", getHealthColor(data.summary.netIncome, 'positive'))}>
              {formatCurrency(data.summary.netIncome)}
            </div>
            <p className="text-xs text-muted-foreground">
              {data.summary.transactionCount} transações
            </p>
          </CardContent>
        </Card>

        <Card className="analytics-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Taxa de Economia</CardTitle>
            <Activity className="h-4 w-4" />
          </CardHeader>
          <CardContent>
            <div className={cn("text-2xl font-bold", getHealthColor(data.financialHealth.savingsRate, 'savings'))}>
              {data.financialHealth.savingsRate.toFixed(1)}%
            </div>
            <Progress value={Math.min(100, data.financialHealth.savingsRate)} className="mt-2 progress-bar" />
          </CardContent>
        </Card>
      </div>

      {/* Detailed Analytics Tabs */}
      <Tabs value={activeTab} onValueChange={handleTabChange} className="space-y-4">
        <TabsList className="grid w-full grid-cols-6">
          <TabsTrigger value="overview" className="tab-trigger">Visão Geral</TabsTrigger>
          <TabsTrigger value="categories" className="tab-trigger">Categorias</TabsTrigger>
          <TabsTrigger value="trends" className="tab-trigger">Tendências</TabsTrigger>
          <TabsTrigger value="health" className="tab-trigger">Saúde Financeira</TabsTrigger>
          <TabsTrigger value="charts" className="tab-trigger">Gráficos Avançados</TabsTrigger>
          <TabsTrigger value="reports" className="tab-trigger">Relatórios</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4 tabs-content">
          {OverviewTab}
        </TabsContent>

        <TabsContent value="categories" className="space-y-4 tabs-content">
          {CategoriesTab}
        </TabsContent>

        <TabsContent value="trends" className="space-y-4 tabs-content">
          {TrendsTab}
        </TabsContent>

        <TabsContent value="health" className="space-y-4 tabs-content">
          {HealthTab}
        </TabsContent>

        <TabsContent value="charts" className="space-y-4 tabs-content">
          {data && <AdvancedCharts data={data} period={period} />}
        </TabsContent>

        <TabsContent value="reports" className="space-y-4 tabs-content">
          {ReportsTab}
        </TabsContent>
      </Tabs>
    </div>
  );
}