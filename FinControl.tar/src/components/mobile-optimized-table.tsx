'use client'

import { useState, useCallback, useRef, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Checkbox } from '@/components/ui/checkbox'
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select'
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from '@/components/ui/dropdown-menu'
import { 
  Search, 
  Filter,
  Edit,
  Trash2,
  MoreHorizontal,
  Plus,
  ChevronLeft,
  ChevronRight,
  X
} from 'lucide-react'
import { Skeleton } from '@/components/ui/skeleton'
import { SwipeableCard } from './swipeable-card'

interface Transaction {
  id: string
  date: string
  description: string
  category: string
  amount: number
  type: 'income' | 'expense'
  account: string
  tags: string[]
}

interface MobileOptimizedTableProps {
  transactions: Transaction[]
  categories: string[]
  accounts: string[]
  onTransactionUpdate?: (transaction: Transaction) => void
  onTransactionDelete?: (id: string) => void
  onBulkDelete?: (ids: string[]) => void
  onBulkReclassify?: (ids: string[], category: string) => void
}

export function MobileOptimizedTable({
  transactions,
  categories,
  accounts,
  onTransactionUpdate,
  onTransactionDelete,
  onBulkDelete,
  onBulkReclassify
}: MobileOptimizedTableProps) {
  const [selectedIds, setSelectedIds] = useState<string[]>([])
  const [searchTerm, setSearchTerm] = useState('')
  const [filterCategory, setFilterCategory] = useState<string>('all')
  const [filterAccount, setFilterAccount] = useState<string>('all')
  const [editingId, setEditingId] = useState<string | null>(null)
  const [editForm, setEditForm] = useState<Partial<Transaction>>({})
  const [showFilters, setShowFilters] = useState(false)
  const [currentPage, setCurrentPage] = useState(1)
  const [isLoading, setIsLoading] = useState(false)
  
  const itemsPerPage = 20
  const touchStartX = useRef<number>(0)
  const touchStartY = useRef<number>(0)

  // Filter transactions
  const filteredTransactions = transactions.filter(transaction => {
    const matchesSearch = transaction.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         transaction.category.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesCategory = filterCategory === 'all' || transaction.category === filterCategory
    const matchesAccount = filterAccount === 'all' || transaction.account === filterAccount
    return matchesSearch && matchesCategory && matchesAccount
  })

  const totalPages = Math.ceil(filteredTransactions.length / itemsPerPage)
  const startIndex = (currentPage - 1) * itemsPerPage
  const paginatedTransactions = filteredTransactions.slice(startIndex, startIndex + itemsPerPage)

  // Touch handlers for swipe actions
  const handleTouchStart = useCallback((e: React.TouchEvent, transactionId: string) => {
    touchStartX.current = e.touches[0].clientX
    touchStartY.current = e.touches[0].clientY
  }, [])

  const handleTouchEnd = useCallback((e: React.TouchEvent, transaction: Transaction) => {
    const touchEndX = e.changedTouches[0].clientX
    const touchEndY = e.changedTouches[0].clientY
    
    const deltaX = touchEndX - touchStartX.current
    const deltaY = Math.abs(touchEndY - touchStartY.current)
    
    // Only register horizontal swipes (not vertical scrolling)
    if (Math.abs(deltaX) > 50 && deltaY < 30) {
      if (deltaX > 0) {
        // Swipe right - select
        handleSelectOne(transaction.id, !selectedIds.includes(transaction.id))
      } else {
        // Swipe left - show actions
        setEditingId(transaction.id)
      }
    }
  }, [selectedIds])

  const handleSelectOne = useCallback((id: string, checked: boolean) => {
    if (checked) {
      setSelectedIds(prev => [...prev, id])
    } else {
      setSelectedIds(prev => prev.filter(selectedId => selectedId !== id))
    }
  }, [])

  const startEditing = useCallback((transaction: Transaction) => {
    setEditingId(transaction.id)
    setEditForm(transaction)
  }, [])

  const saveEdit = useCallback(async () => {
    if (editingId && editForm && onTransactionUpdate) {
      setIsLoading(true)
      try {
        await onTransactionUpdate(editForm as Transaction)
        setEditingId(null)
        setEditForm({})
      } catch (error) {
        console.error('Error updating transaction:', error)
      } finally {
        setIsLoading(false)
      }
    }
  }, [editingId, editForm, onTransactionUpdate])

  const cancelEdit = useCallback(() => {
    setEditingId(null)
    setEditForm({})
  }, [])

  const deleteTransaction = useCallback(async (id: string) => {
    if (onTransactionDelete) {
      setIsLoading(true)
      try {
        await onTransactionDelete(id)
        setSelectedIds(prev => prev.filter(selectedId => selectedId !== id))
      } catch (error) {
        console.error('Error deleting transaction:', error)
      } finally {
        setIsLoading(false)
      }
    }
  }, [onTransactionDelete])

  const bulkDelete = useCallback(async () => {
    if (onBulkDelete && selectedIds.length > 0) {
      setIsLoading(true)
      try {
        await onBulkDelete(selectedIds)
        setSelectedIds([])
      } catch (error) {
        console.error('Error bulk deleting transactions:', error)
      } finally {
        setIsLoading(false)
      }
    }
  }, [onBulkDelete, selectedIds])

  // Performance metrics
  const totalIncome = filteredTransactions
    .filter(t => t.type === 'income')
    .reduce((sum, t) => sum + t.amount, 0)

  const totalExpenses = Math.abs(filteredTransactions
    .filter(t => t.type === 'expense')
    .reduce((sum, t) => sum + t.amount, 0))

  return (
    <div className="space-y-4 pb-20">
      {/* Search and Filters */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg">Transações</CardTitle>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowFilters(!showFilters)}
            >
              <Filter className="h-4 w-4" />
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Buscar transações..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 h-12"
            />
          </div>
          
          {showFilters && (
            <div className="space-y-3 animate-in slide-in-from-top-2">
              <Select value={filterCategory} onValueChange={setFilterCategory}>
                <SelectTrigger className="h-12">
                  <SelectValue placeholder="Categoria" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todas Categorias</SelectItem>
                  {categories.map(category => (
                    <SelectItem key={category} value={category}>{category}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={filterAccount} onValueChange={setFilterAccount}>
                <SelectTrigger className="h-12">
                  <SelectValue placeholder="Conta" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todas Contas</SelectItem>
                  {accounts.map(account => (
                    <SelectItem key={account} value={account}>{account}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Summary Cards */}
      <div className="grid gap-3 grid-cols-1">
        <Card>
          <CardContent className="p-4">
            <div className="flex justify-between items-center">
              <div>
                <p className="text-sm text-muted-foreground">Receitas</p>
                <p className="text-xl font-bold text-green-600">
                  +R$ {totalIncome.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex justify-between items-center">
              <div>
                <p className="text-sm text-muted-foreground">Despesas</p>
                <p className="text-xl font-bold text-red-600">
                  -R$ {totalExpenses.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex justify-between items-center">
              <div>
                <p className="text-sm text-muted-foreground">Saldo</p>
                <p className={`text-xl font-bold ${(totalIncome - totalExpenses) >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                  R$ {(totalIncome - totalExpenses).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Bulk Actions */}
      {selectedIds.length > 0 && (
        <Card className="border-blue-200 bg-blue-50/50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <p className="text-sm text-blue-700">
                {selectedIds.length} selecionada(s)
              </p>
              <div className="flex gap-2">
                <Select onValueChange={(value) => onBulkReclassify?.(selectedIds, value)}>
                  <SelectTrigger className="w-32 h-10">
                    <SelectValue placeholder="Reclassificar" />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map(category => (
                      <SelectItem key={category} value={category}>{category}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Button variant="outline" size="sm" onClick={bulkDelete} disabled={isLoading}>
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Transaction List */}
      <div className="space-y-2">
        {paginatedTransactions.map((transaction) => (
          <Card 
            key={transaction.id} 
            className={`transition-all duration-200 ${
              selectedIds.includes(transaction.id) ? 'ring-2 ring-blue-500' : ''
            } ${editingId === transaction.id ? 'ring-2 ring-orange-500' : ''}`}
          >
            <CardContent className="p-0">
              {editingId === transaction.id ? (
                // Edit mode
                <div className="p-4 space-y-3">
                  <div className="flex justify-between items-center">
                    <h3 className="font-medium">Editar Transação</h3>
                    <Button variant="ghost" size="sm" onClick={cancelEdit}>
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                  
                  <div className="space-y-3">
                    <Input
                      placeholder="Descrição"
                      value={editForm.description || ''}
                      onChange={(e) => setEditForm(prev => ({ ...prev, description: e.target.value }))}
                      className="h-12"
                    />
                    
                    <div className="grid grid-cols-2 gap-3">
                      <Select 
                        value={editForm.category || ''} 
                        onValueChange={(value) => setEditForm(prev => ({ ...prev, category: value }))}
                      >
                        <SelectTrigger className="h-12">
                          <SelectValue placeholder="Categoria" />
                        </SelectTrigger>
                        <SelectContent>
                          {categories.map(category => (
                            <SelectItem key={category} value={category}>{category}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      
                      <Input
                        type="number"
                        placeholder="Valor"
                        value={editForm.amount || ''}
                        onChange={(e) => setEditForm(prev => ({ ...prev, amount: parseFloat(e.target.value) || 0 }))}
                        className="h-12"
                      />
                    </div>
                    
                    <div className="flex gap-2">
                      <Button onClick={saveEdit} disabled={isLoading} className="flex-1 h-12">
                        Salvar
                      </Button>
                      <Button variant="outline" onClick={cancelEdit} className="flex-1 h-12">
                        Cancelar
                      </Button>
                    </div>
                  </div>
                </div>
              ) : (
                // View mode with swipe actions
                <div
                  className="p-4 cursor-pointer active:bg-muted/50"
                  onTouchStart={(e) => handleTouchStart(e, transaction.id)}
                  onTouchEnd={(e) => handleTouchEnd(e, transaction)}
                  onClick={() => handleSelectOne(transaction.id, !selectedIds.includes(transaction.id))}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3 flex-1">
                      <Checkbox
                        checked={selectedIds.includes(transaction.id)}
                        onCheckedChange={(checked) => handleSelectOne(transaction.id, checked as boolean)}
                      />
                      
                      <div className="flex-1 min-w-0">
                        <p className="font-medium truncate">{transaction.description}</p>
                        <div className="flex items-center space-x-2 mt-1">
                          <Badge variant="secondary" className="text-xs">
                            {transaction.category}
                          </Badge>
                          <span className="text-xs text-muted-foreground">
                            {transaction.account}
                          </span>
                          <span className="text-xs text-muted-foreground">
                            {new Date(transaction.date).toLocaleDateString('pt-BR')}
                          </span>
                        </div>
                      </div>
                    </div>
                    
                    <div className="text-right">
                      <p className={`font-bold text-lg ${
                        transaction.amount >= 0 ? 'text-green-600' : 'text-red-600'
                      }`}>
                        {transaction.amount >= 0 ? '+' : ''}R$ {Math.abs(transaction.amount).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                      </p>
                    </div>
                  </div>
                  
                  {/* Quick Actions */}
                  <div className="flex justify-end space-x-2 mt-3">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={(e) => {
                        e.stopPropagation()
                        startEditing(transaction)
                      }}
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={(e) => {
                        e.stopPropagation()
                        deleteTransaction(transaction.id)
                      }}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
                disabled={currentPage === 1}
                className="h-12 px-4"
              >
                <ChevronLeft className="h-4 w-4" />
                Anterior
              </Button>
              
              <span className="text-sm text-muted-foreground">
                Página {currentPage} de {totalPages}
              </span>
              
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
                disabled={currentPage === totalPages}
                className="h-12 px-4"
              >
                Próxima
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Floating Action Button */}
      <div className="fixed bottom-6 right-6 z-50">
        <Button size="lg" className="h-14 w-14 rounded-full shadow-lg">
          <Plus className="h-6 w-6" />
        </Button>
      </div>
    </div>
  )
}