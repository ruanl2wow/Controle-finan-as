'use client'

import { useEffect, useState } from 'react'
import { Button } from '@/components/ui/button'
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from '@/components/ui/dialog'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Slider } from '@/components/ui/slider'
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select'
import { Settings, Eye, EyeOff, Type, Palette } from 'lucide-react'

interface AccessibilitySettings {
  highContrast: boolean
  largeText: boolean
  reducedMotion: boolean
  screenReader: boolean
  fontSize: number
  colorBlindMode: 'none' | 'protanopia' | 'deuteranopia' | 'tritanopia'
  keyboardNavigation: boolean
  focusVisible: boolean
}

export function AccessibilityProvider({ children }: { children: React.ReactNode }) {
  const [settings, setSettings] = useState<AccessibilitySettings>({
    highContrast: false,
    largeText: false,
    reducedMotion: false,
    screenReader: false,
    fontSize: 16,
    colorBlindMode: 'none',
    keyboardNavigation: true,
    focusVisible: true,
  })

  useEffect(() => {
    // Load settings from localStorage
    const savedSettings = localStorage.getItem('accessibility-settings')
    if (savedSettings) {
      setSettings(JSON.parse(savedSettings))
    }
  }, [])

  useEffect(() => {
    // Apply settings to document
    const root = document.documentElement
    
    // High contrast
    if (settings.highContrast) {
      root.classList.add('high-contrast')
    } else {
      root.classList.remove('high-contrast')
    }
    
    // Large text
    if (settings.largeText) {
      root.classList.add('large-text')
    } else {
      root.classList.remove('large-text')
    }
    
    // Reduced motion
    if (settings.reducedMotion) {
      root.classList.add('reduced-motion')
    } else {
      root.classList.remove('reduced-motion')
    }
    
    // Font size
    root.style.setProperty('--font-size-base', `${settings.fontSize}px`)
    
    // Color blind mode
    root.setAttribute('data-color-blind', settings.colorBlindMode)
    
    // Focus visible
    if (settings.focusVisible) {
      root.classList.add('focus-visible-enabled')
    } else {
      root.classList.remove('focus-visible-enabled')
    }
    
    // Screen reader announcements
    if (settings.screenReader) {
      root.setAttribute('aria-live', 'polite')
    } else {
      root.removeAttribute('aria-live')
    }
    
    // Save settings
    localStorage.setItem('accessibility-settings', JSON.stringify(settings))
  }, [settings])

  // Keyboard navigation
  useEffect(() => {
    if (!settings.keyboardNavigation) return

    const handleKeyDown = (e: KeyboardEvent) => {
      // Skip navigation keys
      if (e.target instanceof HTMLInputElement || 
          e.target instanceof HTMLTextAreaElement ||
          e.target instanceof HTMLSelectElement) {
        return
      }

      // Alt + A: Open accessibility settings
      if (e.altKey && e.key === 'a') {
        e.preventDefault()
        document.getElementById('accessibility-trigger')?.click()
      }

      // Tab navigation enhancement
      if (e.key === 'Tab') {
        document.body.classList.add('keyboard-navigation')
      }
    }

    const handleMouseDown = () => {
      document.body.classList.remove('keyboard-navigation')
    }

    document.addEventListener('keydown', handleKeyDown)
    document.addEventListener('mousedown', handleMouseDown)

    return () => {
      document.removeEventListener('keydown', handleKeyDown)
      document.removeEventListener('mousedown', handleMouseDown)
    }
  }, [settings.keyboardNavigation])

  const updateSetting = <K extends keyof AccessibilitySettings>(
    key: K, 
    value: AccessibilitySettings[K]
  ) => {
    setSettings(prev => ({ ...prev, [key]: value }))
  }

  return (
    <>
      {children}
      <AccessibilityControls 
        settings={settings} 
        onUpdate={updateSetting} 
      />
    </>
  )
}

function AccessibilityControls({ 
  settings, 
  onUpdate 
}: { 
  settings: AccessibilitySettings
  onUpdate: <K extends keyof AccessibilitySettings>(key: K, value: AccessibilitySettings[K]) => void 
}) {
  const [open, setOpen] = useState(false)

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button
          id="accessibility-trigger"
          variant="outline"
          size="sm"
          className="fixed bottom-4 left-4 z-50 md:bottom-6 md:left-6"
          aria-label="Configurações de acessibilidade"
        >
          <Settings className="h-4 w-4" />
          <span className="sr-only">Configurações de acessibilidade</span>
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px]" aria-describedby="accessibility-description">
        <DialogHeader>
          <DialogTitle>Configurações de Acessibilidade</DialogTitle>
          <DialogDescription id="accessibility-description">
            Personalize a experiência de uso conforme suas necessidades.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-6">
          {/* Visual Settings */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium flex items-center gap-2">
              <Eye className="h-5 w-5" />
              Visual
            </h3>
            
            <div className="flex items-center justify-between">
              <Label htmlFor="high-contrast">Alto Contraste</Label>
              <Switch
                id="high-contrast"
                checked={settings.highContrast}
                onCheckedChange={(checked) => onUpdate('highContrast', checked)}
              />
            </div>
            
            <div className="flex items-center justify-between">
              <Label htmlFor="large-text">Texto Grande</Label>
              <Switch
                id="large-text"
                checked={settings.largeText}
                onCheckedChange={(checked) => onUpdate('largeText', checked)}
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="font-size">Tamanho da Fonte: {settings.fontSize}px</Label>
              <Slider
                id="font-size"
                min={12}
                max={24}
                step={1}
                value={[settings.fontSize]}
                onValueChange={([value]) => onUpdate('fontSize', value)}
                className="w-full"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="color-blind">Modo Daltônico</Label>
              <Select 
                value={settings.colorBlindMode} 
                onValueChange={(value: any) => onUpdate('colorBlindMode', value)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">Nenhum</SelectItem>
                  <SelectItem value="protanopia">Protanopia (vermelho-verde)</SelectItem>
                  <SelectItem value="deuteranopia">Deuteranopia (verde-vermelho)</SelectItem>
                  <SelectItem value="tritanopia">Tritanopia (azul-amarelo)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Motion Settings */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium flex items-center gap-2">
              <Type className="h-5 w-5" />
              Movimento
            </h3>
            
            <div className="flex items-center justify-between">
              <Label htmlFor="reduced-motion">Reduzir Movimento</Label>
              <Switch
                id="reduced-motion"
                checked={settings.reducedMotion}
                onCheckedChange={(checked) => onUpdate('reducedMotion', checked)}
              />
            </div>
          </div>

          {/* Navigation Settings */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium flex items-center gap-2">
              <Palette className="h-5 w-5" />
              Navegação
            </h3>
            
            <div className="flex items-center justify-between">
              <Label htmlFor="keyboard-nav">Navegação por Teclado</Label>
              <Switch
                id="keyboard-nav"
                checked={settings.keyboardNavigation}
                onCheckedChange={(checked) => onUpdate('keyboardNavigation', checked)}
              />
            </div>
            
            <div className="flex items-center justify-between">
              <Label htmlFor="focus-visible">Foco Visível</Label>
              <Switch
                id="focus-visible"
                checked={settings.focusVisible}
                onCheckedChange={(checked) => onUpdate('focusVisible', checked)}
              />
            </div>
            
            <div className="flex items-center justify-between">
              <Label htmlFor="screen-reader">Suporte a Leitor de Tela</Label>
              <Switch
                id="screen-reader"
                checked={settings.screenReader}
                onCheckedChange={(checked) => onUpdate('screenReader', checked)}
              />
            </div>
          </div>

          {/* Keyboard Shortcuts */}
          <div className="space-y-2">
            <h3 className="text-lg font-medium">Atalhos de Teclado</h3>
            <div className="text-sm text-muted-foreground space-y-1">
              <p><kbd>Alt</kbd> + <kbd>A</kbd> - Abrir configurações de acessibilidade</p>
              <p><kbd>Tab</kbd> - Navegar entre elementos</p>
              <p><kbd>Enter</kbd> - Ativar elemento focado</p>
              <p><kbd>Esc</kbd> - Fechar diálogos</p>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}

// Screen reader announcements
export function useScreenReaderAnnouncement() {
  const announce = (message: string, priority: 'polite' | 'assertive' = 'polite') => {
    const announcement = document.createElement('div')
    announcement.setAttribute('aria-live', priority)
    announcement.setAttribute('aria-atomic', 'true')
    announcement.className = 'sr-only'
    announcement.textContent = message
    
    document.body.appendChild(announcement)
    
    setTimeout(() => {
      document.body.removeChild(announcement)
    }, 1000)
  }

  return { announce }
}

// Focus trap for modals
export function useFocusTrap(isActive: boolean) {
  useEffect(() => {
    if (!isActive) return

    const handleTabKey = (e: KeyboardEvent) => {
      if (e.key !== 'Tab') return

      const focusableElements = document.querySelectorAll(
        'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
      )
      
      const firstElement = focusableElements[0] as HTMLElement
      const lastElement = focusableElements[focusableElements.length - 1] as HTMLElement

      if (e.shiftKey) {
        if (document.activeElement === firstElement) {
          lastElement.focus()
          e.preventDefault()
        }
      } else {
        if (document.activeElement === lastElement) {
          firstElement.focus()
          e.preventDefault()
        }
      }
    }

    document.addEventListener('keydown', handleTabKey)
    
    // Focus first element
    const firstElement = document.querySelector(
      'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
    ) as HTMLElement
    firstElement?.focus()

    return () => {
      document.removeEventListener('keydown', handleTabKey)
    }
  }, [isActive])
}

// Skip links component
export function SkipLinks() {
  return (
    <div className="sr-only focus:not-sr-only focus:absolute focus:top-4 focus:left-4 z-50">
      <a 
        href="#main-content" 
        className="bg-primary text-primary-foreground px-4 py-2 rounded-md focus:outline-none focus:ring-2 focus:ring-ring"
      >
        Pular para o conteúdo principal
      </a>
      <a 
        href="#navigation" 
        className="bg-primary text-primary-foreground px-4 py-2 rounded-md focus:outline-none focus:ring-2 focus:ring-ring ml-2"
      >
        Pular para a navegação
      </a>
    </div>
  )
}