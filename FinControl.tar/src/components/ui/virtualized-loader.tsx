'use client'

import { forwardRef, useEffect, useState, ReactNode } from 'react'
import { Loader2 } from 'lucide-react'

interface VirtualizedLoaderProps {
  size?: 'sm' | 'md' | 'lg'
  text?: string
  className?: string
}

export const VirtualizedLoader = forwardRef<HTMLDivElement, VirtualizedLoaderProps>(
  ({ size = 'md', text = 'Carregando...', className }, ref) => {
    const sizeClasses = {
      sm: 'h-4 w-4',
      md: 'h-8 w-8',
      lg: 'h-12 w-12'
    }

    return (
      <div 
        ref={ref} 
        className={`flex items-center justify-center py-12 ${className}`}
      >
        <div className="flex flex-col items-center space-y-4">
          <Loader2 className={`animate-spin text-primary ${sizeClasses[size]}`} />
          <p className="text-sm text-muted-foreground">{text}</p>
        </div>
      </div>
    )
  }
)

VirtualizedLoader.displayName = 'VirtualizedLoader'

// Skeleton loader para cards
export function CardSkeleton() {
  return (
    <div className="rounded-lg border bg-card text-card-foreground shadow-sm p-6">
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="h-4 w-20 bg-muted rounded animate-pulse" />
          <div className="h-4 w-4 bg-muted rounded animate-pulse" />
        </div>
        <div className="h-8 w-32 bg-muted rounded animate-pulse" />
        <div className="h-3 w-24 bg-muted rounded animate-pulse" />
      </div>
    </div>
  )
}

// Skeleton loader para gráficos
export function ChartSkeleton({ height = 350 }: { height?: number }) {
  return (
    <div className="rounded-lg border bg-card text-card-foreground shadow-sm p-6">
      <div className="h-6 w-32 bg-muted rounded animate-pulse mb-4" />
      <div 
        className="bg-muted rounded animate-pulse" 
        style={{ height: `${height}px` }}
      />
    </div>
  )
}

// Skeleton loader para tabelas
export function TableSkeleton({ rows = 5 }: { rows?: number }) {
  return (
    <div className="rounded-lg border bg-card text-card-foreground shadow-sm p-6">
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="h-6 w-32 bg-muted rounded animate-pulse" />
          <div className="h-8 w-20 bg-muted rounded animate-pulse" />
        </div>
        <div className="space-y-3">
          {Array.from({ length: rows }).map((_, i) => (
            <div key={i} className="flex items-center justify-between">
              <div className="space-y-2">
                <div className="h-4 w-48 bg-muted rounded animate-pulse" />
                <div className="h-3 w-32 bg-muted rounded animate-pulse" />
              </div>
              <div className="h-4 w-16 bg-muted rounded animate-pulse" />
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

// Hook para skeleton loading
export function useSkeletonLoader(isLoading: boolean, delay: number = 200) {
  const [showSkeleton, setShowSkeleton] = useState(false)

  useEffect(() => {
    let timeout: NodeJS.Timeout

    if (isLoading) {
      timeout = setTimeout(() => {
        setShowSkeleton(true)
      }, delay)
    } else {
      setShowSkeleton(false)
    }

    return () => {
      if (timeout) clearTimeout(timeout)
    }
  }, [isLoading, delay])

  return showSkeleton
}

// Componente de loading com suspense otimizado
interface OptimizedSuspenseProps {
  children: ReactNode
  fallback?: ReactNode
  delay?: number
}

export function OptimizedSuspense({ 
  children, 
  fallback, 
  delay = 200 
}: OptimizedSuspenseProps) {
  const [showFallback, setShowFallback] = useState(false)

  useEffect(() => {
    const timeout = setTimeout(() => {
      setShowFallback(true)
    }, delay)

    return () => clearTimeout(timeout)
  }, [delay])

  if (!showFallback) {
    return null
  }

  return (
    <div className="animate-in fade-in-0 duration-300">
      {fallback || <VirtualizedLoader />}
    </div>
  )
}