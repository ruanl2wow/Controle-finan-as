'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Switch } from '@/components/ui/switch'
import { Label } from '@/components/ui/label'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { useWebSocket } from '@/hooks/use-websocket'
import { 
  Bell, 
  BellOff, 
  AlertTriangle, 
  CheckCircle, 
  TrendingUp,
  DollarSign,
  Calendar,
  Settings,
  Plus,
  Trash2,
  Edit,
  Mail,
  Smartphone,
  MessageSquare,
  Wifi,
  WifiOff
} from 'lucide-react'

interface Notification {
  id: string
  type: 'budget_alert' | 'payment_reminder' | 'goal_achieved' | 'anomaly_detected' | 'insight_ready'
  title: string
  message: string
  priority: 'low' | 'medium' | 'high'
  read: boolean
  createdAt: Date
  data?: any
}

interface NotificationRule {
  id: string
  name: string
  type: string
  enabled: boolean
  channels: ('email' | 'push' | 'sms')[]
  conditions: any
  createdAt: Date
}

export function NotificationCenter() {
  const [userId] = useState('demo-user') // In real app, get from auth
  const { 
    isConnected, 
    notifications: realtimeNotifications, 
    markNotificationRead,
    requestNotificationPermission 
  } = useWebSocket(userId)
  
  const [notifications, setNotifications] = useState<Notification[]>([
    {
      id: '1',
      type: 'budget_alert',
      title: 'Orçamento de Restaurante Excedido',
      message: 'Você já utilizou 85% do seu orçamento para restaurantes este mês.',
      priority: 'high',
      read: false,
      createdAt: new Date('2024-06-15T10:30:00'),
      data: { budgetUsed: 850, budgetTotal: 1000, percentage: 85 }
    },
    {
      id: '2',
      type: 'payment_reminder',
      title: 'Lembrete: Conta de Luz',
      message: 'Sua conta de luz vence em 3 dias. Valor estimado: R$ 120,00',
      priority: 'medium',
      read: false,
      createdAt: new Date('2024-06-15T09:15:00'),
      data: { dueDate: '2024-06-18', amount: 120 }
    },
    {
      id: '3',
      type: 'goal_achieved',
      title: 'Meta Alcançada! 🎉',
      message: 'Parabéns! Você alcançou sua meta de economia de R$ 5.000,00',
      priority: 'low',
      read: true,
      createdAt: new Date('2024-06-14T16:45:00'),
      data: { goalName: 'Fundo de Emergência', targetAmount: 5000 }
    },
    {
      id: '4',
      type: 'anomaly_detected',
      title: 'Transação Incomum Detectada',
      message: 'Detectamos uma transação de R$ 2.500,00 em "Eletrônicos" - 300% acima do normal',
      priority: 'high',
      read: true,
      createdAt: new Date('2024-06-14T11:20:00'),
      data: { amount: 2500, category: 'Eletrônicos', averageAmount: 625 }
    }
  ])

  // Merge realtime notifications with existing ones
  useEffect(() => {
    if (realtimeNotifications.length > 0) {
      const newNotifications = realtimeNotifications.map(rn => ({
        id: rn.id,
        type: rn.type as any,
        title: rn.title,
        message: rn.message,
        priority: rn.priority as any,
        read: rn.read,
        createdAt: new Date(rn.createdAt),
        data: rn.data
      }))
      
      setNotifications(prev => {
        const existingIds = new Set(prev.map(n => n.id))
        const uniqueNew = newNotifications.filter(n => !existingIds.has(n.id))
        return [...uniqueNew, ...prev]
      })
    }
  }, [realtimeNotifications])

  // Request notification permission on mount
  useEffect(() => {
    requestNotificationPermission()
  }, [])

  const [rules, setRules] = useState<NotificationRule[]>([
    {
      id: '1',
      name: 'Alertas de Orçamento',
      type: 'budget_alert',
      enabled: true,
      channels: ['email', 'push'],
      conditions: { threshold: 80 },
      createdAt: new Date('2024-06-01T00:00:00')
    },
    {
      id: '2',
      name: 'Lembretes de Contas',
      type: 'payment_reminder',
      enabled: true,
      channels: ['email', 'sms'],
      conditions: { daysBefore: 3 },
      createdAt: new Date('2024-06-01T00:00:00')
    },
    {
      id: '3',
      name: 'Metas Alcançadas',
      type: 'goal_achieved',
      enabled: true,
      channels: ['email', 'push'],
      conditions: { notifyOnAchievement: true },
      createdAt: new Date('2024-06-01T00:00:00')
    }
  ])

  const [newRuleDialog, setNewRuleDialog] = useState(false)
  const [editingRule, setEditingRule] = useState<NotificationRule | null>(null)

  const unreadCount = notifications.filter(n => !n.read).length

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'budget_alert':
        return <AlertTriangle className="h-4 w-4" />
      case 'payment_reminder':
        return <Calendar className="h-4 w-4" />
      case 'goal_achieved':
        return <CheckCircle className="h-4 w-4" />
      case 'anomaly_detected':
        return <TrendingUp className="h-4 w-4" />
      case 'insight_ready':
        return <DollarSign className="h-4 w-4" />
      default:
        return <Bell className="h-4 w-4" />
    }
  }

  const getNotificationColor = (priority: string) => {
    switch (priority) {
      case 'high':
        return 'text-red-600 bg-red-50 border-red-200'
      case 'medium':
        return 'text-yellow-600 bg-yellow-50 border-yellow-200'
      case 'low':
        return 'text-green-600 bg-green-50 border-green-200'
      default:
        return 'text-gray-600 bg-gray-50 border-gray-200'
    }
  }

  const getChannelIcon = (channel: string) => {
    switch (channel) {
      case 'email':
        return <Mail className="h-4 w-4" />
      case 'push':
        return <Smartphone className="h-4 w-4" />
      case 'sms':
        return <MessageSquare className="h-4 w-4" />
      default:
        return <Bell className="h-4 w-4" />
    }
  }

  const markAsRead = (id: string) => {
    setNotifications(prev => 
      prev.map(n => n.id === id ? { ...n, read: true } : n)
    )
    // Also mark as read via WebSocket
    markNotificationRead(id)
  }

  const markAllAsRead = () => {
    setNotifications(prev => 
      prev.map(n => ({ ...n, read: true }))
    )
  }

  const deleteNotification = (id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id))
  }

  const toggleRule = (id: string) => {
    setRules(prev => 
      prev.map(r => r.id === id ? { ...r, enabled: !r.enabled } : r)
    )
  }

  const deleteRule = (id: string) => {
    setRules(prev => prev.filter(r => r.id !== id))
  }

  const createRule = (ruleData: Partial<NotificationRule>) => {
    const newRule: NotificationRule = {
      id: Date.now().toString(),
      name: ruleData.name || 'Nova Regra',
      type: ruleData.type || 'budget_alert',
      enabled: true,
      channels: ruleData.channels || ['email'],
      conditions: ruleData.conditions || {},
      createdAt: new Date()
    }
    setRules(prev => [...prev, newRule])
    setNewRuleDialog(false)
  }

  const updateRule = (id: string, updates: Partial<NotificationRule>) => {
    setRules(prev => 
      prev.map(r => r.id === id ? { ...r, ...updates } : r)
    )
    setEditingRule(null)
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Centro de Notificações</h2>
          <p className="text-muted-foreground">
            Gerencie alertas e notificações financeiras
          </p>
        </div>
        <div className="flex items-center gap-2">
          {/* Connection Status */}
          <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-muted">
            {isConnected ? (
              <>
                <Wifi className="h-4 w-4 text-green-500" />
                <span className="text-sm text-green-600">Conectado</span>
              </>
            ) : (
              <>
                <WifiOff className="h-4 w-4 text-red-500" />
                <span className="text-sm text-red-600">Desconectado</span>
              </>
            )}
          </div>
          
          {unreadCount > 0 && (
            <Button variant="outline" onClick={markAllAsRead}>
              Marcar todas como lidas
            </Button>
          )}
          <Dialog open={newRuleDialog} onOpenChange={setNewRuleDialog}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Nova Regra
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Criar Nova Regra de Notificação</DialogTitle>
                <DialogDescription>
                  Configure quando e como você deseja receber notificações
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="rule-name">Nome da Regra</Label>
                  <Input id="rule-name" placeholder="Ex: Alertas de Orçamento" />
                </div>
                <div>
                  <Label htmlFor="rule-type">Tipo de Notificação</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione o tipo" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="budget_alert">Alerta de Orçamento</SelectItem>
                      <SelectItem value="payment_reminder">Lembrete de Pagamento</SelectItem>
                      <SelectItem value="goal_achieved">Meta Alcançada</SelectItem>
                      <SelectItem value="anomaly_detected">Anomalia Detectada</SelectItem>
                      <SelectItem value="insight_ready">Insight Pronto</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Canais de Notificação</Label>
                  <div className="flex gap-4 mt-2">
                    <div className="flex items-center space-x-2">
                      <Switch id="email" />
                      <Label htmlFor="email">Email</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Switch id="push" />
                      <Label htmlFor="push">Push</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Switch id="sms" />
                      <Label htmlFor="sms">SMS</Label>
                    </div>
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setNewRuleDialog(false)}>
                  Cancelar
                </Button>
                <Button onClick={() => createRule({})}>
                  Criar Regra
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <Tabs defaultValue="notifications" className="space-y-4">
        <TabsList>
          <TabsTrigger value="notifications" className="flex items-center gap-2">
            <Bell className="h-4 w-4" />
            Notificações
            {unreadCount > 0 && (
              <Badge variant="destructive" className="h-5 w-5 rounded-full p-0 text-xs">
                {unreadCount}
              </Badge>
            )}
          </TabsTrigger>
          <TabsTrigger value="rules" className="flex items-center gap-2">
            <Settings className="h-4 w-4" />
            Regras
          </TabsTrigger>
        </TabsList>

        <TabsContent value="notifications" className="space-y-4">
          <div className="grid gap-4">
            {notifications.length === 0 ? (
              <Card>
                <CardContent className="flex items-center justify-center py-12">
                  <div className="text-center">
                    <BellOff className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                    <h3 className="text-lg font-semibold">Nenhuma notificação</h3>
                    <p className="text-muted-foreground">
                      Você não tem notificações no momento.
                    </p>
                  </div>
                </CardContent>
              </Card>
            ) : (
              notifications.map((notification) => (
                <Card 
                  key={notification.id} 
                  className={`transition-all hover:shadow-md ${
                    !notification.read ? 'border-l-4 border-l-blue-500' : ''
                  }`}
                >
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between">
                      <div className="flex items-start space-x-4">
                        <div className={`p-2 rounded-full ${getNotificationColor(notification.priority)}`}>
                          {getNotificationIcon(notification.type)}
                        </div>
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <h3 className="font-semibold">{notification.title}</h3>
                            {!notification.read && (
                              <Badge variant="secondary" className="text-xs">
                                Nova
                              </Badge>
                            )}
                          </div>
                          <p className="text-muted-foreground">{notification.message}</p>
                          <div className="flex items-center gap-4 text-xs text-muted-foreground">
                            <span>
                              {notification.createdAt.toLocaleDateString('pt-BR')} às{' '}
                              {notification.createdAt.toLocaleTimeString('pt-BR', { 
                                hour: '2-digit', 
                                minute: '2-digit' 
                              })}
                            </span>
                            <Badge variant="outline" className="text-xs">
                              {notification.priority === 'high' ? 'Alta' : 
                               notification.priority === 'medium' ? 'Média' : 'Baixa'}
                            </Badge>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        {!notification.read && (
                          <Button 
                            variant="ghost" 
                            size="sm"
                            onClick={() => markAsRead(notification.id)}
                          >
                            Marcar como lida
                          </Button>
                        )}
                        <Button 
                          variant="ghost" 
                          size="sm"
                          onClick={() => deleteNotification(notification.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </TabsContent>

        <TabsContent value="rules" className="space-y-4">
          <div className="grid gap-4">
            {rules.map((rule) => (
              <Card key={rule.id}>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div className="space-y-2">
                      <div className="flex items-center gap-3">
                        <h3 className="font-semibold">{rule.name}</h3>
                        <Badge variant={rule.enabled ? "default" : "secondary"}>
                          {rule.enabled ? 'Ativa' : 'Inativa'}
                        </Badge>
                      </div>
                      <div className="flex items-center gap-4 text-sm text-muted-foreground">
                        <div className="flex items-center gap-2">
                          {getNotificationIcon(rule.type)}
                          <span>
                            {rule.type === 'budget_alert' ? 'Alerta de Orçamento' :
                             rule.type === 'payment_reminder' ? 'Lembrete de Pagamento' :
                             rule.type === 'goal_achieved' ? 'Meta Alcançada' :
                             rule.type === 'anomaly_detected' ? 'Anomalia Detectada' :
                             'Insight Pronto'}
                          </span>
                        </div>
                        <div className="flex items-center gap-2">
                          {rule.channels.map(channel => (
                            <div key={channel} className="flex items-center gap-1">
                              {getChannelIcon(channel)}
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Switch 
                        checked={rule.enabled}
                        onCheckedChange={() => toggleRule(rule.id)}
                      />
                      <Button 
                        variant="ghost" 
                        size="sm"
                        onClick={() => setEditingRule(rule)}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="sm"
                        onClick={() => deleteRule(rule.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}