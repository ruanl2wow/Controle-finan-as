import { withAuth } from 'next-auth/middleware'

export default withAuth(
  function middleware(req) {
    // Lógica adicional do middleware pode ser adicionada aqui
  },
  {
    callbacks: {
      authorized: ({ token, req }) => {
        // Permitir acesso às páginas de autenticação sem login
        if (req.nextUrl.pathname.startsWith('/auth/')) {
          return true
        }
        
        // Permitir acesso à página inicial (redirecionará para login se não autenticado)
        if (req.nextUrl.pathname === '/') {
          return true
        }
        
        // Para outras rotas, exigir autenticação
        return !!token
      },
    },
  }
)

export const config = {
  matcher: [
    /*
     * Match all request paths except for the ones starting with:
     * - api (API routes)
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon file)
     * - public (public files)
     */
    '/((?!api|_next/static|_next/image|favicon.ico|public).*)',
  ],
}