'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from '@/components/ui/dialog'
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select'
import { 
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from '@/components/ui/dropdown-menu'
import { Switch } from '@/components/ui/switch'
import { 
  Plus, 
  Edit, 
  Trash2, 
  MoreHorizontal,
  Tag,
  Settings,
  TrendingUp,
  TrendingDown,
  ShoppingCart,
  Car,
  Utensils,
  Pill,
  Home,
  GraduationCap,
  Shirt,
  Heart
} from 'lucide-react'

interface Category {
  id: string
  name: string
  description?: string
  color: string
  icon?: string
  type: 'income' | 'expense'
  totalSpent?: number
  transactionCount?: number
}

interface Rule {
  id: string
  name: string
  condition: any
  action: any
  priority: number
  isActive: boolean
  category?: Category
  transactionsAffected?: number
}

const defaultCategories: Omit<Category, 'id'>[] = [
  { name: 'Mercado', color: '#F59E0B', icon: 'ShoppingCart', type: 'expense' },
  { name: 'Restaurante', color: '#EF4444', icon: 'Utensils', type: 'expense' },
  { name: 'Transporte', color: '#3B82F6', icon: 'Car', type: 'expense' },
  { name: 'Farmácia', color: '#10B981', icon: 'Pill', type: 'expense' },
  { name: 'Moradia', color: '#8B5CF6', icon: 'Home', type: 'expense' },
  { name: 'Educação', color: '#06B6D4', icon: 'GraduationCap', type: 'expense' },
  { name: 'Vestuário', color: '#EC4899', icon: 'Shirt', type: 'expense' },
  { name: 'Saúde', color: '#F97316', icon: 'Heart', type: 'expense' },
  { name: 'Receita', color: '#22C55E', icon: 'TrendingUp', type: 'income' },
]

const iconMap: Record<string, any> = {
  ShoppingCart,
  Utensils,
  Car,
  Pill,
  Home,
  GraduationCap,
  Shirt,
  Heart,
  TrendingUp,
  TrendingDown,
}

export default function CategoriasPage() {
  const [categories, setCategories] = useState<Category[]>([])
  const [rules, setRules] = useState<Rule[]>([])
  const [showCategoryDialog, setShowCategoryDialog] = useState(false)
  const [showRuleDialog, setShowRuleDialog] = useState(false)
  const [editingCategory, setEditingCategory] = useState<Category | null>(null)
  const [editingRule, setEditingRule] = useState<Rule | null>(null)
  const [activeTab, setActiveTab] = useState<'categories' | 'rules'>('categories')

  // Form states
  const [categoryForm, setCategoryForm] = useState({
    name: '',
    description: '',
    color: '#6B7280',
    icon: 'Tag',
    type: 'expense' as 'income' | 'expense',
  })

  const [ruleForm, setRuleForm] = useState({
    name: '',
    conditionType: 'keyword',
    keyword: '',
    categoryId: '',
    priority: 0,
    isActive: true,
  })

  useEffect(() => {
    fetchData()
  }, [])

  const fetchData = async () => {
    try {
      // Fetch categories
      const categoriesResponse = await fetch('/api/categories')
      const categoriesData = await categoriesResponse.json()
      
      if (categoriesData.categories.length === 0) {
        // Create default categories
        for (const category of defaultCategories) {
          await fetch('/api/categories', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(category),
          })
        }
        fetchData() // Refetch after creating defaults
      } else {
        setCategories(categoriesData.categories)
      }

      // Fetch rules
      const rulesResponse = await fetch('/api/rules')
      const rulesData = await rulesResponse.json()
      setRules(rulesData.rules || [])
    } catch (error) {
      console.error('Error fetching data:', error)
    }
  }

  const saveCategory = async () => {
    try {
      const url = editingCategory 
        ? `/api/categories/${editingCategory.id}`
        : '/api/categories'
      const method = editingCategory ? 'PUT' : 'POST'
      
      const response = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(categoryForm),
      })

      if (response.ok) {
        setShowCategoryDialog(false)
        setEditingCategory(null)
        setCategoryForm({
          name: '',
          description: '',
          color: '#6B7280',
          icon: 'Tag',
          type: 'expense',
        })
        fetchData()
      }
    } catch (error) {
      console.error('Error saving category:', error)
    }
  }

  const saveRule = async () => {
    try {
      const ruleData = {
        name: ruleForm.name,
        condition: {
          type: ruleForm.conditionType,
          keyword: ruleForm.keyword,
        },
        action: {
          categoryId: ruleForm.categoryId,
        },
        priority: ruleForm.priority,
        isActive: ruleForm.isActive,
      }

      const response = await fetch('/api/rules', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(ruleData),
      })

      if (response.ok) {
        setShowRuleDialog(false)
        setEditingRule(null)
        setRuleForm({
          name: '',
          conditionType: 'keyword',
          keyword: '',
          categoryId: '',
          priority: 0,
          isActive: true,
        })
        fetchData()
      }
    } catch (error) {
      console.error('Error saving rule:', error)
    }
  }

  const deleteCategory = async (id: string) => {
    try {
      await fetch(`/api/categories/${id}`, { method: 'DELETE' })
      fetchData()
    } catch (error) {
      console.error('Error deleting category:', error)
    }
  }

  const deleteRule = async (id: string) => {
    try {
      await fetch(`/api/rules/${id}`, { method: 'DELETE' })
      fetchData()
    } catch (error) {
      console.error('Error deleting rule:', error)
    }
  }

  const toggleRule = async (id: string, isActive: boolean) => {
    try {
      await fetch(`/api/rules/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isActive }),
      })
      fetchData()
    } catch (error) {
      console.error('Error toggling rule:', error)
    }
  }

  const startEditCategory = (category: Category) => {
    setEditingCategory(category)
    setCategoryForm({
      name: category.name,
      description: category.description || '',
      color: category.color,
      icon: category.icon || 'Tag',
      type: category.type,
    })
    setShowCategoryDialog(true)
  }

  const startEditRule = (rule: Rule) => {
    setEditingRule(rule)
    setRuleForm({
      name: rule.name,
      conditionType: rule.condition?.type || 'keyword',
      keyword: rule.condition?.keyword || '',
      categoryId: rule.action?.categoryId || '',
      priority: rule.priority,
      isActive: rule.isActive,
    })
    setShowRuleDialog(true)
  }

  const getCategoryIcon = (iconName: string) => {
    const IconComponent = iconMap[iconName] || Tag
    return <IconComponent className="h-4 w-4" />
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Categorias & Regras</h1>
          <p className="text-muted-foreground">
            Gerencie categorias e regras de classificação automática
          </p>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex space-x-1 rounded-lg bg-muted p-1">
        <Button
          variant={activeTab === 'categories' ? 'default' : 'ghost'}
          onClick={() => setActiveTab('categories')}
          className="flex-1"
        >
          <Tag className="mr-2 h-4 w-4" />
          Categorias
        </Button>
        <Button
          variant={activeTab === 'rules' ? 'default' : 'ghost'}
          onClick={() => setActiveTab('rules')}
          className="flex-1"
        >
          <Settings className="mr-2 h-4 w-4" />
          Regras
        </Button>
      </div>

      {activeTab === 'categories' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-semibold">Categorias</h2>
            <Dialog open={showCategoryDialog} onOpenChange={setShowCategoryDialog}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="mr-2 h-4 w-4" />
                  Nova Categoria
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>
                    {editingCategory ? 'Editar Categoria' : 'Nova Categoria'}
                  </DialogTitle>
                  <DialogDescription>
                    Configure uma nova categoria para organizar suas transações
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-medium mb-2 block">Nome</label>
                    <Input
                      value={categoryForm.name}
                      onChange={(e) => setCategoryForm(prev => ({ ...prev, name: e.target.value }))}
                      placeholder="Nome da categoria"
                    />
                  </div>
                  
                  <div>
                    <label className="text-sm font-medium mb-2 block">Descrição</label>
                    <Input
                      value={categoryForm.description}
                      onChange={(e) => setCategoryForm(prev => ({ ...prev, description: e.target.value }))}
                      placeholder="Descrição opcional"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm font-medium mb-2 block">Tipo</label>
                      <Select 
                        value={categoryForm.type} 
                        onValueChange={(value: 'income' | 'expense') => 
                          setCategoryForm(prev => ({ ...prev, type: value }))
                        }
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="income">Receita</SelectItem>
                          <SelectItem value="expense">Despesa</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <label className="text-sm font-medium mb-2 block">Cor</label>
                      <Input
                        type="color"
                        value={categoryForm.color}
                        onChange={(e) => setCategoryForm(prev => ({ ...prev, color: e.target.value }))}
                      />
                    </div>
                  </div>

                  <div className="flex justify-end space-x-2">
                    <Button variant="outline" onClick={() => setShowCategoryDialog(false)}>
                      Cancelar
                    </Button>
                    <Button onClick={saveCategory}>
                      {editingCategory ? 'Atualizar' : 'Criar'} Categoria
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>

          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {categories.map((category) => (
              <Card key={category.id} className="hover:shadow-md transition-shadow">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <div className="flex items-center space-x-2">
                    <div 
                      className="p-2 rounded-lg"
                      style={{ backgroundColor: `${category.color}20` }}
                    >
                      {getCategoryIcon(category.icon || 'Tag')}
                    </div>
                    <div>
                      <CardTitle className="text-sm">{category.name}</CardTitle>
                      <Badge variant={category.type === 'income' ? 'default' : 'secondary'}>
                        {category.type === 'income' ? 'Receita' : 'Despesa'}
                      </Badge>
                    </div>
                  </div>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" className="h-8 w-8">
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => startEditCategory(category)}>
                        <Edit className="mr-2 h-4 w-4" />
                        Editar
                      </DropdownMenuItem>
                      <DropdownMenuItem 
                        className="text-red-600"
                        onClick={() => deleteCategory(category.id)}
                      >
                        <Trash2 className="mr-2 h-4 w-4" />
                        Excluir
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </CardHeader>
                <CardContent>
                  {category.description && (
                    <p className="text-sm text-muted-foreground mb-2">
                      {category.description}
                    </p>
                  )}
                  <div className="text-xs text-muted-foreground">
                    {category.transactionCount || 0} transações
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {activeTab === 'rules' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-semibold">Regras de Classificação</h2>
            <Dialog open={showRuleDialog} onOpenChange={setShowRuleDialog}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="mr-2 h-4 w-4" />
                  Nova Regra
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>
                    {editingRule ? 'Editar Regra' : 'Nova Regra'}
                  </DialogTitle>
                  <DialogDescription>
                    Crie regras para classificar transações automaticamente
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-medium mb-2 block">Nome da Regra</label>
                    <Input
                      value={ruleForm.name}
                      onChange={(e) => setRuleForm(prev => ({ ...prev, name: e.target.value }))}
                      placeholder="Ex: Classificar Uber"
                    />
                  </div>

                  <div>
                    <label className="text-sm font-medium mb-2 block">Condição</label>
                    <div className="space-y-2">
                      <Select 
                        value={ruleForm.conditionType} 
                        onValueChange={(value) => setRuleForm(prev => ({ ...prev, conditionType: value }))}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="keyword">Contém palavra-chave</SelectItem>
                          <SelectItem value="amount">Valor maior que</SelectItem>
                        </SelectContent>
                      </Select>
                      
                      {ruleForm.conditionType === 'keyword' && (
                        <Input
                          value={ruleForm.keyword}
                          onChange={(e) => setRuleForm(prev => ({ ...prev, keyword: e.target.value }))}
                          placeholder="Digite a palavra-chave"
                        />
                      )}
                    </div>
                  </div>

                  <div>
                    <label className="text-sm font-medium mb-2 block">Aplicar à Categoria</label>
                    <Select 
                      value={ruleForm.categoryId} 
                      onValueChange={(value) => setRuleForm(prev => ({ ...prev, categoryId: value }))}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione uma categoria" />
                      </SelectTrigger>
                  <SelectContent>
                        {categories.map(category => (
                          <SelectItem key={category.id} value={category.id}>
                            {category.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="flex items-center space-x-2">
                    <Switch
                      checked={ruleForm.isActive}
                      onCheckedChange={(checked) => setRuleForm(prev => ({ ...prev, isActive: checked }))}
                    />
                    <label className="text-sm font-medium">Regra ativa</label>
                  </div>

                  <div className="flex justify-end space-x-2">
                    <Button variant="outline" onClick={() => setShowRuleDialog(false)}>
                      Cancelar
                    </Button>
                    <Button onClick={saveRule}>
                      {editingRule ? 'Atualizar' : 'Criar'} Regra
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Regras Configuradas</CardTitle>
            </CardHeader>
            <CardContent>
              {rules.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <Settings className="mx-auto h-12 w-12 mb-4" />
                  <p>Nenhuma regra configurada ainda</p>
                  <p className="text-sm">Crie regras para classificar transações automaticamente</p>
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Nome</TableHead>
                      <TableHead>Condição</TableHead>
                      <TableHead>Categoria</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {rules.map((rule) => (
                      <TableRow key={rule.id}>
                        <TableCell className="font-medium">{rule.name}</TableCell>
                        <TableCell>
                          <Badge variant="outline">
                            {rule.condition?.type === 'keyword' 
                              ? `Contém: "${rule.condition?.keyword}"`
                              : 'Condição personalizada'
                            }
                          </Badge>
                        </TableCell>
                        <TableCell>
                          {rule.category && (
                            <Badge style={{ backgroundColor: rule.category.color + '20', color: rule.category.color }}>
                              {rule.category.name}
                            </Badge>
                          )}
                        </TableCell>
                        <TableCell>
                          <Switch
                            checked={rule.isActive}
                            onCheckedChange={(checked) => toggleRule(rule.id, checked)}
                          />
                        </TableCell>
                        <TableCell>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon" className="h-8 w-8">
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem onClick={() => startEditRule(rule)}>
                                <Edit className="mr-2 h-4 w-4" />
                                Editar
                              </DropdownMenuItem>
                              <DropdownMenuItem 
                                className="text-red-600"
                                onClick={() => deleteRule(rule.id)}
                              >
                                <Trash2 className="mr-2 h-4 w-4" />
                                Excluir
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}