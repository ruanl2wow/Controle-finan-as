'use client'

import { useState, useEffect, startTransition } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/optimized-tabs'
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select'
import { 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  CreditCard, 
  ArrowUpRight,
  ArrowDownRight,
  MoreHorizontal,
  BarChart3,
  PieChart,
  TrendingUp as TrendingUpIcon,
  Settings,
  Target,
  Download,
  Bell,
  Upload,
  HelpCircle
} from 'lucide-react'
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  PieChart as RechartsPieChart,
  Pie,
  Cell,
  BarChart,
  Bar
} from 'recharts'
import { TabProvider } from '@/contexts/tab-context'
import { 
  SuspenseWrapper,
  OptimizedTabContent,
  preloadComponents,
  AnalyticsDashboard,
  NotificationCenter,
  FileUploadManager,
  GoalsBudgetsManager,
  DataExport,
  SettingsPage,
  HelpCenter
} from '@/components/optimized-tabs-content'
import { StorageInfoDialog } from '@/components/storage-info-dialog'
import { AICategorization } from '@/components/ai-categorization'
import { RulesManager } from '@/components/rules-manager'
import { AuthGuard } from '@/components/auth-guard'

const monthlyData = [
  { month: 'Jan', receitas: 5000, despesas: 3200 },
  { month: 'Fev', receitas: 5200, despesas: 2800 },
  { month: 'Mar', receitas: 4800, despesas: 3500 },
  { month: 'Abr', receitas: 5500, despesas: 2900 },
  { month: 'Mai', receitas: 6000, despesas: 3100 },
  { month: 'Jun', receitas: 5800, despesas: 3300 },
]

const categoryData = [
  { name: 'Restaurante', value: 1200, color: '#EF4444' },
  { name: 'Mercado', value: 800, color: '#F59E0B' },
  { name: 'Transporte', value: 600, color: '#3B82F6' },
  { name: 'Farmácia', value: 400, color: '#10B981' },
  { name: 'Lazer', value: 300, color: '#8B5CF6' },
  { name: 'Outros', value: 500, color: '#6B7280' },
]

const recentTransactions = [
  { id: 1, description: 'Supermercado Extra', category: 'Mercado', amount: -250.50, date: '12/06/2024' },
  { id: 2, description: 'Salário', category: 'Receita', amount: 5800.00, date: '10/06/2024' },
  { id: 3, description: 'Uber Viagem', category: 'Transporte', amount: -45.30, date: '09/06/2024' },
  { id: 4, description: 'Restaurante Italiano', category: 'Restaurante', amount: -180.00, date: '08/06/2024' },
  { id: 5, description: 'Farmácia', category: 'Farmácia', amount: -89.90, date: '07/06/2024' },
]

function DashboardContent() {
  const currentBalance = 12500.00
  const monthlyIncome = 5800.00
  const monthlyExpenses = 3300.00
  const savingsRate = ((monthlyIncome - monthlyExpenses) / monthlyIncome * 100).toFixed(1)

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
          <p className="text-muted-foreground">
            Visão geral das suas finanças
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Select defaultValue="current-month">
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Selecione o período" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="current-month">Mês Atual</SelectItem>
              <SelectItem value="last-month">Mês Anterior</SelectItem>
              <SelectItem value="last-3-months">Últimos 3 Meses</SelectItem>
              <SelectItem value="current-year">Ano Atual</SelectItem>
            </SelectContent>
          </Select>
          <Button>
            <ArrowUpRight className="mr-2 h-4 w-4" />
            Novo Upload
          </Button>
        </div>
      </div>

      {/* Cards Principais */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Saldo Atual</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">R$ {currentBalance.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</div>
            <p className="text-xs text-muted-foreground">
              <span className="flex items-center text-green-600">
                <TrendingUp className="h-3 w-3 mr-1" />
                +12.5% vs mês anterior
              </span>
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Receitas</CardTitle>
            <TrendingUp className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">+R$ {monthlyIncome.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</div>
            <p className="text-xs text-muted-foreground">
              <span className="flex items-center text-green-600">
                <ArrowUpRight className="h-3 w-3 mr-1" />
                +8.2% vs mês anterior
              </span>
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Despesas</CardTitle>
            <TrendingDown className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">-R$ {monthlyExpenses.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</div>
            <p className="text-xs text-muted-foreground">
              <span className="flex items-center text-red-600">
                <ArrowDownRight className="h-3 w-3 mr-1" />
                -5.1% vs mês anterior
              </span>
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Taxa de Economia</CardTitle>
            <CreditCard className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{savingsRate}%</div>
            <p className="text-xs text-muted-foreground">
              <span className="flex items-center text-green-600">
                <TrendingUp className="h-3 w-3 mr-1" />
                Acima da meta (20%)
              </span>
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Gráficos */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
        <Card className="col-span-4">
          <CardHeader>
            <CardTitle>Receitas vs Despesas</CardTitle>
          </CardHeader>
          <CardContent className="pl-2">
            <ResponsiveContainer width="100%" height={350}>
              <LineChart data={monthlyData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip 
                  formatter={(value: number) => [`R$ ${value.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`, '']}
                />
                <Line 
                  type="monotone" 
                  dataKey="receitas" 
                  stroke="#22C55E" 
                  strokeWidth={2}
                  name="Receitas"
                />
                <Line 
                  type="monotone" 
                  dataKey="despesas" 
                  stroke="#EF4444" 
                  strokeWidth={2}
                  name="Despesas"
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="col-span-3">
          <CardHeader>
            <CardTitle>Despesas por Categoria</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={350}>
              <RechartsPieChart>
                <Pie
                  data={categoryData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {categoryData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip formatter={(value: number) => [`R$ ${value.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`, '']} />
              </RechartsPieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Transações Recentes e Evolução Mensal */}
      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle>Transações Recentes</CardTitle>
              <CardDescription>Últimas movimentações</CardDescription>
            </div>
            <Button variant="outline" size="sm">
              <MoreHorizontal className="h-4 w-4" />
            </Button>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentTransactions.map((transaction) => (
                <div key={transaction.id} className="flex items-center justify-between">
                  <div className="space-y-1">
                    <p className="text-sm font-medium leading-none">
                      {transaction.description}
                    </p>
                    <p className="text-sm text-muted-foreground">
                      {transaction.category} • {transaction.date}
                    </p>
                  </div>
                  <div className="font-medium">
                    <span className={transaction.amount > 0 ? 'text-green-600' : 'text-red-600'}>
                      {transaction.amount > 0 ? '+' : ''}R$ {Math.abs(transaction.amount).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Evolução Mensal</CardTitle>
            <CardDescription>Receitas e despesas dos últimos 6 meses</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={monthlyData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip formatter={(value: number) => [`R$ ${value.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`, '']} />
                <Bar dataKey="receitas" fill="#22C55E" />
                <Bar dataKey="despesas" fill="#EF4444" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Storage Info Card */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="h-5 w-5 text-blue-500" />
            Segurança e Armazenamento
          </CardTitle>
          <CardDescription>
            Saiba onde seus dados financeiros são armazenados
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <p className="text-sm text-muted-foreground">
                Seus dados são armazenados com segurança em nosso servidor local, 
                com criptografia e isolamento completos.
              </p>
              <div className="flex items-center gap-2 text-xs text-green-600">
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                Servidor seguro • Dados criptografados • Backup automático
              </div>
            </div>
            <StorageInfoDialog />
          </div>
        </CardContent>
      </Card>

      {/* AI Categorization */}
      <AICategorization 
        transactions={recentTransactions.map(t => ({
          ...t,
          id: t.id.toString(),
          date: t.date,
          aiCategorized: false
        }))}
      />

      {/* Rules Manager */}
      <RulesManager />
    </div>
  )
}

export default function Dashboard() {
  return (
    <AuthGuard>
      <DashboardContent />
    </AuthGuard>
  )
}

function DashboardContent() {
  const [activeTab, setActiveTab] = useState('overview')
  const [isTransitioning, setIsTransitioning] = useState(false)

  // Pré-carregar componentes após o mount
  useEffect(() => {
    preloadComponents()
  }, [])

  const handleTabChange = (value: string) => {
    if (value === activeTab || isTransitioning) return
    
    setIsTransitioning(true)
    startTransition(() => {
      setActiveTab(value)
      // Pré-carregar o próximo componente baseado no uso
      if (value === 'help') {
        import('@/components/help-center')
      }
      setTimeout(() => setIsTransitioning(false), 300)
    })
  }

  // Preload estratégico baseado em hover
  const handleTabHover = (value: string) => {
    if (value !== activeTab) {
      requestIdleCallback(() => {
        switch (value) {
          case 'help':
            import('@/components/help-center')
            break
          case 'analytics':
            import('@/components/analytics-dashboard')
            break
          case 'upload':
            import('@/components/file-upload-manager')
            break
        }
      })
    }
  }

  return (
    <TabProvider>
      <div className="space-y-6">
        <Tabs value={activeTab} onValueChange={handleTabChange} className="space-y-4">
          <TabsList className="grid w-full grid-cols-8">
            <TabsTrigger 
              value="overview" 
              className="flex items-center gap-2"
              onMouseEnter={() => handleTabHover('overview')}
            >
              <BarChart3 className="h-4 w-4" />
              <span className="hidden sm:inline">Visão Geral</span>
            </TabsTrigger>
            <TabsTrigger 
              value="upload" 
              className="flex items-center gap-2"
              onMouseEnter={() => handleTabHover('upload')}
            >
              <Upload className="h-4 w-4" />
              <span className="hidden sm:inline">Upload</span>
            </TabsTrigger>
            <TabsTrigger 
              value="analytics" 
              className="flex items-center gap-2"
              onMouseEnter={() => handleTabHover('analytics')}
            >
              <TrendingUpIcon className="h-4 w-4" />
              <span className="hidden sm:inline">Análise</span>
            </TabsTrigger>
            <TabsTrigger 
              value="notifications" 
              className="flex items-center gap-2"
              onMouseEnter={() => handleTabHover('notifications')}
            >
              <Bell className="h-4 w-4" />
              <span className="hidden sm:inline">Notificações</span>
            </TabsTrigger>
            <TabsTrigger 
              value="goals-budgets" 
              className="flex items-center gap-2"
              onMouseEnter={() => handleTabHover('goals-budgets')}
            >
              <Target className="h-4 w-4" />
              <span className="hidden sm:inline">Metas</span>
            </TabsTrigger>
            <TabsTrigger 
              value="export" 
              className="flex items-center gap-2"
              onMouseEnter={() => handleTabHover('export')}
            >
              <Download className="h-4 w-4" />
              <span className="hidden sm:inline">Exportar</span>
            </TabsTrigger>
            <TabsTrigger 
              value="settings" 
              className="flex items-center gap-2"
              onMouseEnter={() => handleTabHover('settings')}
            >
              <Settings className="h-4 w-4" />
              <span className="hidden sm:inline">Config</span>
            </TabsTrigger>
            <TabsTrigger 
              value="help" 
              className="flex items-center gap-2"
              onMouseEnter={() => handleTabHover('help')}
            >
              <HelpCircle className="h-4 w-4" />
              <span className="hidden sm:inline">Ajuda</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview">
            <DashboardContent />
          </TabsContent>

          <TabsContent value="upload">
            <OptimizedTabContent value="upload">
              <SuspenseWrapper>
                <FileUploadManager />
              </SuspenseWrapper>
            </OptimizedTabContent>
          </TabsContent>

          <TabsContent value="analytics">
            <OptimizedTabContent value="analytics">
              <SuspenseWrapper>
                <AnalyticsDashboard />
              </SuspenseWrapper>
            </OptimizedTabContent>
          </TabsContent>

          <TabsContent value="notifications">
            <OptimizedTabContent value="notifications">
              <SuspenseWrapper>
                <NotificationCenter />
              </SuspenseWrapper>
            </OptimizedTabContent>
          </TabsContent>

          <TabsContent value="goals-budgets">
            <OptimizedTabContent value="goals-budgets">
              <SuspenseWrapper>
                <GoalsBudgetsManager />
              </SuspenseWrapper>
            </OptimizedTabContent>
          </TabsContent>

          <TabsContent value="export">
            <OptimizedTabContent value="export">
              <SuspenseWrapper>
                <DataExport />
              </SuspenseWrapper>
            </OptimizedTabContent>
          </TabsContent>

          <TabsContent value="settings">
            <OptimizedTabContent value="settings">
              <SuspenseWrapper>
                <SettingsPage />
              </SuspenseWrapper>
            </OptimizedTabContent>
          </TabsContent>

          <TabsContent value="help">
            <OptimizedTabContent value="help">
              <SuspenseWrapper>
                <HelpCenter />
              </SuspenseWrapper>
            </OptimizedTabContent>
          </TabsContent>
        </Tabs>
      </div>
    </TabProvider>
  )
}