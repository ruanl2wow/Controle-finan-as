'use client'

import { useState, useEffect, useCallback } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Checkbox } from '@/components/ui/checkbox'
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select'
import { 
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from '@/components/ui/dropdown-menu'
import { 
  Search, 
  Upload, 
  Download, 
  Filter,
  Edit,
  Trash2,
  MoreHorizontal,
  ChevronLeft,
  ChevronRight,
  Plus
} from 'lucide-react'

interface Transaction {
  id: string
  date: string
  description: string
  category: string
  amount: number
  type: 'income' | 'expense'
  account: string
  tags: string[]
}

const mockTransactions: Transaction[] = [
  { id: '1', date: '2024-06-12', description: 'Supermercado Extra', category: 'Mercado', amount: -250.50, type: 'expense', account: 'Conta Corrente', tags: ['essencial'] },
  { id: '2', date: '2024-06-10', description: 'Salário Mensal', category: 'Receita', amount: 5800.00, type: 'income', account: 'Conta Corrente', tags: ['salario'] },
  { id: '3', date: '2024-06-09', description: 'Uber Viagem', category: 'Transporte', amount: -45.30, type: 'expense', account: 'Cartão Crédito', tags: ['trabalho'] },
  { id: '4', date: '2024-06-08', description: 'Restaurante Italiano', category: 'Restaurante', amount: -180.00, type: 'expense', account: 'Cartão Crédito', tags: ['lazer'] },
  { id: '5', date: '2024-06-07', description: 'Farmácia', category: 'Farmácia', amount: -89.90, type: 'expense', account: 'Conta Corrente', tags: ['saúde'] },
  { id: '6', date: '2024-06-05', description: 'Netflix', category: 'Entretenimento', amount: -49.90, type: 'expense', account: 'Cartão Crédito', tags: ['assinatura'] },
  { id: '7', date: '2024-06-03', description: 'Gasolina', category: 'Transporte', amount: -200.00, type: 'expense', account: 'Cartão Crédito', tags: ['carro'] },
  { id: '8', date: '2024-06-01', description: 'Aluguel', category: 'Moradia', amount: -1500.00, type: 'expense', account: 'Conta Corrente', tags: ['essencial'] },
]

const categories = [
  'Mercado', 'Restaurante', 'Transporte', 'Farmácia', 'Entretenimento', 
  'Moradia', 'Receita', 'Educação', 'Vestuário', 'Saúde', 'Outros'
]

const accounts = [
  'Conta Corrente', 'Cartão Crédito', 'Poupança', 'Investimento'
]

export default function PlanilhaPage() {
  const [transactions, setTransactions] = useState<Transaction[]>(mockTransactions)
  const [selectedIds, setSelectedIds] = useState<string[]>([])
  const [searchTerm, setSearchTerm] = useState('')
  const [filterCategory, setFilterCategory] = useState<string>('all')
  const [filterAccount, setFilterAccount] = useState<string>('all')
  const [editingCell, setEditingCell] = useState<{ id: string; field: keyof Transaction } | null>(null)
  const [editValue, setEditValue] = useState('')
  const [currentPage, setCurrentPage] = useState(1)
  const itemsPerPage = 10

  const filteredTransactions = transactions.filter(transaction => {
    const matchesSearch = transaction.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         transaction.category.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesCategory = filterCategory === 'all' || transaction.category === filterCategory
    const matchesAccount = filterAccount === 'all' || transaction.account === filterAccount
    return matchesSearch && matchesCategory && matchesAccount
  })

  const totalPages = Math.ceil(filteredTransactions.length / itemsPerPage)
  const startIndex = (currentPage - 1) * itemsPerPage
  const paginatedTransactions = filteredTransactions.slice(startIndex, startIndex + itemsPerPage)

  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      setSelectedIds(paginatedTransactions.map(t => t.id))
    } else {
      setSelectedIds([])
    }
  }

  const handleSelectOne = (id: string, checked: boolean) => {
    if (checked) {
      setSelectedIds(prev => [...prev, id])
    } else {
      setSelectedIds(prev => prev.filter(selectedId => selectedId !== id))
    }
  }

  const startEditing = (id: string, field: keyof Transaction, value: any) => {
    setEditingCell({ id, field })
    setEditValue(String(value))
  }

  const saveEdit = () => {
    if (editingCell) {
      setTransactions(prev => prev.map(transaction => {
        if (transaction.id === editingCell.id) {
          const updatedTransaction = { ...transaction }
          
          if (editingCell.field === 'amount') {
            updatedTransaction[editingCell.field] = parseFloat(editValue) || 0
            updatedTransaction.type = parseFloat(editValue) >= 0 ? 'income' : 'expense'
          } else {
            (updatedTransaction as any)[editingCell.field] = editValue
          }
          
          return updatedTransaction
        }
        return transaction
      }))
      setEditingCell(null)
      setEditValue('')
    }
  }

  const cancelEdit = () => {
    setEditingCell(null)
    setEditValue('')
  }

  const deleteTransaction = (id: string) => {
    setTransactions(prev => prev.filter(t => t.id !== id))
    setSelectedIds(prev => prev.filter(selectedId => selectedId !== id))
  }

  const bulkDelete = () => {
    setTransactions(prev => prev.filter(t => !selectedIds.includes(t.id)))
    setSelectedIds([])
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      saveEdit()
    } else if (e.key === 'Escape') {
      cancelEdit()
    }
  }

  const totalIncome = filteredTransactions
    .filter(t => t.type === 'income')
    .reduce((sum, t) => sum + t.amount, 0)

  const totalExpenses = Math.abs(filteredTransactions
    .filter(t => t.type === 'expense')
    .reduce((sum, t) => sum + t.amount, 0))

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Planilha</h1>
          <p className="text-muted-foreground">
            Gerencie suas transações em uma interface tipo planilha
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline">
            <Upload className="mr-2 h-4 w-4" />
            Upload
          </Button>
          <Button variant="outline">
            <Download className="mr-2 h-4 w-4" />
            Exportar
          </Button>
          <Button>
            <Plus className="mr-2 h-4 w-4" />
            Nova Transação
          </Button>
        </div>
      </div>

      {/* Filtros e Busca */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Filtros</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-4">
            <div className="flex-1 min-w-[200px]">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  placeholder="Buscar transações..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Select value={filterCategory} onValueChange={setFilterCategory}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Categoria" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todas Categorias</SelectItem>
                {categories.map(category => (
                  <SelectItem key={category} value={category}>{category}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={filterAccount} onValueChange={setFilterAccount}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Conta" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todas Contas</SelectItem>
                {accounts.map(account => (
                  <SelectItem key={account} value={account}>{account}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Resumo */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Receitas</p>
                <p className="text-2xl font-bold text-green-600">
                  +R$ {totalIncome.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Despesas</p>
                <p className="text-2xl font-bold text-red-600">
                  -R$ {totalExpenses.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Saldo</p>
                <p className={`text-2xl font-bold ${(totalIncome - totalExpenses) >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                  R$ {(totalIncome - totalExpenses).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Ações em Lote */}
      {selectedIds.length > 0 && (
        <Card className="border-blue-200 bg-blue-50/50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <p className="text-sm text-blue-700">
                {selectedIds.length} transação(ões) selecionada(s)
              </p>
              <div className="flex gap-2">
                <Button variant="outline" size="sm">
                  Reclassificar
                </Button>
                <Button variant="outline" size="sm" onClick={bulkDelete}>
                  <Trash2 className="mr-2 h-4 w-4" />
                  Excluir
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Tabela de Transações */}
      <Card>
        <CardHeader>
          <CardTitle>Transações</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-12">
                    <Checkbox
                      checked={selectedIds.length === paginatedTransactions.length && paginatedTransactions.length > 0}
                      onCheckedChange={handleSelectAll}
                    />
                  </TableHead>
                  <TableHead>Data</TableHead>
                  <TableHead>Descrição</TableHead>
                  <TableHead>Categoria</TableHead>
                  <TableHead>Conta</TableHead>
                  <TableHead className="text-right">Valor</TableHead>
                  <TableHead className="w-12"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {paginatedTransactions.map((transaction) => (
                  <TableRow key={transaction.id} className="hover:bg-muted/50">
                    <TableCell>
                      <Checkbox
                        checked={selectedIds.includes(transaction.id)}
                        onCheckedChange={(checked) => handleSelectOne(transaction.id, checked as boolean)}
                      />
                    </TableCell>
                    <TableCell>
                      {editingCell?.id === transaction.id && editingCell?.field === 'date' ? (
                        <Input
                          value={editValue}
                          onChange={(e) => setEditValue(e.target.value)}
                          onBlur={saveEdit}
                          onKeyDown={handleKeyDown}
                          className="h-8 w-28"
                          autoFocus
                        />
                      ) : (
                        <div 
                          className="cursor-pointer hover:bg-muted/50 px-2 py-1 rounded"
                          onClick={() => startEditing(transaction.id, 'date', transaction.date)}
                        >
                          {new Date(transaction.date).toLocaleDateString('pt-BR')}
                        </div>
                      )}
                    </TableCell>
                    <TableCell>
                      {editingCell?.id === transaction.id && editingCell?.field === 'description' ? (
                        <Input
                          value={editValue}
                          onChange={(e) => setEditValue(e.target.value)}
                          onBlur={saveEdit}
                          onKeyDown={handleKeyDown}
                          className="h-8 min-w-[200px]"
                          autoFocus
                        />
                      ) : (
                        <div 
                          className="cursor-pointer hover:bg-muted/50 px-2 py-1 rounded"
                          onClick={() => startEditing(transaction.id, 'description', transaction.description)}
                        >
                          {transaction.description}
                        </div>
                      )}
                    </TableCell>
                    <TableCell>
                      {editingCell?.id === transaction.id && editingCell?.field === 'category' ? (
                        <Select value={editValue} onValueChange={setEditValue}>
                          <SelectTrigger className="h-8 w-32" onBlur={saveEdit}>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {categories.map(category => (
                              <SelectItem key={category} value={category}>{category}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      ) : (
                        <div 
                          className="cursor-pointer hover:bg-muted/50 px-2 py-1 rounded"
                          onClick={() => startEditing(transaction.id, 'category', transaction.category)}
                        >
                          <Badge variant="secondary">{transaction.category}</Badge>
                        </div>
                      )}
                    </TableCell>
                    <TableCell>
                      {editingCell?.id === transaction.id && editingCell?.field === 'account' ? (
                        <Select value={editValue} onValueChange={setEditValue}>
                          <SelectTrigger className="h-8 w-32" onBlur={saveEdit}>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {accounts.map(account => (
                              <SelectItem key={account} value={account}>{account}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      ) : (
                        <div 
                          className="cursor-pointer hover:bg-muted/50 px-2 py-1 rounded"
                          onClick={() => startEditing(transaction.id, 'account', transaction.account)}
                        >
                          {transaction.account}
                        </div>
                      )}
                    </TableCell>
                    <TableCell className="text-right font-medium">
                      {editingCell?.id === transaction.id && editingCell?.field === 'amount' ? (
                        <Input
                          value={editValue}
                          onChange={(e) => setEditValue(e.target.value)}
                          onBlur={saveEdit}
                          onKeyDown={handleKeyDown}
                          className="h-16 w-24 text-right"
                          autoFocus
                        />
                      ) : (
                        <div 
                          className={`cursor-pointer hover:bg-muted/50 px-2 py-1 rounded ${
                            transaction.type === 'income' ? 'text-green-600' : 'text-red-600'
                          }`}
                          onClick={() => startEditing(transaction.id, 'amount', Math.abs(transaction.amount))}
                        >
                          {transaction.type === 'income' ? '+' : '-'}R$ {Math.abs(transaction.amount).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                        </div>
                      )}
                    </TableCell>
                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem>
                            <Edit className="mr-2 h-4 w-4" />
                            Editar
                          </DropdownMenuItem>
                          <DropdownMenuItem 
                            className="text-red-600"
                            onClick={() => deleteTransaction(transaction.id)}
                          >
                            <Trash2 className="mr-2 h-4 w-4" />
                            Excluir
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          {/* Paginação */}
          <div className="flex items-center justify-between px-2 py-4">
            <div className="text-sm text-muted-foreground">
              Mostrando {startIndex + 1} a {Math.min(startIndex + itemsPerPage, filteredTransactions.length)} de {filteredTransactions.length} transações
            </div>
            <div className="flex items-center space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                disabled={currentPage === 1}
              >
                <ChevronLeft className="h-4 w-4" />
                Anterior
              </Button>
              <div className="flex items-center space-x-1">
                {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                  const page = i + 1
                  return (
                    <Button
                      key={page}
                      variant={currentPage === page ? "default" : "outline"}
                      size="sm"
                      onClick={() => setCurrentPage(page)}
                    >
                      {page}
                    </Button>
                  )
                })}
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                disabled={currentPage === totalPages}
              >
                Próximo
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}