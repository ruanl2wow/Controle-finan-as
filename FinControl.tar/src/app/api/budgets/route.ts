import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.email) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const user = await db.user.findUnique({
      where: { email: session.user.email }
    })

    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 })
    }

    const { searchParams } = new URL(request.url)
    const period = searchParams.get('period') || 'monthly'
    const active = searchParams.get('active') !== 'false'

    const budgets = await db.budget.findMany({
      where: {
        userId: user.id,
        period,
        isActive: active
      },
      include: {
        category: true
      },
      orderBy: {
        createdAt: 'desc'
      }
    })

    // Calculate spent amounts for each budget
    const budgetsWithSpending = await Promise.all(
      budgets.map(async (budget) => {
        const spent = await calculateSpentAmount(budget.id, budget.categoryId, user.id, budget.startDate, budget.endDate)
        return {
          ...budget,
          spent,
          remaining: budget.amount - spent,
          percentageUsed: budget.amount > 0 ? (spent / budget.amount) * 100 : 0,
          isOverBudget: spent > budget.amount
        }
      })
    )

    return NextResponse.json({ budgets: budgetsWithSpending })
  } catch (error) {
    console.error('Error fetching budgets:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.email) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await request.json()
    const user = await db.user.findUnique({
      where: { email: session.user.email }
    })

    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 })
    }

    const budget = await db.budget.create({
      data: {
        ...body,
        userId: user.id,
        startDate: new Date(body.startDate),
        endDate: new Date(body.endDate)
      },
      include: {
        category: true
      }
    })

    return NextResponse.json({ budget })
  } catch (error) {
    console.error('Error creating budget:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

export async function PUT(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.email) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await request.json()
    const { id, ...updateData } = body

    const user = await db.user.findUnique({
      where: { email: session.user.email }
    })

    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 })
    }

    const budget = await db.budget.update({
      where: { 
        id,
        userId: user.id 
      },
      data: {
        ...updateData,
        startDate: updateData.startDate ? new Date(updateData.startDate) : undefined,
        endDate: updateData.endDate ? new Date(updateData.endDate) : undefined
      },
      include: {
        category: true
      }
    })

    return NextResponse.json({ budget })
  } catch (error) {
    console.error('Error updating budget:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.email) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const id = searchParams.get('id')

    if (!id) {
      return NextResponse.json({ error: 'Budget ID is required' }, { status: 400 })
    }

    const user = await db.user.findUnique({
      where: { email: session.user.email }
    })

    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 })
    }

    await db.budget.delete({
      where: { 
        id,
        userId: user.id 
      }
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Error deleting budget:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

async function calculateSpentAmount(
  budgetId: string, 
  categoryId: string | null, 
  userId: string, 
  startDate: Date, 
  endDate: Date
): Promise<number> {
  const whereClause: any = {
    userId,
    date: {
      gte: startDate,
      lte: endDate
    },
    type: 'expense'
  }

  if (categoryId) {
    whereClause.categoryId = categoryId
  }

  const result = await db.transaction.aggregate({
    where: whereClause,
    _sum: {
      amount: true
    }
  })

  return Math.abs(result._sum.amount || 0)
}