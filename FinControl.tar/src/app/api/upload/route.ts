import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { writeFile, mkdir } from 'fs/promises'
import { join } from 'path'
import { db } from '@/lib/db'

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const formData = await request.formData()
    const file = formData.get('file') as File
    const accountId = formData.get('accountId') as string

    if (!file) {
      return NextResponse.json({ error: 'No file provided' }, { status: 400 })
    }

    // Validate file type
    const allowedTypes = [
      'text/csv',
      'application/pdf',
      'application/xml',
      'text/xml',
      'application/ofx',
      'application/qif'
    ]

    if (!allowedTypes.includes(file.type) && !file.name.match(/\.(csv|ofx|qif|pdf)$/i)) {
      return NextResponse.json({ 
        error: 'Invalid file type. Only CSV, OFX, QIF, and PDF files are allowed.' 
      }, { status: 400 })
    }

    // Create uploads directory if it doesn't exist
    const uploadsDir = join(process.cwd(), 'uploads')
    try {
      await mkdir(uploadsDir, { recursive: true })
    } catch (error) {
      // Directory already exists
    }

    // Generate unique filename
    const timestamp = Date.now()
    const filename = `${timestamp}-${file.name}`
    const filepath = join(uploadsDir, filename)

    // Save file to disk
    const bytes = await file.arrayBuffer()
    const buffer = Buffer.from(bytes)
    await writeFile(filepath, buffer)

    // Determine file type from extension
    const fileType = file.name.toLowerCase().endsWith('.csv') ? 'csv' :
                    file.name.toLowerCase().endsWith('.ofx') ? 'ofx' :
                    file.name.toLowerCase().endsWith('.qif') ? 'qif' :
                    file.name.toLowerCase().endsWith('.pdf') ? 'pdf' : 'unknown'

    // Create upload record in database
    const upload = await db.upload.create({
      data: {
        filename,
        originalName: file.name,
        fileType,
        fileSize: file.size,
        status: 'pending',
        userId: session.user.id,
        accountId: accountId || null,
      },
    })

    // Start processing the file asynchronously
    processFile(upload.id, filepath, fileType).catch(console.error)

    return NextResponse.json({
      uploadId: upload.id,
      filename: file.name,
      size: file.size,
      type: fileType,
      status: 'pending'
    })

  } catch (error) {
    console.error('Error uploading file:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

async function processFile(uploadId: string, filepath: string, fileType: string) {
  try {
    // Update status to processing
    await db.upload.update({
      where: { id: uploadId },
      data: { status: 'processing' }
    })

    let transactions: any[] = []

    // Process file based on type
    switch (fileType) {
      case 'csv':
        transactions = await processCSV(filepath)
        break
      case 'ofx':
        transactions = await processOFX(filepath)
        break
      case 'qif':
        transactions = await processQIF(filepath)
        break
      case 'pdf':
        transactions = await processPDF(filepath)
        break
      default:
        throw new Error(`Unsupported file type: ${fileType}`)
    }

    // Get upload details
    const upload = await db.upload.findUnique({
      where: { id: uploadId },
      include: { user: true }
    })

    if (!upload) {
      throw new Error('Upload not found')
    }

    // Create transactions in database
    for (const transactionData of transactions) {
      await db.transaction.create({
        data: {
          date: transactionData.date,
          description: transactionData.description,
          amount: transactionData.amount,
          type: transactionData.amount > 0 ? 'income' : 'expense',
          userId: upload.userId,
          accountId: upload.accountId || '',
          uploadId: upload.id,
          metadata: transactionData.metadata ? JSON.stringify(transactionData.metadata) : null,
        }
      })
    }

    // Update upload status to completed
    await db.upload.update({
      where: { id: uploadId },
      data: { 
        status: 'completed',
        processedAt: new Date()
      }
    })

    // Trigger notification processing
    const { NotificationService } = await import('@/lib/notifications')
    await NotificationService.checkAndTriggerNotifications(upload.userId)

  } catch (error) {
    console.error('Error processing file:', error)
    
    // Update upload status to error
    await db.upload.update({
      where: { id: uploadId },
      data: { 
        status: 'error',
        error: error instanceof Error ? error.message : 'Unknown error'
      }
    })
  }
}

async function processCSV(filepath: string): Promise<any[]> {
  const fs = await import('fs/promises')
  const content = await fs.readFile(filepath, 'utf-8')
  const lines = content.split('\n').filter(line => line.trim())
  
  if (lines.length < 2) {
    throw new Error('CSV file is empty or invalid')
  }

  const transactions: any[] = []
  const headers = lines[0].split(',').map(h => h.trim().toLowerCase())
  
  for (let i = 1; i < lines.length; i++) {
    const values = lines[i].split(',').map(v => v.trim())
    const transaction: any = {}
    
    headers.forEach((header, index) => {
      const value = values[index]
      
      switch (header) {
        case 'date':
        case 'data':
          transaction.date = new Date(value)
          break
        case 'description':
        case 'descrição':
        case 'memo':
          transaction.description = value
          break
        case 'amount':
        case 'valor':
          transaction.amount = parseFloat(value.replace(/[R$\s]/g, '').replace(',', '.'))
          break
        default:
          if (!transaction.metadata) transaction.metadata = {}
          transaction.metadata[header] = value
      }
    })
    
    if (transaction.date && transaction.description && transaction.amount) {
      transactions.push(transaction)
    }
  }
  
  return transactions
}

async function processOFX(filepath: string): Promise<any[]> {
  // Simplified OFX processing - in production, use a proper OFX parser
  const fs = await import('fs/promises')
  const content = await fs.readFile(filepath, 'utf-8')
  
  const transactions: any[] = []
  
  // Extract transactions using regex
  const transactionRegex = /<STMTTRN>.*?<\/STMTTRN>/gs
  const matches = content.match(transactionRegex) || []
  
  for (const match of matches) {
    const dateMatch = match.match(/<DTPOSTED>([^<]+)/)
    const descMatch = match.match(/<NAME>([^<]+)/)
    const amountMatch = match.match(/<TRNAMT>([^<]+)/)
    
    if (dateMatch && descMatch && amountMatch) {
      const dateStr = dateMatch[1]
      const date = new Date(
        parseInt(dateStr.substring(0, 4)),
        parseInt(dateStr.substring(4, 6)) - 1,
        parseInt(dateStr.substring(6, 8))
      )
      
      transactions.push({
        date,
        description: descMatch[1].trim(),
        amount: parseFloat(amountMatch[1]),
        metadata: { raw: match }
      })
    }
  }
  
  return transactions
}

async function processQIF(filepath: string): Promise<any[]> {
  // Simplified QIF processing - in production, use a proper QIF parser
  const fs = await import('fs/promises')
  const content = await fs.readFile(filepath, 'utf-8')
  
  const transactions: any[] = []
  const lines = content.split('\n')
  
  let currentTransaction: any = {}
  
  for (const line of lines) {
    const trimmed = line.trim()
    
    if (trimmed.startsWith('D')) {
      // Date
      currentTransaction.date = new Date(trimmed.substring(1))
    } else if (trimmed.startsWith('T')) {
      // Amount
      currentTransaction.amount = parseFloat(trimmed.substring(1).replace(',', '.'))
    } else if (trimmed.startsWith('P')) {
      // Description
      currentTransaction.description = trimmed.substring(1)
    } else if (trimmed === '^') {
      // End of transaction
      if (currentTransaction.date && currentTransaction.description && currentTransaction.amount) {
        transactions.push({ ...currentTransaction })
      }
      currentTransaction = {}
    }
  }
  
  return transactions
}

async function processPDF(filepath: string): Promise<any[]> {
  // PDF processing would require a PDF parsing library
  // For now, return empty array and set error
  throw new Error('PDF processing not yet implemented. Please use CSV, OFX, or QIF files.')
}

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const status = searchParams.get('status')
    const limit = parseInt(searchParams.get('limit') || '20')

    const where: any = { userId: session.user.id }
    if (status) {
      where.status = status
    }

    const uploads = await db.upload.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      take: limit,
      include: {
        _count: {
          select: { transactions: true }
        }
      }
    })

    return NextResponse.json({ uploads })
  } catch (error) {
    console.error('Error fetching uploads:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}