import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { db } from '@/lib/db';
import { AICategorizationService } from '@/lib/ai-categorization';

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.email) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { transactions } = await request.json();

    if (!Array.isArray(transactions) || transactions.length === 0) {
      return NextResponse.json({ error: 'No transactions provided' }, { status: 400 });
    }

    // Get user from database
    const user = await db.user.findUnique({
      where: { email: session.user.email }
    });

    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }

    // Get AI categorizations
    const categorizations = await AICategorizationService.categorizeTransactions(transactions);

    // Update transactions with categories
    const updatedTransactions = [];
    for (let i = 0; i < transactions.length; i++) {
      const transaction = transactions[i];
      const categorization = categorizations[i];

      // Update transaction in database
      const updated = await db.transaction.update({
        where: { 
          id: transaction.id,
          userId: user.id 
        },
        data: {
          category: categorization.category,
          subcategory: categorization.subcategory,
          aiCategorized: true,
          aiConfidence: categorization.confidence,
          aiReasoning: categorization.reasoning
        }
      });

      updatedTransactions.push(updated);
    }

    return NextResponse.json({
      success: true,
      transactions: updatedTransactions,
      categorizations
    });

  } catch (error) {
    console.error('Categorization error:', error);
    return NextResponse.json(
      { error: 'Failed to categorize transactions', details: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 }
    );
  }
}