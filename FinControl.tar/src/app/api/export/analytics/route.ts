import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.email) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { data } = await request.json();

    // Generate CSV content
    const csvContent = generateCSV(data);
    
    // Generate HTML content for PDF
    const htmlContent = generateHTMLReport(data);

    // For now, return CSV content
    return new NextResponse(csvContent, {
      headers: {
        'Content-Type': 'text/csv',
        'Content-Disposition': `attachment; filename="financial-analytics-${new Date().toISOString().split('T')[0]}.csv"`,
      },
    });

  } catch (error) {
    console.error('Export analytics error:', error);
    return NextResponse.json(
      { error: 'Failed to export analytics' },
      { status: 500 }
    );
  }
}

function generateCSV(data: any): string {
  const headers = [
    'Métrica',
    'Valor',
    'Descrição'
  ];

  const rows = [
    ['Receita Total', data.summary.totalIncome.toFixed(2), 'Total de receitas no período'],
    ['Despesa Total', data.summary.totalExpenses.toFixed(2), 'Total de despesas no período'],
    ['Receita Líquida', data.summary.netIncome.toFixed(2), 'Receitas menos despesas'],
    ['Número de Transações', data.summary.transactionCount.toString(), 'Quantidade total de transações'],
    ['Receita Média', data.summary.avgIncome.toFixed(2), 'Valor médio das receitas'],
    ['Despesa Média', data.summary.avgExpense.toFixed(2), 'Valor médio das despesas'],
    ['Taxa de Economia', `${data.financialHealth.savingsRate.toFixed(2)}%`, 'Percentual de economia em relação à receita'],
    ['Relação Dívida/Renda', `${data.financialHealth.debtToIncome.toFixed(2)}%`, 'Percentual de despesas em relação à receita'],
    ['Tamanho Médio da Transação', data.financialHealth.avgTransactionSize.toFixed(2), 'Valor médio por transação'],
    ['Frequência de Transações', `${data.financialHealth.transactionFrequency.toFixed(2)}/dia`, 'Média de transações por dia'],
  ];

  // Add category breakdown
  rows.push(['', '', '']);
  rows.push(['Análise por Categoria', '', '']);
  rows.push(['Categoria', 'Receitas', 'Despesas', 'Transações', 'Saldo']);
  
  data.categoryBreakdown.forEach((category: any) => {
    rows.push([
      category.name,
      category.income.toFixed(2),
      category.expenses.toFixed(2),
      category.count.toString(),
      (category.income - category.expenses).toFixed(2)
    ]);
  });

  // Add monthly trends
  rows.push(['', '', '']);
  rows.push(['Tendências Mensais', '', '']);
  rows.push(['Mês', 'Receitas', 'Despesas', 'Transações', 'Saldo']);
  
  data.monthlyTrends.forEach((trend: any) => {
    rows.push([
      trend.month,
      trend.income.toFixed(2),
      trend.expenses.toFixed(2),
      trend.count.toString(),
      (trend.income - trend.expenses).toFixed(2)
    ]);
  });

  const csvContent = [
    headers.join(','),
    ...rows.map(row => row.map(cell => `"${cell}"`).join(','))
  ].join('\n');

  return csvContent;
}

function generateHTMLReport(data: any): string {
  return `
    <!DOCTYPE html>
    <html>
    <head>
      <title>Relatório de Análise Financeira</title>
      <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        .header { text-align: center; margin-bottom: 30px; }
        .summary { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 30px; }
        .metric { background: #f5f5f5; padding: 15px; border-radius: 8px; text-align: center; }
        .metric-value { font-size: 24px; font-weight: bold; color: #333; }
        .metric-label { font-size: 14px; color: #666; margin-top: 5px; }
        table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
        .positive { color: green; }
        .negative { color: red; }
      </style>
    </head>
    <body>
      <div class="header">
        <h1>Relatório de Análise Financeira</h1>
        <p>Período: ${new Date(data.dateRange.start).toLocaleDateString('pt-BR')} - ${new Date(data.dateRange.end).toLocaleDateString('pt-BR')}</p>
      </div>

      <div class="summary">
        <div class="metric">
          <div class="metric-value positive">R$ ${data.summary.totalIncome.toFixed(2)}</div>
          <div class="metric-label">Receita Total</div>
        </div>
        <div class="metric">
          <div class="metric-value negative">R$ ${data.summary.totalExpenses.toFixed(2)}</div>
          <div class="metric-label">Despesa Total</div>
        </div>
        <div class="metric">
          <div class="metric-value ${data.summary.netIncome >= 0 ? 'positive' : 'negative'}">R$ ${data.summary.netIncome.toFixed(2)}</div>
          <div class="metric-label">Receita Líquida</div>
        </div>
        <div class="metric">
          <div class="metric-value">${data.financialHealth.savingsRate.toFixed(1)}%</div>
          <div class="metric-label">Taxa de Economia</div>
        </div>
      </div>

      <h2>Análise por Categoria</h2>
      <table>
        <thead>
          <tr>
            <th>Categoria</th>
            <th>Receitas</th>
            <th>Despesas</th>
            <th>Transações</th>
            <th>Saldo</th>
          </tr>
        </thead>
        <tbody>
          ${data.categoryBreakdown.map((cat: any) => `
            <tr>
              <td>${cat.name}</td>
              <td class="positive">R$ ${cat.income.toFixed(2)}</td>
              <td class="negative">R$ ${cat.expenses.toFixed(2)}</td>
              <td>${cat.count}</td>
              <td class="${cat.income - cat.expenses >= 0 ? 'positive' : 'negative'}">R$ ${(cat.income - cat.expenses).toFixed(2)}</td>
            </tr>
          `).join('')}
        </tbody>
      </table>

      <h2>Tendências Mensais</h2>
      <table>
        <thead>
          <tr>
            <th>Mês</th>
            <th>Receitas</th>
            <th>Despesas</th>
            <th>Transações</th>
            <th>Saldo</th>
          </tr>
        </thead>
        <tbody>
          ${data.monthlyTrends.map((trend: any) => `
            <tr>
              <td>${trend.month}</td>
              <td class="positive">R$ ${trend.income.toFixed(2)}</td>
              <td class="negative">R$ ${trend.expenses.toFixed(2)}</td>
              <td>${trend.count}</td>
              <td class="${trend.income - trend.expenses >= 0 ? 'positive' : 'negative'}">R$ ${(trend.income - trend.expenses).toFixed(2)}</td>
            </tr>
          `).join('')}
        </tbody>
      </table>

      <h2>Indicadores de Saúde Financeira</h2>
      <table>
        <thead>
          <tr>
            <th>Indicador</th>
            <th>Valor</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>Taxa de Economia</td>
            <td>${data.financialHealth.savingsRate.toFixed(1)}%</td>
            <td>${data.financialHealth.savingsRate >= 20 ? '✅ Bom' : data.financialHealth.savingsRate >= 10 ? '⚠️ Regular' : '❌ Ruim'}</td>
          </tr>
          <tr>
            <td>Relação Dívida/Renda</td>
            <td>${data.financialHealth.debtToIncome.toFixed(1)}%</td>
            <td>${data.financialHealth.debtToIncome <= 30 ? '✅ Bom' : data.financialHealth.debtToIncome <= 50 ? '⚠️ Regular' : '❌ Ruim'}</td>
          </tr>
          <tr>
            <td>Tamanho Médio da Transação</td>
            <td>R$ ${data.financialHealth.avgTransactionSize.toFixed(2)}</td>
            <td>-</td>
          </tr>
          <tr>
            <td>Frequência de Transações</td>
            <td>${data.financialHealth.transactionFrequency.toFixed(2)}/dia</td>
            <td>-</td>
          </tr>
        </tbody>
      </table>
    </body>
    </html>
  `;
}