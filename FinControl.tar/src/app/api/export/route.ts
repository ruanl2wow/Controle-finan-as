import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import * as XLSX from 'xlsx'

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.email) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await request.json()
    const { format, filters, exportType = 'transactions' } = body

    const user = await db.user.findUnique({
      where: { email: session.user.email }
    })

    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 })
    }

    // Build where clause based on filters
    const where: any = { userId: user.id }

    if (filters?.startDate) {
      where.date = { ...where.date, gte: new Date(filters.startDate) }
    }

    if (filters?.endDate) {
      where.date = { ...where.date, lte: new Date(filters.endDate) }
    }

    if (filters?.category && filters.category !== 'all') {
      where.category = { name: filters.category }
    }

    if (filters?.account && filters.account !== 'all') {
      where.account = { name: filters.account }
    }

    if (filters?.type && filters.type !== 'all') {
      where.type = filters.type
    }

    let exportData: any[] = []
    let filename = ''
    let sheetName = ''

    switch (exportType) {
      case 'transactions':
        const transactions = await db.transaction.findMany({
          where,
          include: {
            category: true,
            account: true,
            upload: true
          },
          orderBy: { date: 'desc' },
        })

        exportData = transactions.map(t => ({
          'ID': t.id,
          'Data': new Date(t.date).toLocaleDateString('pt-BR'),
          'Descrição': t.description,
          'Categoria': t.category?.name || '',
          'Subcategoria': t.subcategory || '',
          'Conta': t.account.name,
          'Valor': t.amount,
          'Tipo': t.type === 'income' ? 'Receita' : 'Despesa',
          'Tags': t.tags ? JSON.parse(t.tags).join(', ') : '',
          'IA Categorizado': t.aiCategorized ? 'Sim' : 'Não',
          'Confiança IA': t.aiConfidence ? `${(t.aiConfidence * 100).toFixed(1)}%` : '',
          'Upload': t.upload?.originalName || '',
          'Data de Criação': new Date(t.createdAt).toLocaleDateString('pt-BR'),
        }))
        filename = `transacoes_${new Date().toISOString().split('T')[0]}`
        sheetName = 'Transações'
        break

      case 'categories':
        const categories = await db.category.findMany({
          where: { userId: user.id },
          include: {
            _count: {
              select: { transactions: true }
            }
          }
        })

        exportData = categories.map(c => ({
          'ID': c.id,
          'Nome': c.name,
          'Descrição': c.description || '',
          'Tipo': c.type === 'income' ? 'Receita' : 'Despesa',
          'Cor': c.color,
          'Ícone': c.icon || '',
          'Total de Transações': c._count.transactions,
          'Data de Criação': new Date(c.createdAt).toLocaleDateString('pt-BR'),
        }))
        filename = `categorias_${new Date().toISOString().split('T')[0]}`
        sheetName = 'Categorias'
        break

      case 'goals':
        const goals = await db.goal.findMany({
          where: { userId: user.id }
        })

        exportData = goals.map(g => ({
          'ID': g.id,
          'Nome': g.name,
          'Descrição': g.description || '',
          'Valor Alvo': g.targetAmount,
          'Valor Atual': g.currentAmount,
          'Progresso': `${((g.currentAmount / g.targetAmount) * 100).toFixed(1)}%`,
          'Data Alvo': new Date(g.targetDate).toLocaleDateString('pt-BR'),
          'Prioridade': g.priority,
          'Status': g.status,
          'Categoria': g.category || '',
          'Ativo': g.isActive ? 'Sim' : 'Não',
          'Data de Criação': new Date(g.createdAt).toLocaleDateString('pt-BR'),
        }))
        filename = `metas_${new Date().toISOString().split('T')[0]}`
        sheetName = 'Metas'
        break

      case 'budgets':
        const budgets = await db.budget.findMany({
          where: { userId: user.id },
          include: { category: true }
        })

        // Calculate spent amounts for budgets
        const budgetsWithSpending = await Promise.all(
          budgets.map(async (budget) => {
            const spent = await calculateSpentAmount(budget.id, budget.categoryId, user.id, budget.startDate, budget.endDate)
            return {
              ...budget,
              spent,
              remaining: budget.amount - spent,
              percentageUsed: budget.amount > 0 ? (spent / budget.amount) * 100 : 0
            }
          })
        )

        exportData = budgetsWithSpending.map(b => ({
          'ID': b.id,
          'Nome': b.name,
          'Descrição': b.description || '',
          'Valor Orçado': b.amount,
          'Valor Gasto': b.spent,
          'Valor Restante': b.remaining,
          'Percentual Usado': `${b.percentageUsed.toFixed(1)}%`,
          'Período': b.period,
          'Data Início': new Date(b.startDate).toLocaleDateString('pt-BR'),
          'Data Fim': new Date(b.endDate).toLocaleDateString('pt-BR'),
          'Categoria': b.category?.name || '',
          'Ativo': b.isActive ? 'Sim' : 'Não',
          'Data de Criação': new Date(b.createdAt).toLocaleDateString('pt-BR'),
        }))
        filename = `orcamentos_${new Date().toISOString().split('T')[0]}`
        sheetName = 'Orçamentos'
        break

      case 'full':
        // Export all data types
        const fullExportData = {
          transactions: await db.transaction.findMany({
            where: { userId: user.id },
            include: { category: true, account: true }
          }),
          categories: await db.category.findMany({
            where: { userId: user.id }
          }),
          goals: await db.goal.findMany({
            where: { userId: user.id }
          }),
          budgets: await db.budget.findMany({
            where: { userId: user.id },
            include: { category: true }
          }),
          accounts: await db.financialAccount.findMany({
            where: { userId: user.id }
          }),
          rules: await db.rule.findMany({
            where: { userId: user.id },
            include: { category: true }
          })
        }

        if (format === 'json') {
          return new NextResponse(JSON.stringify(fullExportData, null, 2), {
            headers: {
              'Content-Type': 'application/json',
              'Content-Disposition': `attachment; filename="backup_completo_${new Date().toISOString().split('T')[0]}.json"`,
            },
          })
        }

        // For Excel, create multiple sheets
        const wb = XLSX.utils.book_new()
        
        // Transactions sheet
        const transactionsData = fullExportData.transactions.map((t: any) => ({
          'Data': new Date(t.date).toLocaleDateString('pt-BR'),
          'Descrição': t.description,
          'Categoria': t.category?.name || '',
          'Conta': t.account.name,
          'Valor': t.amount,
          'Tipo': t.type === 'income' ? 'Receita' : 'Despesa',
        }))
        const wsTransactions = XLSX.utils.json_to_sheet(transactionsData)
        XLSX.utils.book_append_sheet(wb, wsTransactions, 'Transações')

        // Categories sheet
        const categoriesData = fullExportData.categories.map((c: any) => ({
          'Nome': c.name,
          'Tipo': c.type,
          'Cor': c.color,
        }))
        const wsCategories = XLSX.utils.json_to_sheet(categoriesData)
        XLSX.utils.book_append_sheet(wb, wsCategories, 'Categorias')

        // Goals sheet
        const goalsData = fullExportData.goals.map((g: any) => ({
          'Nome': g.name,
          'Valor Alvo': g.targetAmount,
          'Valor Atual': g.currentAmount,
          'Data Alvo': new Date(g.targetDate).toLocaleDateString('pt-BR'),
          'Status': g.status,
        }))
        const wsGoals = XLSX.utils.json_to_sheet(goalsData)
        XLSX.utils.book_append_sheet(wb, wsGoals, 'Metas')

        const excelBuffer = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' })
        
        return new NextResponse(excelBuffer, {
          headers: {
            'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            'Content-Disposition': `attachment; filename="backup_completo_${new Date().toISOString().split('T')[0]}.xlsx"`,
          },
        })

      default:
        return NextResponse.json({ error: 'Invalid export type' }, { status: 400 })
    }

    if (format === 'csv') {
      const ws = XLSX.utils.json_to_sheet(exportData)
      const csv = XLSX.utils.sheet_to_csv(ws)
      
      return new NextResponse(csv, {
        headers: {
          'Content-Type': 'text/csv',
          'Content-Disposition': `attachment; filename="${filename}.csv"`,
        },
      })
    } else if (format === 'excel') {
      const ws = XLSX.utils.json_to_sheet(exportData)
      const wb = XLSX.utils.book_new()
      XLSX.utils.book_append_sheet(wb, ws, sheetName)
      
      // Add summary sheet for transactions
      if (exportType === 'transactions') {
        const summaryData = [
          ['Resumo de Transações'],
          [''],
          ['Período', filters?.startDate && filters?.endDate ? `${filters.startDate} a ${filters.endDate}` : 'Todo o período'],
          ['Total de Transações', exportData.length],
          ['Total Receitas', exportData.filter(t => t.Tipo === 'Receita').reduce((sum, t) => sum + t.Valor, 0)],
          ['Total Despesas', Math.abs(exportData.filter(t => t.Tipo === 'Despesa').reduce((sum, t) => sum + t.Valor, 0))],
          ['Saldo', exportData.reduce((sum, t) => sum + t.Valor, 0)],
        ]
        
        const wsSummary = XLSX.utils.aoa_to_sheet(summaryData)
        XLSX.utils.book_append_sheet(wb, wsSummary, 'Resumo')
      }
      
      const excelBuffer = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' })
      
      return new NextResponse(excelBuffer, {
        headers: {
          'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
          'Content-Disposition': `attachment; filename="${filename}.xlsx"`,
        },
      })
    }

    return NextResponse.json({ error: 'Unsupported format' }, { status: 400 })
  } catch (error) {
    console.error('Export error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

async function calculateSpentAmount(
  budgetId: string, 
  categoryId: string | null, 
  userId: string, 
  startDate: Date, 
  endDate: Date
): Promise<number> {
  const whereClause: any = {
    userId,
    date: {
      gte: startDate,
      lte: endDate
    },
    type: 'expense'
  }

  if (categoryId) {
    whereClause.categoryId = categoryId
  }

  const result = await db.transaction.aggregate({
    where: whereClause,
    _sum: {
      amount: true
    }
  })

  return Math.abs(result._sum.amount || 0)
}