import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.email) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const user = await db.user.findUnique({
      where: { email: session.user.email }
    })

    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 })
    }

    const { searchParams } = new URL(request.url)
    const status = searchParams.get('status')
    const category = searchParams.get('category')
    const active = searchParams.get('active') !== 'false'

    const whereClause: any = {
      userId: user.id,
      isActive: active
    }

    if (status) {
      whereClause.status = status
    }

    if (category) {
      whereClause.category = category
    }

    const goals = await db.goal.findMany({
      where: whereClause,
      orderBy: [
        { priority: 'desc' },
        { targetDate: 'asc' }
      ]
    })

    // Calculate progress and additional metrics for each goal
    const goalsWithProgress = goals.map(goal => {
      const progress = goal.targetAmount > 0 ? (goal.currentAmount / goal.targetAmount) * 100 : 0
      const daysRemaining = Math.ceil((goal.targetDate.getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24))
      const isCompleted = goal.currentAmount >= goal.targetAmount
      const isOverdue = !isCompleted && daysRemaining < 0

      // Calculate required monthly contribution to reach goal
      const monthsRemaining = Math.max(0, daysRemaining / 30)
      const requiredMonthly = monthsRemaining > 0 ? 
        (goal.targetAmount - goal.currentAmount) / monthsRemaining : 0

      return {
        ...goal,
        progress: Math.min(100, progress),
        daysRemaining,
        isCompleted,
        isOverdue,
        requiredMonthly,
        remainingAmount: Math.max(0, goal.targetAmount - goal.currentAmount)
      }
    })

    return NextResponse.json({ goals: goalsWithProgress })
  } catch (error) {
    console.error('Error fetching goals:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.email) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await request.json()
    const user = await db.user.findUnique({
      where: { email: session.user.email }
    })

    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 })
    }

    const goal = await db.goal.create({
      data: {
        ...body,
        userId: user.id,
        targetDate: new Date(body.targetDate)
      }
    })

    return NextResponse.json({ goal })
  } catch (error) {
    console.error('Error creating goal:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

export async function PUT(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.email) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await request.json()
    const { id, ...updateData } = body

    const user = await db.user.findUnique({
      where: { email: session.user.email }
    })

    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 })
    }

    const goal = await db.goal.update({
      where: { 
        id,
        userId: user.id 
      },
      data: {
        ...updateData,
        targetDate: updateData.targetDate ? new Date(updateData.targetDate) : undefined
      }
    })

    return NextResponse.json({ goal })
  } catch (error) {
    console.error('Error updating goal:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.email) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const id = searchParams.get('id')

    if (!id) {
      return NextResponse.json({ error: 'Goal ID is required' }, { status: 400 })
    }

    const user = await db.user.findUnique({
      where: { email: session.user.email }
    })

    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 })
    }

    await db.goal.delete({
      where: { 
        id,
        userId: user.id 
      }
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Error deleting goal:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

// Update goal progress
export async function PATCH(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.email) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await request.json()
    const { id, amount, operation = 'add' } = body

    const user = await db.user.findUnique({
      where: { email: session.user.email }
    })

    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 })
    }

    const goal = await db.goal.findUnique({
      where: { id, userId: user.id }
    })

    if (!goal) {
      return NextResponse.json({ error: 'Goal not found' }, { status: 404 })
    }

    let newAmount = goal.currentAmount
    if (operation === 'add') {
      newAmount += amount
    } else if (operation === 'subtract') {
      newAmount = Math.max(0, newAmount - amount)
    } else if (operation === 'set') {
      newAmount = amount
    }

    const updatedGoal = await db.goal.update({
      where: { id },
      data: { 
        currentAmount: newAmount,
        status: newAmount >= goal.targetAmount ? 'completed' : 
                newAmount <= 0 ? 'cancelled' : goal.status
      }
    })

    return NextResponse.json({ goal: updatedGoal })
  } catch (error) {
    console.error('Error updating goal progress:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}