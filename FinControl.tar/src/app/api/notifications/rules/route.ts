import { NextRequest, NextResponse } from 'next/server'
import { NotificationService } from '@/lib/notifications'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const rules = await NotificationService.getUserNotificationRules(session.user.id)

    return NextResponse.json({ rules })
  } catch (error) {
    console.error('Error fetching notification rules:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await request.json()
    const { name, type, enabled, channels, conditions } = body

    if (!name || !type || !channels || !conditions) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      )
    }

    const rule = await NotificationService.createNotificationRule({
      name,
      type,
      enabled: enabled ?? true,
      channels,
      conditions,
      userId: session.user.id,
    })

    return NextResponse.json(rule)
  } catch (error) {
    console.error('Error creating notification rule:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}