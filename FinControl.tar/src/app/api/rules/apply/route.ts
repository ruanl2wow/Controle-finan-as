import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { RuleProcessor } from '@/lib/rule-processor'

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.email) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { transactionIds, applyToAll = false } = await request.json()

    const user = await db.user.findUnique({
      where: { email: session.user.email }
    })

    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 })
    }

    let transactions

    if (applyToAll) {
      // Get all uncategorized transactions for the user
      transactions = await db.transaction.findMany({
        where: {
          userId: user.id,
          categoryId: null
        }
      })
    } else if (transactionIds && Array.isArray(transactionIds)) {
      // Get specific transactions
      transactions = await db.transaction.findMany({
        where: {
          id: { in: transactionIds },
          userId: user.id
        }
      })
    } else {
      return NextResponse.json({ error: 'No transactions specified' }, { status: 400 })
    }

    if (transactions.length === 0) {
      return NextResponse.json({ 
        success: true, 
        message: 'No transactions to process',
        processedTransactions: []
      })
    }

    // Process transactions with rules
    const processedTransactions = await RuleProcessor.processTransactions(transactions)

    return NextResponse.json({
      success: true,
      message: `Processed ${processedTransactions.length} transactions`,
      processedTransactions
    })

  } catch (error) {
    console.error('Error applying rules:', error)
    return NextResponse.json(
      { error: 'Failed to apply rules', details: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 }
    )
  }
}