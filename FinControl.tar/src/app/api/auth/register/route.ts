import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import bcrypt from 'bcryptjs'
import { z } from 'zod'

const registerSchema = z.object({
  name: z.string().min(2, 'Nome deve ter pelo menos 2 caracteres'),
  email: z.string().email('Email inválido'),
  password: z.string().min(6, 'Senha deve ter pelo menos 6 caracteres'),
})

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { name, email, password } = registerSchema.parse(body)

    // Check if user already exists
    const existingUser = await db.user.findUnique({
      where: { email }
    })

    if (existingUser) {
      return NextResponse.json(
        { error: 'Usuário já existe com este email' },
        { status: 400 }
      )
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 12)

    // Create user
    const user = await db.user.create({
      data: {
        name,
        email,
        password: hashedPassword,
        role: 'user'
      }
    })

    // Create default categories for the user
    const defaultCategories = [
      { name: 'Alimentação', color: '#EF4444', type: 'expense', icon: '🍔' },
      { name: 'Transporte', color: '#3B82F6', type: 'expense', icon: '🚗' },
      { name: 'Moradia', color: '#8B5CF6', type: 'expense', icon: '🏠' },
      { name: 'Saúde', color: '#10B981', type: 'expense', icon: '🏥' },
      { name: 'Educação', color: '#F59E0B', type: 'expense', icon: '📚' },
      { name: 'Lazer', color: '#EC4899', type: 'expense', icon: '🎮' },
      { name: 'Salário', color: '#22C55E', type: 'income', icon: '💰' },
      { name: 'Investimentos', color: '#06B6D4', type: 'income', icon: '📈' },
      { name: 'Outros', color: '#6B7280', type: 'expense', icon: '📦' },
    ]

    await Promise.all(
      defaultCategories.map(category =>
        db.category.create({
          data: {
            ...category,
            userId: user.id
          }
        })
      )
    )

    // Create default financial account
    await db.financialAccount.create({
      data: {
        name: 'Conta Principal',
        type: 'checking',
        balance: 0,
        currency: 'BRL',
        userId: user.id
      }
    })

    return NextResponse.json({
      message: 'Usuário criado com sucesso',
      user: {
        id: user.id,
        name: user.name,
        email: user.email
      }
    })

  } catch (error) {
    console.error('Registration error:', error)
    
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: error.errors[0].message },
        { status: 400 }
      )
    }

    return NextResponse.json(
      { error: 'Erro ao criar usuário' },
      { status: 500 }
    )
  }
}