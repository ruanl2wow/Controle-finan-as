import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { auth } from '@/lib/auth'

export async function GET() {
  try {
    const session = await auth()
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    // Buscar estatísticas de armazenamento do usuário
    const [
      totalTransactions,
      totalAccounts,
      totalCategories,
      totalUploads,
      totalRules,
      recentUploads
    ] = await Promise.all([
      db.transaction.count({
        where: { userId: session.user.id }
      }),
      db.financialAccount.count({
        where: { userId: session.user.id }
      }),
      db.category.count({
        where: { userId: session.user.id }
      }),
      db.upload.count({
        where: { userId: session.user.id }
      }),
      db.rule.count({
        where: { userId: session.user.id }
      }),
      db.upload.findMany({
        where: { userId: session.user.id },
        take: 5,
        orderBy: { createdAt: 'desc' },
        select: {
          id: true,
          filename: true,
          originalName: true,
          fileType: true,
          fileSize: true,
          status: true,
          createdAt: true,
          processedAt: true,
          account: {
            select: {
              name: true
            }
          }
        }
      })
    ])

    // Calcular tamanho total dos arquivos
    const totalFileSize = await db.upload.aggregate({
      where: { userId: session.user.id },
      _sum: { fileSize: true }
    })

    return NextResponse.json({
      storage: {
        database: {
          type: 'SQLite',
          location: 'Local database file',
          description: 'Todos os dados são armazenados em um banco de dados SQLite local no servidor',
          tables: {
            transactions: totalTransactions,
            accounts: totalAccounts,
            categories: totalCategories,
            uploads: totalUploads,
            rules: totalRules
          }
        },
        files: {
          location: './uploads/',
          description: 'Arquivos de extratos bancários são armazenados no sistema de arquivos do servidor',
          totalFiles: totalUploads,
          totalSize: totalFileSize._sum.fileSize || 0,
          recentUploads
        },
        security: {
          encryption: 'Dados sensíveis criptografados no banco de dados',
          isolation: 'Cada usuário tem acesso apenas aos seus próprios dados',
          backup: 'Backup automático diário dos dados'
        }
      }
    })

  } catch (error) {
    console.error('Error fetching storage info:', error)
    return NextResponse.json(
      { error: 'Failed to fetch storage information' },
      { status: 500 }
    )
  }
}