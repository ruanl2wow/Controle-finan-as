import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { cache, CACHE_KEYS, CACHE_TTL } from '@/lib/cache'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')
    
    if (!userId) {
      return NextResponse.json({ error: 'User ID is required' }, { status: 400 })
    }

    // Check cache first
    const cacheKey = CACHE_KEYS.CATEGORIES(userId)
    const cached = cache.get(cacheKey)
    
    if (cached) {
      return NextResponse.json(cached)
    }

    const categories = await db.category.findMany({
      where: { userId },
      orderBy: [
        { type: 'asc' },
        { name: 'asc' }
      ],
      include: {
        _count: {
          select: {
            transactions: true
          }
        }
      }
    })

    // Cache the result
    cache.set(cacheKey, categories, CACHE_TTL.MEDIUM)

    return NextResponse.json(categories)
  } catch (error) {
    console.error('Error fetching categories:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { name, description, color, icon, type, userId } = body

    if (!name || !type || !userId) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 })
    }

    const category = await db.category.create({
      data: {
        name,
        description,
        color: color || '#6B7280',
        icon,
        type,
        userId
      }
    })

    // Clear cache for this user
    cache.delete(CACHE_KEYS.CATEGORIES(userId))

    return NextResponse.json(category, { status: 201 })
  } catch (error) {
    console.error('Error creating category:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function PUT(request: NextRequest) {
  try {
    const body = await request.json()
    const { id, name, description, color, icon, type, userId } = body

    if (!id || !userId) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 })
    }

    const category = await db.category.update({
      where: { id },
      data: {
        ...(name && { name }),
        ...(description !== undefined && { description }),
        ...(color && { color }),
        ...(icon !== undefined && { icon }),
        ...(type && { type })
      }
    })

    // Clear cache for this user
    cache.delete(CACHE_KEYS.CATEGORIES(userId))

    return NextResponse.json(category)
  } catch (error) {
    console.error('Error updating category:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get('id')
    const userId = searchParams.get('userId')

    if (!id || !userId) {
      return NextResponse.json({ error: 'Missing required parameters' }, { status: 400 })
    }

    await db.category.delete({
      where: { id }
    })

    // Clear cache for this user
    cache.delete(CACHE_KEYS.CATEGORIES(userId))

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Error deleting category:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}