import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.email) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const period = searchParams.get('period') || 'month';
    const startDate = searchParams.get('startDate');
    const endDate = searchParams.get('endDate');

    // Build date filter
    let dateFilter: any = {};
    if (startDate && endDate) {
      dateFilter = {
        date: {
          gte: new Date(startDate),
          lte: new Date(endDate),
        },
      };
    } else {
      const now = new Date();
      let startDate: Date;
      
      switch (period) {
        case 'week':
          startDate = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
          break;
        case 'month':
          startDate = new Date(now.getFullYear(), now.getMonth(), 1);
          break;
        case 'quarter':
          startDate = new Date(now.getFullYear(), Math.floor(now.getMonth() / 3) * 3, 1);
          break;
        case 'year':
          startDate = new Date(now.getFullYear(), 0, 1);
          break;
        default:
          startDate = new Date(now.getFullYear(), now.getMonth(), 1);
      }
      
      dateFilter = {
        date: {
          gte: startDate,
          lte: now,
        },
      };
    }

    // Get user's transactions
    const user = await db.user.findUnique({
      where: { email: session.user.email },
    });

    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }

    // Fetch transactions with filters
    const transactions = await db.transaction.findMany({
      where: {
        userId: user.id,
        ...dateFilter,
      },
      include: {
        category: true,
      },
      orderBy: {
        date: 'desc',
      },
    });

    // Calculate basic metrics
    const totalIncome = transactions
      .filter(t => t.type === 'INCOME')
      .reduce((sum, t) => sum + Number(t.amount), 0);

    const totalExpenses = transactions
      .filter(t => t.type === 'EXPENSE')
      .reduce((sum, t) => sum + Number(t.amount), 0);

    const netIncome = totalIncome - totalExpenses;
    const savingsRate = totalIncome > 0 ? (netIncome / totalIncome) * 100 : 0;

    // Category breakdown
    const categoryBreakdown = transactions.reduce((acc, transaction) => {
      const categoryName = transaction.category.name;
      if (!acc[categoryName]) {
        acc[categoryName] = {
          name: categoryName,
          income: 0,
          expenses: 0,
          count: 0,
        };
      }
      
      if (transaction.type === 'INCOME') {
        acc[categoryName].income += Number(transaction.amount);
      } else {
        acc[categoryName].expenses += Number(transaction.amount);
      }
      acc[categoryName].count += 1;
      
      return acc;
    }, {} as Record<string, any>);

    // Monthly trends
    const monthlyTrends = transactions.reduce((acc, transaction) => {
      const date = new Date(transaction.date);
      const monthKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
      
      if (!acc[monthKey]) {
        acc[monthKey] = {
          month: monthKey,
          income: 0,
          expenses: 0,
          count: 0,
        };
      }
      
      if (transaction.type === 'INCOME') {
        acc[monthKey].income += Number(transaction.amount);
      } else {
        acc[monthKey].expenses += Number(transaction.amount);
      }
      acc[monthKey].count += 1;
      
      return acc;
    }, {} as Record<string, any>);

    // Calculate average transaction values
    const avgIncome = transactions
      .filter(t => t.type === 'INCOME')
      .reduce((sum, t, _, arr) => sum + Number(t.amount) / arr.length, 0);

    const avgExpense = transactions
      .filter(t => t.type === 'EXPENSE')
      .reduce((sum, t, _, arr) => sum + Number(t.amount) / arr.length, 0);

    // Top spending categories
    const topCategories = Object.values(categoryBreakdown)
      .sort((a: any, b: any) => b.expenses - a.expenses)
      .slice(0, 5);

    // Daily transaction patterns
    const dailyPatterns = transactions.reduce((acc, transaction) => {
      const date = new Date(transaction.date);
      const dayOfWeek = date.getDay();
      const dayName = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'][dayOfWeek];
      
      if (!acc[dayName]) {
        acc[dayName] = {
          day: dayName,
          income: 0,
          expenses: 0,
          count: 0,
        };
      }
      
      if (transaction.type === 'INCOME') {
        acc[dayName].income += Number(transaction.amount);
      } else {
        acc[dayName].expenses += Number(transaction.amount);
      }
      acc[dayName].count += 1;
      
      return acc;
    }, {} as Record<string, any>);

    // Financial health indicators
    const financialHealth = {
      savingsRate: Math.round(savingsRate * 100) / 100,
      debtToIncome: totalIncome > 0 ? Math.round((totalExpenses / totalIncome) * 100 * 100) / 100 : 0,
      avgTransactionSize: Math.round(((avgIncome + avgExpense) / 2) * 100) / 100,
      transactionFrequency: Math.round((transactions.length / Math.max(1, getDaysBetweenDates(dateFilter.date?.gte || new Date(), dateFilter.date?.lte || new Date()))) * 100) / 100,
    };

    const analytics = {
      summary: {
        totalIncome: Math.round(totalIncome * 100) / 100,
        totalExpenses: Math.round(totalExpenses * 100) / 100,
        netIncome: Math.round(netIncome * 100) / 100,
        transactionCount: transactions.length,
        avgIncome: Math.round(avgIncome * 100) / 100,
        avgExpense: Math.round(avgExpense * 100) / 100,
      },
      categoryBreakdown: Object.values(categoryBreakdown),
      monthlyTrends: Object.values(monthlyTrends).sort((a, b) => a.month.localeCompare(b.month)),
      topCategories,
      dailyPatterns: Object.values(dailyPatterns),
      financialHealth,
      period,
      dateRange: {
        start: dateFilter.date?.gte || new Date(),
        end: dateFilter.date?.lte || new Date(),
      },
    };

    return NextResponse.json(analytics);
  } catch (error) {
    console.error('Analytics API error:', error);
    return NextResponse.json(
      { error: 'Failed to fetch analytics data' },
      { status: 500 }
    );
  }
}

function getDaysBetweenDates(start: Date, end: Date): number {
  const diffTime = Math.abs(end.getTime() - start.getTime());
  return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
}