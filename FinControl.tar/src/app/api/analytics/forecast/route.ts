import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.email) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const months = parseInt(searchParams.get('months') || '6');

    // Get user's transactions
    const user = await db.user.findUnique({
      where: { email: session.user.email },
    });

    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }

    // Fetch historical data (last 12 months for better forecasting)
    const twelveMonthsAgo = new Date();
    twelveMonthsAgo.setMonth(twelveMonthsAgo.getMonth() - 12);

    const transactions = await db.transaction.findMany({
      where: {
        userId: user.id,
        date: {
          gte: twelveMonthsAgo,
        },
      },
      include: {
        category: true,
      },
      orderBy: {
        date: 'asc',
      },
    });

    // Group transactions by month
    const monthlyData = transactions.reduce((acc, transaction) => {
      const date = new Date(transaction.date);
      const monthKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
      
      if (!acc[monthKey]) {
        acc[monthKey] = {
          month: monthKey,
          income: 0,
          expenses: 0,
          count: 0,
          categories: {},
        };
      }
      
      if (transaction.type === 'INCOME') {
        acc[monthKey].income += Number(transaction.amount);
      } else {
        acc[monthKey].expenses += Number(transaction.amount);
        
        // Track category expenses
        const categoryName = transaction.category.name;
        if (!acc[monthKey].categories[categoryName]) {
          acc[monthKey].categories[categoryName] = 0;
        }
        acc[monthKey].categories[categoryName] += Number(transaction.amount);
      }
      
      acc[monthKey].count += 1;
      
      return acc;
    }, {} as Record<string, any>);

    const monthlyArray = Object.values(monthlyData);

    // Calculate trends using linear regression
    const calculateTrend = (data: number[]) => {
      const n = data.length;
      if (n < 2) return { slope: 0, intercept: data[0] || 0 };
      
      const sumX = data.reduce((sum, _, i) => sum + i, 0);
      const sumY = data.reduce((sum, val) => sum + val, 0);
      const sumXY = data.reduce((sum, val, i) => sum + val * i, 0);
      const sumXX = data.reduce((sum, _, i) => sum + i * i, 0);
      
      const slope = (n * sumXY - sumX * sumY) / (n * sumXX - sumX * sumX);
      const intercept = (sumY - slope * sumX) / n;
      
      return { slope, intercept };
    };

    const incomeData = monthlyArray.map(m => m.income);
    const expenseData = monthlyArray.map(m => m.expenses);

    const incomeTrend = calculateTrend(incomeData);
    const expenseTrend = calculateTrend(expenseData);

    // Generate forecasts
    const forecasts = [];
    const lastMonthIndex = monthlyArray.length - 1;
    
    for (let i = 1; i <= months; i++) {
      const futureIndex = lastMonthIndex + i;
      const forecastIncome = Math.max(0, incomeTrend.intercept + incomeTrend.slope * futureIndex);
      const forecastExpenses = Math.max(0, expenseTrend.intercept + expenseTrend.slope * futureIndex);
      
      // Calculate seasonal adjustments (simplified)
      const seasonalFactor = getSeasonalFactor(futureIndex);
      const adjustedIncome = forecastIncome * seasonalFactor.income;
      const adjustedExpenses = forecastExpenses * seasonalFactor.expenses;
      
      forecasts.push({
        month: getFutureMonth(i),
        income: Math.round(adjustedIncome * 100) / 100,
        expenses: Math.round(adjustedExpenses * 100) / 100,
        netIncome: Math.round((adjustedIncome - adjustedExpenses) * 100) / 100,
        confidence: Math.max(0.5, 1 - (i * 0.1)), // Decreasing confidence over time
      });
    }

    // Category-wise forecasting
    const categoryForecasts = {};
    const recentMonths = monthlyArray.slice(-6); // Use last 6 months for category trends
    
    Object.keys(recentMonths[0]?.categories || {}).forEach(category => {
      const categoryData = recentMonths.map(m => m.categories[category] || 0);
      const categoryTrend = calculateTrend(categoryData);
      
      const futureCategoryExpenses = [];
      for (let i = 1; i <= months; i++) {
        const futureIndex = recentMonths.length + i;
        const forecast = Math.max(0, categoryTrend.intercept + categoryTrend.slope * futureIndex);
        futureCategoryExpenses.push({
          month: getFutureMonth(i),
          amount: Math.round(forecast * 100) / 100,
        });
      }
      
      categoryForecasts[category] = futureCategoryExpenses;
    });

    // Calculate risk indicators
    const riskAnalysis = {
      incomeVolatility: calculateVolatility(incomeData),
      expenseVolatility: calculateVolatility(expenseData),
      trendDirection: {
        income: incomeTrend.slope > 0 ? 'increasing' : incomeTrend.slope < 0 ? 'decreasing' : 'stable',
        expenses: expenseTrend.slope > 0 ? 'increasing' : expenseTrend.slope < 0 ? 'decreasing' : 'stable',
      },
      riskLevel: calculateRiskLevel(incomeTrend.slope, expenseTrend.slope, incomeData, expenseData),
    };

    // Recommendations based on forecast
    const recommendations = generateRecommendations(forecasts, riskAnalysis, monthlyArray);

    const forecastData = {
      historical: monthlyArray,
      forecasts,
      categoryForecasts,
      riskAnalysis,
      recommendations,
      metadata: {
        generatedAt: new Date().toISOString(),
        forecastPeriod: months,
        dataPoints: monthlyArray.length,
        confidence: forecasts.reduce((sum, f) => sum + f.confidence, 0) / forecasts.length,
      },
    };

    return NextResponse.json(forecastData);
  } catch (error) {
    console.error('Forecast API error:', error);
    return NextResponse.json(
      { error: 'Failed to generate forecast' },
      { status: 500 }
    );
  }
}

function getSeasonalFactor(monthIndex: number): { income: number; expenses: number } {
  const monthOfYear = monthIndex % 12;
  
  // Simplified seasonal patterns (Brazilian context)
  const seasonalPatterns = {
    // Dec: Christmas bonus, higher expenses
    11: { income: 1.3, expenses: 1.4 },
    // Jan: Vacation, lower income, higher expenses
    0: { income: 0.8, expenses: 1.2 },
    // Feb: Carnival, higher expenses
    1: { income: 0.9, expenses: 1.3 },
    // Mar-Apr: Normal period
    2: { income: 1.0, expenses: 1.0 },
    3: { income: 1.0, expenses: 1.0 },
    // May: Mother's Day
    4: { income: 1.0, expenses: 1.1 },
    // Jun: Festas Juninas
    5: { income: 1.0, expenses: 1.1 },
    // Jul: Vacation
    6: { income: 0.9, expenses: 1.2 },
    // Aug-Sep: Back to school
    7: { income: 1.0, expenses: 1.1 },
    8: { income: 1.0, expenses: 1.1 },
    // Oct: Normal
    9: { income: 1.0, expenses: 1.0 },
    // Nov: Black Friday
    10: { income: 1.0, expenses: 1.2 },
  };
  
  return seasonalPatterns[monthOfYear] || { income: 1.0, expenses: 1.0 };
}

function getFutureMonth(monthsAhead: number): string {
  const date = new Date();
  date.setMonth(date.getMonth() + monthsAhead);
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
}

function calculateVolatility(data: number[]): number {
  if (data.length < 2) return 0;
  
  const mean = data.reduce((sum, val) => sum + val, 0) / data.length;
  const variance = data.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / data.length;
  const standardDeviation = Math.sqrt(variance);
  
  return mean > 0 ? (standardDeviation / mean) * 100 : 0; // Coefficient of variation
}

function calculateRiskLevel(incomeSlope: number, expenseSlope: number, incomeData: number[], expenseData: number[]): string {
  const incomeVolatility = calculateVolatility(incomeData);
  const expenseVolatility = calculateVolatility(expenseData);
  
  // Risk scoring
  let riskScore = 0;
  
  // Trend risks
  if (incomeSlope < 0) riskScore += 30;
  if (expenseSlope > 0) riskScore += 30;
  
  // Volatility risks
  if (incomeVolatility > 20) riskScore += 20;
  if (expenseVolatility > 20) riskScore += 20;
  
  if (riskScore >= 60) return 'high';
  if (riskScore >= 30) return 'medium';
  return 'low';
}

function generateRecommendations(forecasts: any[], riskAnalysis: any, historicalData: any[]): string[] {
  const recommendations = [];
  
  // Analyze forecast trends
  const avgForecastIncome = forecasts.reduce((sum, f) => sum + f.income, 0) / forecasts.length;
  const avgForecastExpenses = forecasts.reduce((sum, f) => sum + f.expenses, 0) / forecasts.length;
  const avgForecastSavings = avgForecastIncome - avgForecastExpenses;
  
  // Income recommendations
  if (riskAnalysis.trendDirection.income === 'decreasing') {
    recommendations.push('⚠️ Suas receitas estão tendendo a queda. Considere diversificar fontes de renda ou buscar aumentos salariais.');
  }
  
  // Expense recommendations
  if (riskAnalysis.trendDirection.expenses === 'increasing') {
    recommendations.push('📈 Suas despesas estão crescendo. Revise seu orçamento e identifique áreas para cortar custos.');
  }
  
  // Savings recommendations
  if (avgForecastSavings < 0) {
    recommendations.push('🚨 Previsão de déficit nos próximos meses. É urgente reduzir despesas ou aumentar receitas.');
  } else if (avgForecastSavings < avgForecastIncome * 0.1) {
    recommendations.push('💡 Sua taxa de economia prevista está abaixo de 10%. Tente aumentar para pelo menos 20% para maior segurança financeira.');
  }
  
  // Volatility recommendations
  if (riskAnalysis.incomeVolatility > 20) {
    recommendations.push('🔄 Sua renda é muito volátil. Crie uma reserva de emergência com pelo menos 6 meses de despesas.');
  }
  
  if (riskAnalysis.expenseVolatility > 20) {
    recommendations.push('📊 Suas despesas são muito variáveis. Tente criar um orçamento mais estável com categorias fixas.');
  }
  
  // Risk-based recommendations
  if (riskAnalysis.riskLevel === 'high') {
    recommendations.push('⚡ Alto risco financeiro detectado. Considere consultar um planejador financeiro profissional.');
  }
  
  // Positive recommendations
  if (riskAnalysis.riskLevel === 'low' && avgForecastSavings > avgForecastIncome * 0.2) {
    recommendations.push('✅ Ótima saúde financeira! Considere investir o excedente para fazer seu dinheiro trabalhar para você.');
  }
  
  return recommendations;
}