import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { writeFile, mkdir } from 'fs/promises'
import { join } from 'path'
import { v4 as uuidv4 } from 'uuid'
import { auth } from '@/lib/auth'
import Papa from 'papaparse'
import * as OFX from 'ofx-js'
import { readFile } from 'fs/promises'

export async function POST(request: NextRequest) {
  try {
    const session = await auth()
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const formData = await request.formData()
    const file = formData.get('file') as File
    const accountId = formData.get('accountId') as string
    const userId = session.user.id

    if (!file) {
      return NextResponse.json({ error: 'No file provided' }, { status: 400 })
    }

    if (!accountId) {
      return NextResponse.json({ error: 'No account provided' }, { status: 400 })
    }

    // Verify account belongs to user
    const account = await db.financialAccount.findFirst({
      where: { 
        id: accountId,
        userId: userId 
      }
    })

    if (!account) {
      return NextResponse.json({ error: 'Account not found' }, { status: 404 })
    }

    // Create uploads directory if it doesn't exist
    const uploadsDir = join(process.cwd(), 'uploads')
    await mkdir(uploadsDir, { recursive: true })

    // Generate unique filename
    const fileId = uuidv4()
    const fileExtension = file.name.split('.').pop()
    const filename = `${fileId}.${fileExtension}`
    const filepath = join(uploadsDir, filename)

    // Save file to disk
    const bytes = await file.arrayBuffer()
    const buffer = Buffer.from(bytes)
    await writeFile(filepath, buffer)

    // Create upload record in database
    const upload = await db.upload.create({
      data: {
        id: fileId,
        filename,
        originalName: file.name,
        fileType: fileExtension!,
        fileSize: file.size,
        status: 'pending',
        userId,
        accountId,
      },
    })

    // Start processing in background
    processFile(fileId, filepath, userId, accountId).catch(console.error)

    return NextResponse.json({ upload })
  } catch (error) {
    console.error('Upload error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

async function processFile(fileId: string, filepath: string, userId: string, accountId: string) {
  try {
    // Update status to processing
    await db.upload.update({
      where: { id: fileId },
      data: { status: 'processing' },
    })

    const fileExtension = filepath.split('.').pop()?.toLowerCase()
    
    let transactions: any[] = []

    switch (fileExtension) {
      case 'csv':
        transactions = await parseCSV(filepath)
        break
      case 'ofx':
        transactions = await parseOFX(filepath)
        break
      case 'qif':
        transactions = await parseQIF(filepath)
        break
      default:
        throw new Error(`Unsupported file type: ${fileExtension}`)
    }

    // Auto-categorize transactions
    transactions = await autoCategorize(transactions, userId)

    // Save transactions to database
    await db.transaction.createMany({
      data: transactions.map(t => ({
        date: new Date(t.date),
        description: t.description,
        amount: t.amount,
        type: t.amount >= 0 ? 'income' : 'expense',
        categoryId: t.categoryId,
        accountId,
        userId,
        uploadId: fileId,
        tags: JSON.stringify(t.tags || []),
      })),
    })

    // Update upload status to completed
    await db.upload.update({
      where: { id: fileId },
      data: {
        status: 'completed',
        processedAt: new Date(),
      },
    })

  } catch (error) {
    console.error('Processing error:', error)
    
    // Update upload status to error
    await db.upload.update({
      where: { id: fileId },
      data: {
        status: 'error',
        error: error instanceof Error ? error.message : 'Unknown error',
      },
    })
  }
}

async function parseCSV(filepath: string): Promise<any[]> {
  const fileContent = await readFile(filepath, 'utf8')

  return new Promise((resolve, reject) => {
    Papa.parse(fileContent, {
      header: true,
      skipEmptyLines: true,
      complete: (results: any) => {
        try {
          const transactions = results.data.map((row: any) => {
            // Try to auto-detect columns
            const date = row.date || row.Data || row.DATA || row['Data da transação']
            const description = row.description || row.descrição || row.Descrição || row['Descrição']
            const amount = row.amount || row.valor || row.Valor || row['Valor (R$)']

            if (!date || !description || amount === undefined) {
              throw new Error('Invalid CSV format')
            }

            return {
              date: parseDate(date),
              description: description.trim(),
              amount: parseFloat(String(amount).replace(/[R$\s.]/g, '').replace(',', '.')),
              tags: [],
            }
          }).filter(t => !isNaN(t.amount))

          resolve(transactions)
        } catch (error) {
          reject(error)
        }
      },
      error: reject,
    })
  })
}

async function parseOFX(filepath: string): Promise<any[]> {
  const fileContent = await readFile(filepath, 'utf8')

  try {
    const ofxData = await OFX.parse(fileContent)
    
    if (ofxData?.bankTransactionList?.transactions) {
      return ofxData.bankTransactionList.transactions.map((t: any) => ({
        date: new Date(t.date),
        description: t.name || t.memo || '',
        amount: t.amount,
        tags: [],
      }))
    }
    
    throw new Error('Invalid OFX format')
  } catch (error) {
    throw new Error(`Error parsing OFX: ${error}`)
  }
}

async function parseQIF(filepath: string): Promise<any[]> {
  const fileContent = await readFile(filepath, 'utf8')
  
  try {
    const lines = fileContent.split('\n')
    const transactions: any[] = []
    let currentTransaction: any = {}

    for (const line of lines) {
      const trimmedLine = line.trim()
      
      if (trimmedLine === '^') {
        // End of transaction
        if (currentTransaction.date && currentTransaction.amount) {
          transactions.push(currentTransaction)
        }
        currentTransaction = {}
      } else if (trimmedLine.startsWith('D')) {
        currentTransaction.date = parseDate(trimmedLine.substring(1))
      } else if (trimmedLine.startsWith('T')) {
        currentTransaction.amount = parseFloat(trimmedLine.substring(1))
      } else if (trimmedLine.startsWith('P')) {
        currentTransaction.description = trimmedLine.substring(1)
      }
    }

    return transactions.map(t => ({ ...t, tags: [] }))
  } catch (error) {
    throw new Error(`Error parsing QIF: ${error}`)
  }
}

function parseDate(dateString: string): Date {
  // Try different date formats
  const formats = [
    /(\d{2})\/(\d{2})\/(\d{4})/, // DD/MM/YYYY
    /(\d{4})-(\d{2})-(\d{2})/, // YYYY-MM-DD
    /(\d{2})-(\d{2})-(\d{4})/, // DD-MM-YYYY
  ]

  for (const format of formats) {
    const match = dateString.match(format)
    if (match) {
      if (format === formats[0] || format === formats[2]) {
        // DD/MM/YYYY or DD-MM-YYYY
        return new Date(`${match[3]}-${match[2]}-${match[1]}`)
      } else {
        // YYYY-MM-DD
        return new Date(`${match[1]}-${match[2]}-${match[3]}`)
      }
    }
  }

  // Fallback to Date constructor
  return new Date(dateString)
}

async function autoCategorize(transactions: any[], userId: string): Promise<any[]> {
  // Get user's rules
  const rules = await db.rule.findMany({
    where: { userId, isActive: true },
    orderBy: { priority: 'desc' },
  })

  // Get default categories
  const categories = await db.category.findMany({
    where: { userId },
  })

  return transactions.map(transaction => {
    let categoryId = null

    // Apply rules
    for (const rule of rules) {
      try {
        const condition = JSON.parse(rule.condition)
        const action = JSON.parse(rule.action)

        if (matchesCondition(transaction, condition)) {
          if (action.categoryId) {
            categoryId = action.categoryId
            break
          }
        }
      } catch (error) {
        console.error('Error applying rule:', error)
      }
    }

    // Default categorization based on keywords
    if (!categoryId) {
      categoryId = getDefaultCategory(transaction.description, categories)
    }

    return { ...transaction, categoryId }
  })
}

function matchesCondition(transaction: any, condition: any): boolean {
  if (condition.keyword) {
    return transaction.description.toLowerCase().includes(condition.keyword.toLowerCase())
  }
  
  if (condition.amountGreaterThan) {
    return Math.abs(transaction.amount) > condition.amountGreaterThan
  }
  
  if (condition.amountLessThan) {
    return Math.abs(transaction.amount) < condition.amountLessThan
  }
  
  return false
}

function getDefaultCategory(description: string, categories: any[]): string | null {
  const desc = description.toLowerCase()
  
  // Simple keyword-based categorization
  const keywordMap: Record<string, string> = [
    { keywords: ['supermercado', 'mercado', 'comida'], category: 'Mercado' },
    { keywords: ['restaurante', 'lanchonete', 'café'], category: 'Restaurante' },
    { keywords: ['uber', 'taxi', 'transporte', 'ônibus', 'metrô'], category: 'Transporte' },
    { keywords: ['farmácia', 'remédio', 'saúde'], category: 'Farmácia' },
    { keywords: ['netflix', 'spotify', 'assinatura'], category: 'Entretenimento' },
    { keywords: ['salário', 'pagamento', 'recebimento'], category: 'Receita' },
  ]

  for (const { keywords, category } of keywordMap) {
    if (keywords.some(keyword => desc.includes(keyword))) {
      const categoryObj = categories.find(c => c.name === category)
      return categoryObj?.id || null
    }
  }

  return null
}