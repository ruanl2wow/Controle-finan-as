import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const upload = await db.upload.findUnique({
      where: { id: params.id },
      include: {
        _count: {
          select: { transactions: true }
        }
      }
    })

    if (!upload) {
      return NextResponse.json(
        { error: 'Upload not found' },
        { status: 404 }
      )
    }

    return NextResponse.json({
      id: upload.id,
      status: upload.status,
      error: upload.error,
      processedAt: upload.processedAt,
      transactionsCount: upload._count.transactions
    })

  } catch (error) {
    console.error('Status check error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}