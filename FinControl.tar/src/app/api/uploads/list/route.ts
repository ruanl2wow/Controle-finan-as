import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = 'user-1' // TODO: Get from auth session

    const uploads = await db.upload.findMany({
      where: { userId },
      include: {
        account: true,
        _count: {
          select: { transactions: true }
        }
      },
      orderBy: { createdAt: 'desc' },
    })

    return NextResponse.json({ uploads })
  } catch (error) {
    console.error('Error fetching uploads:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}