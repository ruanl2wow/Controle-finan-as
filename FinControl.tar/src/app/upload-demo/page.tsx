'use client'

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Separator } from '@/components/ui/separator'
import { 
  Upload, 
  FileText, 
  CheckCircle, 
  AlertCircle, 
  Clock,
  Database,
  HardDrive,
  Shield,
  ArrowRight,
  Folder,
  Server
} from 'lucide-react'
import { formatFileSize } from '@/lib/utils'

interface FileUpload {
  id: string
  name: string
  size: number
  type: string
  status: 'uploading' | 'processing' | 'completed' | 'error'
  progress: number
  extractedData?: {
    transactions: number
    accounts: string[]
    dateRange: string
  }
}

export default function UploadDemo() {
  const [files, setFiles] = useState<FileUpload[]>([
    {
      id: '1',
      name: 'extrato_janeiro.csv',
      size: 15420,
      type: 'csv',
      status: 'completed',
      progress: 100,
      extractedData: {
        transactions: 45,
        accounts: ['Conta Corrente - Banco do Brasil'],
        dateRange: '01/01/2024 - 31/01/2024'
      }
    },
    {
      id: '2',
      name: 'extrato_fevereiro.ofx',
      size: 28960,
      type: 'ofx',
      status: 'processing',
      progress: 75
    },
    {
      id: '3',
      name: 'cartao_marco.pdf',
      size: 45280,
      type: 'pdf',
      status: 'uploading',
      progress: 45
    }
  ])

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="h-4 w-4 text-green-500" />
      case 'processing':
        return <Clock className="h-4 w-4 text-yellow-500" />
      case 'uploading':
        return <Upload className="h-4 w-4 text-blue-500" />
      case 'error':
        return <AlertCircle className="h-4 w-4 text-red-500" />
      default:
        return <Clock className="h-4 w-4 text-gray-500" />
    }
  }

  const getStatusBadge = (status: string) => {
    const variants: Record<string, 'default' | 'secondary' | 'destructive' | 'outline'> = {
      completed: 'default',
      processing: 'secondary',
      uploading: 'outline',
      error: 'destructive'
    }
    
    const labels: Record<string, string> = {
      completed: 'Concluído',
      processing: 'Processando',
      uploading: 'Enviando',
      error: 'Erro'
    }

    return (
      <Badge variant={variants[status] || 'outline'}>
        {labels[status] || status}
      </Badge>
    )
  }

  const simulateProgress = () => {
    setFiles(prev => prev.map(file => {
      if (file.status === 'uploading' && file.progress < 100) {
        const newProgress = Math.min(file.progress + 10, 100)
        return {
          ...file,
          progress: newProgress,
          status: newProgress === 100 ? 'processing' : 'uploading'
        }
      }
      if (file.status === 'processing' && file.progress < 100) {
        const newProgress = Math.min(file.progress + 15, 100)
        return {
          ...file,
          progress: newProgress,
          status: newProgress === 100 ? 'completed' : 'processing',
          extractedData: newProgress === 100 ? {
            transactions: Math.floor(Math.random() * 50) + 10,
            accounts: ['Conta Corrente - Banco do Brasil'],
            dateRange: '01/02/2024 - 29/02/2024'
          } : undefined
        }
      }
      return file
    }))
  }

  return (
    <div className="container mx-auto py-8">
      <div className="max-w-4xl mx-auto space-y-8">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Demonstração de Upload</h1>
          <p className="text-muted-foreground mt-2">
            Veja como seus extratos bancários são processados e armazenados
          </p>
        </div>

        {/* Storage Flow */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Database className="h-5 w-5 text-blue-500" />
              Fluxo de Armazenamento
            </CardTitle>
            <CardDescription>
              O caminho completo desde o upload até o armazenamento seguro
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between text-center">
              <div className="flex-1">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-3">
                  <Upload className="h-8 w-8 text-blue-600" />
                </div>
                <h4 className="font-medium text-sm mb-1">1. Upload</h4>
                <p className="text-xs text-muted-foreground">
                  Arquivo enviado do seu dispositivo
                </p>
              </div>
              <ArrowRight className="h-5 w-5 text-muted-foreground mx-2" />
              <div className="flex-1">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-3">
                  <FileText className="h-8 w-8 text-green-600" />
                </div>
                <h4 className="font-medium text-sm mb-1">2. Processamento</h4>
                <p className="text-xs text-muted-foreground">
                  Extração e validação dos dados
                </p>
              </div>
              <ArrowRight className="h-5 w-5 text-muted-foreground mx-2" />
              <div className="flex-1">
                <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-3">
                  <Database className="h-8 w-8 text-purple-600" />
                </div>
                <h4 className="font-medium text-sm mb-1">3. Banco de Dados</h4>
                <p className="text-xs text-muted-foreground">
                  SQLite local com criptografia
                </p>
              </div>
              <ArrowRight className="h-5 w-5 text-muted-foreground mx-2" />
              <div className="flex-1">
                <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-3">
                  <Shield className="h-8 w-8 text-orange-600" />
                </div>
                <h4 className="font-medium text-sm mb-1">4. Proteção</h4>
                <p className="text-xs text-muted-foreground">
                  Isolamento e backup automático
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Storage Locations */}
        <div className="grid md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <HardDrive className="h-5 w-5 text-green-500" />
                Arquivos Originais
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center gap-2">
                <Folder className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm font-medium">Local:</span>
                <span className="text-sm text-muted-foreground">./uploads/</span>
              </div>
              <div className="flex items-center gap-2">
                <Server className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm font-medium">Servidor:</span>
                <span className="text-sm text-muted-foreground">Local</span>
              </div>
              <div className="flex items-center gap-2">
                <Shield className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm font-medium">Segurança:</span>
                <span className="text-sm text-muted-foreground">Permissões restritas</span>
              </div>
              <div className="bg-blue-50 p-3 rounded-lg">
                <p className="text-xs text-blue-700">
                  Os arquivos originais são mantidos para referência e reprocessamento, 
                  com acesso restrito ao sistema.
                </p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Database className="h-5 w-5 text-purple-500" />
                Dados Estruturados
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center gap-2">
                <Database className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm font-medium">Tipo:</span>
                <span className="text-sm text-muted-foreground">SQLite</span>
              </div>
              <div className="flex items-center gap-2">
                <Server className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm font-medium">Local:</span>
                <span className="text-sm text-muted-foreground">Servidor local</span>
              </div>
              <div className="flex items-center gap-2">
                <Shield className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm font-medium">Segurança:</span>
                <span className="text-sm text-muted-foreground">Criptografado</span>
              </div>
              <div className="bg-green-50 p-3 rounded-lg">
                <p className="text-xs text-green-700">
                  Dados estruturados para consultas rápidas, análises e relatórios, 
                  com isolamento completo por usuário.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Upload Progress */}
        <Card>
          <CardHeader>
            <CardTitle>Uploads em Tempo Real</CardTitle>
            <CardDescription>
              Simulação do processo de upload e processamento
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {files.map((file) => (
              <div key={file.id} className="border rounded-lg p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    {getStatusIcon(file.status)}
                    <div>
                      <div className="font-medium text-sm">{file.name}</div>
                      <div className="text-xs text-muted-foreground">
                        {file.type.toUpperCase()} • {formatFileSize(file.size)}
                      </div>
                    </div>
                  </div>
                  {getStatusBadge(file.status)}
                </div>
                
                <Progress value={file.progress} className="h-2" />
                
                {file.extractedData && (
                  <div className="bg-gray-50 p-3 rounded-lg">
                    <div className="text-xs font-medium mb-2">Dados Extraídos:</div>
                    <div className="grid grid-cols-3 gap-2 text-xs">
                      <div>
                        <span className="text-muted-foreground">Transações:</span>
                        <div className="font-medium">{file.extractedData.transactions}</div>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Contas:</span>
                        <div className="font-medium">{file.extractedData.accounts.length}</div>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Período:</span>
                        <div className="font-medium text-xs">{file.extractedData.dateRange}</div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            ))}
            
            <div className="flex justify-center pt-4">
              <Button onClick={simulateProgress} variant="outline">
                Simular Progresso
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Security Summary */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Shield className="h-5 w-5 text-red-500" />
              Resumo de Segurança
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-medium mb-3">📁 Arquivos</h4>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li>• Armazenados em pasta segura do servidor</li>
                  <li>• Permissões de acesso restritas</li>
                  <li>• Nomes de arquivo criptografados</li>
                  <li>• Backup diário automático</li>
                </ul>
              </div>
              <div>
                <h4 className="font-medium mb-3">🗄️ Banco de Dados</h4>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li>• SQLite local e isolado</li>
                  <li>• Dados sensíveis criptografados</li>
                  <li>• Acesso apenas via autenticação</li>
                  <li>• Isolamento completo por usuário</li>
                </ul>
              </div>
            </div>
            
            <Separator className="my-4" />
            
            <div className="bg-green-50 p-4 rounded-lg">
              <h4 className="font-medium text-green-900 mb-2">✅ Seus dados estão seguros</h4>
              <p className="text-sm text-green-700">
                Todos os dados são armazenados localmente em nosso servidor, sem compartilhamento 
                com terceiros. Você tem controle total e pode exportar ou solicitar exclusão 
                a qualquer momento.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}