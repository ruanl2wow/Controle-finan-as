'use client'

import { useState, useCallback, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'
import { Badge } from '@/components/ui/badge'
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select'
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogHeader, 
  DialogTitle 
} from '@/components/ui/dialog'
import { 
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import { 
  Upload, 
  FileText, 
  CheckCircle, 
  XCircle, 
  Clock,
  AlertCircle,
  Download,
  Eye,
  Trash2,
  RefreshCw,
  Plus
} from 'lucide-react'
import { toast } from 'sonner'

interface Account {
  id: string
  name: string
  type: string
  balance: number
  currency: string
  _count: { transactions: number }
}

interface UploadFile {
  id: string
  filename: string
  originalName: string
  fileType: string
  fileSize: number
  status: 'pending' | 'processing' | 'completed' | 'error'
  progress?: number
  error?: string
  processedAt?: string
  transactionsCount?: number
  account?: string
}

const supportedFormats = [
  { ext: 'csv', name: 'CSV', description: 'Valores separados por vírgula' },
  { ext: 'ofx', name: 'OFX', description: 'Open Financial Exchange' },
  { ext: 'qif', name: 'QIF', description: 'Quicken Interchange Format' },
  { ext: 'pdf', name: 'PDF', description: 'Apenas PDF baseado em texto' }
]

export default function UploadPage() {
  const [uploads, setUploads] = useState<UploadFile[]>([])
  const [accounts, setAccounts] = useState<Account[]>([])
  const [selectedAccount, setSelectedAccount] = useState<string>('')
  const [isDragging, setIsDragging] = useState(false)
  const [isLoadingAccounts, setIsLoadingAccounts] = useState(true)
  const [previewData, setPreviewData] = useState<any[]>([])
  const [showPreview, setShowPreview] = useState(false)
  const [columnMapping, setColumnMapping] = useState<Record<string, string>>({})

  useEffect(() => {
    fetchAccounts()
    fetchUploads()
  }, [])

  const fetchAccounts = async () => {
    try {
      const response = await fetch('/api/accounts')
      if (response.ok) {
        const data = await response.json()
        setAccounts(data.accounts)
        if (data.accounts.length > 0) {
          setSelectedAccount(data.accounts[0].id)
        }
      }
    } catch (error) {
      console.error('Error fetching accounts:', error)
      toast.error('Erro ao carregar contas')
    } finally {
      setIsLoadingAccounts(false)
    }
  }

  const fetchUploads = async () => {
    try {
      const response = await fetch('/api/uploads/list')
      if (response.ok) {
        const data = await response.json()
        setUploads(data.uploads)
      }
    } catch (error) {
      console.error('Error fetching uploads:', error)
    }
  }

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(true)
  }, [])

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(false)
  }, [])

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(false)
    const files = Array.from(e.dataTransfer.files)
    handleFiles(files)
  }, [])

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || [])
    handleFiles(files)
  }

  const handleFiles = async (files: File[]) => {
    if (!selectedAccount) {
      toast.error('Por favor, selecione uma conta primeiro.')
      return
    }

    for (const file of files) {
      const fileExt = file.name.split('.').pop()?.toLowerCase()
      
      if (!fileExt || !supportedFormats.some(f => f.ext === fileExt)) {
        toast.error(`Formato de arquivo não suportado: ${fileExt}`)
        continue
      }

      const newUpload: UploadFile = {
        id: Date.now().toString(),
        filename: file.name,
        originalName: file.name,
        fileType: fileExt!,
        fileSize: file.size,
        status: 'pending',
        account: accounts.find(a => a.id === selectedAccount)?.name
      }

      setUploads(prev => [...prev, newUpload])

      try {
        // Create FormData for API request
        const formData = new FormData()
        formData.append('file', file)
        formData.append('accountId', selectedAccount)

        // Upload file
        const response = await fetch('/api/uploads', {
          method: 'POST',
          body: formData
        })

        if (!response.ok) {
          const errorData = await response.json()
          throw new Error(errorData.error || 'Failed to upload file')
        }

        const result = await response.json()
        
        // Update upload with server data
        setUploads(prev => prev.map(u => 
          u.id === newUpload.id 
            ? { ...u, id: result.upload.id, status: 'processing' }
            : u
        ))

        toast.success('Arquivo enviado com sucesso! Processando...')

        // Start polling for status updates
        const pollInterval = setInterval(async () => {
          try {
            const statusResponse = await fetch(`/api/uploads/${result.upload.id}/status`)
            if (statusResponse.ok) {
              const statusData = await statusResponse.json()
              
              setUploads(prev => prev.map(u => 
                u.id === result.upload.id 
                  ? { 
                      ...u, 
                      status: statusData.status,
                      error: statusData.error,
                      processedAt: statusData.processedAt,
                      transactionsCount: statusData.transactionsCount
                    }
                  : u
              ))

              if (statusData.status === 'completed') {
                clearInterval(pollInterval)
                toast.success(`Processamento concluído! ${statusData.transactionsCount} transações importadas.`)
                fetchUploads() // Refresh uploads list
              } else if (statusData.status === 'error') {
                clearInterval(pollInterval)
                toast.error(`Erro no processamento: ${statusData.error}`)
              }
            }
          } catch (error) {
            console.error('Error polling status:', error)
          }
        }, 2000)

      } catch (error) {
        console.error('Upload error:', error)
        const errorMessage = error instanceof Error ? error.message : 'Failed to upload file'
        toast.error(errorMessage)
        setUploads(prev => prev.map(u => 
          u.id === newUpload.id 
            ? { ...u, status: 'error', error: errorMessage }
            : u
        ))
      }
    }
  }

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes'
    const k = 1024
    const sizes = ['Bytes', 'KB', 'MB', 'GB']
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i]
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="h-4 w-4 text-green-500" />
      case 'processing':
        return <Clock className="h-4 w-4 text-blue-500 animate-spin" />
      case 'error':
        return <XCircle className="h-4 w-4 text-red-500" />
      default:
        return <Clock className="h-4 w-4 text-gray-500" />
    }
  }

  const getStatusBadge = (status: string) => {
    const variants: Record<string, 'default' | 'secondary' | 'destructive' | 'outline'> = {
      completed: 'default',
      processing: 'secondary',
      error: 'destructive',
      pending: 'outline'
    }
    
    const labels: Record<string, string> = {
      completed: 'Concluído',
      processing: 'Processando',
      error: 'Erro',
      pending: 'Pendente'
    }

    return (
      <Badge variant={variants[status]}>
        {labels[status]}
      </Badge>
    )
  }

  const retryUpload = (id: string) => {
    setUploads(prev => prev.map(u => 
      u.id === id 
        ? { ...u, status: 'pending', error: undefined }
        : u
    ))
    
    // Simular retry
    setTimeout(() => {
      setUploads(prev => prev.map(u => 
        u.id === id 
          ? { ...u, status: 'processing', progress: 0 }
          : u
      ))
    }, 500)
  }

  const deleteUpload = (id: string) => {
    setUploads(prev => prev.filter(u => u.id !== id))
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Upload de Extratos</h1>
          <p className="text-muted-foreground">
            Faça upload dos seus extratos bancários para importar transações automaticamente
          </p>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Área de Upload */}
        <div className="lg:col-span-2 space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Novo Upload</CardTitle>
              <CardDescription>
                Selecione a conta e arraste os arquivos ou clique para selecionar
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="text-sm font-medium mb-2 block">Conta</label>
                {isLoadingAccounts ? (
                  <Select disabled>
                    <SelectTrigger>
                      <SelectValue placeholder="Carregando contas..." />
                    </SelectTrigger>
                  </Select>
                ) : accounts.length === 0 ? (
                  <div className="space-y-2">
                    <Select disabled>
                      <SelectTrigger>
                        <SelectValue placeholder="Nenhuma conta encontrada" />
                      </SelectTrigger>
                    </Select>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="w-full"
                      onClick={() => window.location.href = '/accounts'}
                    >
                      <Plus className="h-4 w-4 mr-2" />
                      Criar Primeira Conta
                    </Button>
                  </div>
                ) : (
                  <Select value={selectedAccount} onValueChange={setSelectedAccount}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione uma conta" />
                    </SelectTrigger>
                    <SelectContent>
                      {accounts.map(account => (
                        <SelectItem key={account.id} value={account.id}>
                          {account.name} ({account.type})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                )}
              </div>

              <div
                className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
                  isDragging 
                    ? 'border-primary bg-primary/5' 
                    : 'border-muted-foreground/25 hover:border-primary/50'
                }`}
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onDrop={handleDrop}
              >
                <Upload className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                <div className="space-y-2">
                  <p className="text-lg font-medium">
                    {isDragging ? 'Solte os arquivos aqui' : 'Arraste arquivos para cá'}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    ou clique para selecionar manualmente
                  </p>
                </div>
                <input
                  type="file"
                  multiple
                  accept=".csv,.ofx,.qif,.pdf"
                  onChange={handleFileInput}
                  className="hidden"
                  id="file-upload"
                />
                <label htmlFor="file-upload">
                  <Button className="mt-4" asChild>
                    <span>Selecionar Arquivos</span>
                  </Button>
                </label>
              </div>

              <div className="space-y-2">
                <p className="text-sm font-medium">Formatos suportados:</p>
                <div className="grid grid-cols-2 gap-2">
                  {supportedFormats.map(format => (
                    <div key={format.ext} className="flex items-center gap-2 text-sm">
                      <Badge variant="outline">{format.ext.toUpperCase()}</Badge>
                      <span className="text-muted-foreground">{format.description}</span>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Histórico de Uploads */}
          <Card>
            <CardHeader>
              <CardTitle>Histórico de Uploads</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {uploads.map(upload => (
                  <div key={upload.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center gap-3">
                      <FileText className="h-8 w-8 text-muted-foreground" />
                      <div>
                        <p className="font-medium">{upload.originalName}</p>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <span>{formatFileSize(upload.fileSize)}</span>
                          <span>•</span>
                          <span>{upload.fileType.toUpperCase()}</span>
                          <span>•</span>
                          <span>{upload.account}</span>
                        </div>
                        {upload.status === 'processing' && upload.progress !== undefined && (
                          <div className="mt-2">
                            <Progress value={upload.progress} className="w-32" />
                          </div>
                        )}
                        {upload.status === 'error' && upload.error && (
                          <p className="text-sm text-red-600 mt-1">{upload.error}</p>
                        )}
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      {getStatusIcon(upload.status)}
                      {getStatusBadge(upload.status)}
                      
                      {upload.status === 'completed' && upload.transactionsCount && (
                        <Badge variant="secondary">
                          {upload.transactionsCount} transações
                        </Badge>
                      )}
                      
                      <div className="flex gap-1">
                        {upload.status === 'error' && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => retryUpload(upload.id)}
                          >
                            <RefreshCw className="h-4 w-4" />
                          </Button>
                        )}
                        {upload.status === 'completed' && (
                          <Button variant="outline" size="sm">
                            <Eye className="h-4 w-4" />
                          </Button>
                        )}
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => deleteUpload(upload.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
                
                {uploads.length === 0 && (
                  <div className="text-center py-8 text-muted-foreground">
                    <Upload className="mx-auto h-12 w-12 mb-4" />
                    <p>Nenhum upload realizado ainda</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Sidebar com informações */}
        <div className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Dicas</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex gap-3">
                <AlertCircle className="h-5 w-5 text-blue-500 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-sm font-medium">Formato CSV</p>
                  <p className="text-xs text-muted-foreground">
                    Certifique-se de que seu CSV tenha colunas para data, descrição e valor.
                  </p>
                </div>
              </div>
              
              <div className="flex gap-3">
                <AlertCircle className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-sm font-medium">OFX/QIF</p>
                  <p className="text-xs text-muted-foreground">
                    Formatos padrão de exportação da maioria dos bancos.
                  </p>
                </div>
              </div>
              
              <div className="flex gap-3">
                <AlertCircle className="h-5 w-5 text-orange-500 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-sm font-medium">PDF</p>
                  <p className="text-xs text-muted-foreground">
                    Apenas PDFs baseados em texto. PDFs escaneados não são suportados.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Estatísticas</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Total de uploads</span>
                <span className="font-medium">{uploads.length}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Concluídos</span>
                <span className="font-medium text-green-600">
                  {uploads.filter(u => u.status === 'completed').length}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Processando</span>
                <span className="font-medium text-blue-600">
                  {uploads.filter(u => u.status === 'processing').length}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Com erro</span>
                <span className="font-medium text-red-600">
                  {uploads.filter(u => u.status === 'error').length}
                </span>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}