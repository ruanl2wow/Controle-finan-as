'use client'

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { 
  Accordion, 
  AccordionContent, 
  AccordionItem, 
  AccordionTrigger 
} from '@/components/ui/accordion'
import { 
  FileText, 
  Upload, 
  Filter, 
  Download,
  HelpCircle,
  MessageCircle,
  Book,
  Video,
  Mail,
  ExternalLink
} from 'lucide-react'

const faqItems = [
  {
    question: "Como faço upload do meu extrato bancário?",
    answer: "Vá para a página de Upload, selecione a conta correspondente e arraste o arquivo ou clique para selecionar. Suportamos os formatos CSV, OFX, QIF e PDF (baseado em texto)."
  },
  {
    question: "Quais formatos de arquivo são suportados?",
    answer: "Atualmente suportamos CSV (valores separados por vírgula), OFX (Open Financial Exchange), QIF (Quicken Interchange Format) e PDFs que contenham texto (não imagens escaneadas)."
  },
  {
    question: "Como funcionam as regras de classificação automática?",
    answer: "As regras analisam as descrições das transações e aplicam condições (como palavras-chave) para categorizar automaticamente. Você pode criar regras personalizadas na página de Categorias & Regras."
  },
  {
    question: "Posso editar transações após o upload?",
    answer: "Sim! Todas as transações são editáveis na planilha. Basta clicar na célula que deseja editar, fazer as alterações e pressionar Enter para salvar."
  },
  {
    question: "Como exporto meus dados?",
    answer: "Na página de Relatórios, clique em 'Exportar' e escolha entre CSV ou Excel. Você pode aplicar filtros de período, conta e categoria antes de exportar."
  },
  {
    question: "Meus dados estão seguros?",
    answer: "Sim, todos os dados são criptografados em trânsito e em repouso. Utilizamos conexões HTTPS seguras e seguimos as melhores práticas de segurança da indústria."
  }
]

const tutorialSteps = [
  {
    title: "1. Faça seu primeiro upload",
    description: "Vá para a página Upload e envie um extrato no formato CSV ou OFX",
    icon: Upload,
    status: "pending"
  },
  {
    title: "2. Verifique as transações",
    description: "Na planilha, revise as transações importadas e faça ajustes se necessário",
    icon: Filter,
    status: "pending"
  },
  {
    title: "3. Crie categorias",
    description: "Configure suas categorias pessoais para melhor organização",
    icon: FileText,
    status: "pending"
  },
  {
    title: "4. Configure regras",
    description: "Crie regras automáticas para classificar transações futuras",
    icon: Filter,
    status: "pending"
  },
  {
    title: "5. Explore o dashboard",
    description: "Visualize gráficos e relatórios para entender suas finanças",
    icon: Download,
    status: "pending"
  }
]

const resources = [
  {
    title: "Guia de Início Rápido",
    description: "Aprenda os conceitos básicos em 5 minutos",
    icon: Book,
    type: "article",
    url: "#"
  },
  {
    title: "Vídeos Tutoriais",
    description: "Assista demonstrações passo a passo",
    icon: Video,
    type: "video",
    url: "#"
  },
  {
    title: "API Documentation",
    description: "Documentação técnica para desenvolvedores",
    icon: FileText,
    type: "technical",
    url: "#"
  },
  {
    title: "Blog da FinControl",
    description: "Dicas e melhores práticas de finanças",
    icon: FileText,
    type: "blog",
    url: "#"
  }
]

export default function AjudaPage() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Central de Ajuda</h1>
          <p className="text-muted-foreground">
            Encontre respostas, tutoriais e recursos para usar o FinControl
          </p>
        </div>
        <Button>
          <MessageCircle className="mr-2 h-4 w-4" />
          Suporte ao Vivo
        </Button>
      </div>

      {/* Quick Actions */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card className="cursor-pointer hover:shadow-md transition-shadow">
          <CardContent className="p-4 text-center">
            <Upload className="mx-auto h-8 w-8 text-blue-500 mb-2" />
            <h3 className="font-medium">Fazer Upload</h3>
            <p className="text-sm text-muted-foreground">Importe seu primeiro extrato</p>
          </CardContent>
        </Card>

        <Card className="cursor-pointer hover:shadow-md transition-shadow">
          <CardContent className="p-4 text-center">
            <FileText className="mx-auto h-8 w-8 text-green-500 mb-2" />
            <h3 className="font-medium">Ver Tutorial</h3>
            <p className="text-sm text-muted-foreground">Aprenda a usar o sistema</p>
          </CardContent>
        </Card>

        <Card className="cursor-pointer hover:shadow-md transition-shadow">
          <CardContent className="p-4 text-center">
            <MessageCircle className="mx-auto h-8 w-8 text-purple-500 mb-2" />
            <h3 className="font-medium">Chat Suporte</h3>
            <p className="text-sm text-muted-foreground">Fale com nossa equipe</p>
          </CardContent>
        </Card>

        <Card className="cursor-pointer hover:shadow-md transition-shadow">
          <CardContent className="p-4 text-center">
            <Mail className="mx-auto h-8 w-8 text-orange-500 mb-2" />
            <h3 className="font-medium">Enviar E-mail</h3>
            <p className="text-sm text-muted-foreground">suporte@fincontrol.com</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Getting Started */}
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Começando a Usar</CardTitle>
              <CardDescription>
                Siga estes passos para configurar sua conta rapidamente
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {tutorialSteps.map((step, index) => {
                  const IconComponent = step.icon
                  return (
                    <div key={index} className="flex items-start gap-3 p-3 border rounded-lg">
                      <div className="p-2 bg-muted rounded-lg">
                        <IconComponent className="h-4 w-4" />
                      </div>
                      <div className="flex-1">
                        <h4 className="font-medium">{step.title}</h4>
                        <p className="text-sm text-muted-foreground">{step.description}</p>
                      </div>
                      <Badge variant={step.status === 'completed' ? 'default' : 'secondary'}>
                        {step.status === 'completed' ? 'Concluído' : 'Pendente'}
                      </Badge>
                    </div>
                  )
                })}
              </div>
            </CardContent>
          </Card>

          {/* FAQ */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <HelpCircle className="h-5 w-5" />
                Perguntas Frequentes
              </CardTitle>
              <CardDescription>
                Respostas para as dúvidas mais comuns
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Accordion type="single" collapsible className="w-full">
                {faqItems.map((item, index) => (
                  <AccordionItem key={index} value={`item-${index}`}>
                    <AccordionTrigger className="text-left">
                      {item.question}
                    </AccordionTrigger>
                    <AccordionContent className="text-muted-foreground">
                      {item.answer}
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            </CardContent>
          </Card>
        </div>

        {/* Resources */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Recursos</CardTitle>
              <CardDescription>
                Materiais para aprender mais
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {resources.map((resource, index) => {
                const IconComponent = resource.icon
                return (
                  <div key={index} className="flex items-start gap-3 p-3 border rounded-lg hover:bg-muted/50 cursor-pointer">
                    <div className="p-2 bg-muted rounded-lg">
                      <IconComponent className="h-4 w-4" />
                    </div>
                    <div className="flex-1">
                      <h4 className="font-medium text-sm">{resource.title}</h4>
                      <p className="text-xs text-muted-foreground">{resource.description}</p>
                    </div>
                    <ExternalLink className="h-4 w-4 text-muted-foreground" />
                  </div>
                )
              })}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Precisa de Ajuda?</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="text-center space-y-3">
                <HelpCircle className="mx-auto h-12 w-12 text-muted-foreground" />
                <p className="text-sm text-muted-foreground">
                  Nossa equipe de suporte está disponível para ajudar você
                </p>
                <div className="space-y-2">
                  <Button className="w-full">
                    <MessageCircle className="mr-2 h-4 w-4" />
                    Iniciar Chat
                  </Button>
                  <Button variant="outline" className="w-full">
                    <Mail className="mr-2 h-4 w-4" />
                    Enviar E-mail
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}