'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { 
  Database, 
  HardDrive, 
  Shield, 
  FileText, 
  Upload, 
  Clock,
  CheckCircle,
  AlertCircle,
  Server,
  Lock,
  Backup
} from 'lucide-react'
import { formatFileSize, formatDate } from '@/lib/utils'

interface StorageInfo {
  storage: {
    database: {
      type: string
      location: string
      description: string
      tables: {
        transactions: number
        accounts: number
        categories: number
        uploads: number
        rules: number
      }
    }
    files: {
      location: string
      description: string
      totalFiles: number
      totalSize: number
      recentUploads: Array<{
        id: string
        filename: string
        originalName: string
        fileType: string
        fileSize: number
        status: string
        createdAt: string
        processedAt?: string
        account?: {
          name: string
        }
      }>
    }
    security: {
      encryption: string
      isolation: string
      backup: string
    }
  }
}

export default function StoragePage() {
  const [storageInfo, setStorageInfo] = useState<StorageInfo | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchStorageInfo()
  }, [])

  const fetchStorageInfo = async () => {
    try {
      const response = await fetch('/api/storage-info')
      if (response.ok) {
        const data = await response.json()
        setStorageInfo(data)
      }
    } catch (error) {
      console.error('Error fetching storage info:', error)
    } finally {
      setLoading(false)
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="h-4 w-4 text-green-500" />
      case 'processing':
        return <Clock className="h-4 w-4 text-yellow-500" />
      case 'error':
        return <AlertCircle className="h-4 w-4 text-red-500" />
      default:
        return <Clock className="h-4 w-4 text-gray-500" />
    }
  }

  const getStatusBadge = (status: string) => {
    const variants: Record<string, 'default' | 'secondary' | 'destructive' | 'outline'> = {
      completed: 'default',
      processing: 'secondary',
      error: 'destructive',
      pending: 'outline'
    }
    
    const labels: Record<string, string> = {
      completed: 'Concluído',
      processing: 'Processando',
      error: 'Erro',
      pending: 'Pendente'
    }

    return (
      <Badge variant={variants[status] || 'outline'}>
        {labels[status] || status}
      </Badge>
    )
  }

  if (loading) {
    return (
      <div className="container mx-auto py-8">
        <div className="max-w-6xl mx-auto">
          <div className="animate-pulse">
            <div className="h-8 bg-gray-200 rounded w-1/3 mb-8"></div>
            <div className="grid gap-6">
              <div className="h-32 bg-gray-200 rounded"></div>
              <div className="h-32 bg-gray-200 rounded"></div>
              <div className="h-32 bg-gray-200 rounded"></div>
            </div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="container mx-auto py-8">
      <div className="max-w-6xl mx-auto space-y-8">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Armazenamento de Dados</h1>
          <p className="text-muted-foreground mt-2">
            Onde seus dados financeiros são armazenados e como são protegidos
          </p>
        </div>

        {/* Database Storage */}
        <Card>
          <CardHeader>
            <div className="flex items-center gap-2">
              <Database className="h-5 w-5 text-blue-500" />
              <CardTitle>Banco de Dados</CardTitle>
            </div>
            <CardDescription>
              Armazenamento estruturado dos seus dados financeiros
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <Server className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm font-medium">Tipo:</span>
                  <Badge variant="outline">{storageInfo?.storage.database.type}</Badge>
                </div>
                <div className="flex items-center gap-2">
                  <HardDrive className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm font-medium">Localização:</span>
                  <span className="text-sm text-muted-foreground">
                    {storageInfo?.storage.database.location}
                  </span>
                </div>
              </div>
              <div className="text-sm text-muted-foreground">
                {storageInfo?.storage.database.description}
              </div>
            </div>
            
            <Separator />
            
            <div>
              <h4 className="text-sm font-medium mb-3">Estatísticas das Tabelas</h4>
              <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                <div className="text-center p-3 bg-gray-50 rounded-lg">
                  <div className="text-2xl font-bold text-blue-600">
                    {storageInfo?.storage.database.tables.transactions}
                  </div>
                  <div className="text-xs text-muted-foreground">Transações</div>
                </div>
                <div className="text-center p-3 bg-gray-50 rounded-lg">
                  <div className="text-2xl font-bold text-green-600">
                    {storageInfo?.storage.database.tables.accounts}
                  </div>
                  <div className="text-xs text-muted-foreground">Contas</div>
                </div>
                <div className="text-center p-3 bg-gray-50 rounded-lg">
                  <div className="text-2xl font-bold text-purple-600">
                    {storageInfo?.storage.database.tables.categories}
                  </div>
                  <div className="text-xs text-muted-foreground">Categorias</div>
                </div>
                <div className="text-center p-3 bg-gray-50 rounded-lg">
                  <div className="text-2xl font-bold text-orange-600">
                    {storageInfo?.storage.database.tables.uploads}
                  </div>
                  <div className="text-xs text-muted-foreground">Uploads</div>
                </div>
                <div className="text-center p-3 bg-gray-50 rounded-lg">
                  <div className="text-2xl font-bold text-red-600">
                    {storageInfo?.storage.database.tables.rules}
                  </div>
                  <div className="text-xs text-muted-foreground">Regras</div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* File Storage */}
        <Card>
          <CardHeader>
            <div className="flex items-center gap-2">
              <FileText className="h-5 w-5 text-green-500" />
              <CardTitle>Arquivos de Extratos</CardTitle>
            </div>
            <CardDescription>
              Armazenamento dos arquivos de extratos bancários enviados
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid md:grid-cols-3 gap-4">
              <div className="flex items-center gap-2">
                <HardDrive className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm font-medium">Localização:</span>
                <span className="text-sm text-muted-foreground">
                  {storageInfo?.storage.files.location}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <Upload className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm font-medium">Arquivos:</span>
                <Badge variant="outline">{storageInfo?.storage.files.totalFiles}</Badge>
              </div>
              <div className="flex items-center gap-2">
                <Database className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm font-medium">Tamanho Total:</span>
                <Badge variant="outline">
                  {formatFileSize(storageInfo?.storage.files.totalSize || 0)}
                </Badge>
              </div>
            </div>

            <div className="text-sm text-muted-foreground">
              {storageInfo?.storage.files.description}
            </div>

            {storageInfo?.storage.files.recentUploads.length > 0 && (
              <>
                <Separator />
                <div>
                  <h4 className="text-sm font-medium mb-3">Uploads Recentes</h4>
                  <div className="space-y-2">
                    {storageInfo.storage.files.recentUploads.map((upload) => (
                      <div
                        key={upload.id}
                        className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
                      >
                        <div className="flex items-center gap-3">
                          {getStatusIcon(upload.status)}
                          <div>
                            <div className="text-sm font-medium">{upload.originalName}</div>
                            <div className="text-xs text-muted-foreground">
                              {upload.fileType.toUpperCase()} • {formatFileSize(upload.fileSize)}
                              {upload.account && ` • ${upload.account.name}`}
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          {getStatusBadge(upload.status)}
                          <div className="text-xs text-muted-foreground">
                            {formatDate(upload.createdAt)}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </>
            )}
          </CardContent>
        </Card>

        {/* Security */}
        <Card>
          <CardHeader>
            <div className="flex items-center gap-2">
              <Shield className="h-5 w-5 text-red-500" />
              <CardTitle>Segurança e Privacidade</CardTitle>
            </div>
            <CardDescription>
              Como seus dados são protegidos
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-3 gap-6">
              <div className="flex items-start gap-3">
                <Lock className="h-5 w-5 text-blue-500 mt-0.5" />
                <div>
                  <h4 className="font-medium text-sm">Criptografia</h4>
                  <p className="text-xs text-muted-foreground mt-1">
                    {storageInfo?.storage.security.encryption}
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <Shield className="h-5 w-5 text-green-500 mt-0.5" />
                <div>
                  <h4 className="font-medium text-sm">Isolamento</h4>
                  <p className="text-xs text-muted-foreground mt-1">
                    {storageInfo?.storage.security.isolation}
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <Backup className="h-5 w-5 text-purple-500 mt-0.5" />
                <div>
                  <h4 className="font-medium text-sm">Backup</h4>
                  <p className="text-xs text-muted-foreground mt-1">
                    {storageInfo?.storage.security.backup}
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Data Flow Diagram */}
        <Card>
          <CardHeader>
            <CardTitle>Fluxo de Dados</CardTitle>
            <CardDescription>
              Como seus dados percorrem o sistema
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-4 gap-4">
              <div className="text-center">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-2">
                  <Upload className="h-8 w-8 text-blue-600" />
                </div>
                <h4 className="font-medium text-sm">1. Upload</h4>
                <p className="text-xs text-muted-foreground mt-1">
                  Extratos enviados via interface
                </p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-2">
                  <FileText className="h-8 w-8 text-green-600" />
                </div>
                <h4 className="font-medium text-sm">2. Processamento</h4>
                <p className="text-xs text-muted-foreground mt-1">
                  Parse e validação dos dados
                </p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-2">
                  <Database className="h-8 w-8 text-purple-600" />
                </div>
                <h4 className="font-medium text-sm">3. Armazenamento</h4>
                <p className="text-xs text-muted-foreground mt-1">
                  Salvos no banco SQLite
                </p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-2">
                  <Shield className="h-8 w-8 text-orange-600" />
                </div>
                <h4 className="font-medium text-sm">4. Proteção</h4>
                <p className="text-xs text-muted-foreground mt-1">
                  Criptografia e isolamento
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Actions */}
        <div className="flex justify-end gap-4">
          <Button variant="outline" onClick={fetchStorageInfo}>
            Atualizar Dados
          </Button>
          <Button>
            Exportar Dados
          </Button>
        </div>
      </div>
    </div>
  )
}