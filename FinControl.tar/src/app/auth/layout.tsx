import { SessionProviderWrapper } from '@/components/session-provider'

export default function AuthLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <SessionProviderWrapper>
      {children}
    </SessionProviderWrapper>
  )
}