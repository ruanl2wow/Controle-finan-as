'use client'

import { useSearchParams } from 'next/navigation'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { 
  AlertTriangle, 
  RefreshCw,
  ArrowLeft
} from 'lucide-react'
import Link from 'next/link'

export default function AuthErrorPage() {
  const searchParams = useSearchParams()
  const error = searchParams.get('error')

  const getErrorMessage = (error: string | null) => {
    switch (error) {
      case 'Configuration':
        return 'Erro de configuração do servidor. Por favor, tente novamente mais tarde.'
      case 'AccessDenied':
        return 'Acesso negado. Você não tem permissão para acessar este recurso.'
      case 'Verification':
        return 'Erro de verificação. O token de verificação pode ter expirado.'
      case 'Default':
        return 'Ocorreu um erro durante a autenticação.'
      case 'OAuthSignin':
        return 'Erro ao tentar fazer login com provedor OAuth.'
      case 'OAuthCallback':
        return 'Erro durante o callback do OAuth.'
      case 'OAuthCreateAccount':
        return 'Erro ao criar conta com provedor OAuth.'
      case 'EmailCreateAccount':
        return 'Erro ao criar conta com email.'
      case 'Callback':
        return 'Erro durante o callback de autenticação.'
      case 'OAuthAccountNotLinked':
        return 'Esta conta já está vinculada a outro provedor.'
      case 'SessionRequired':
        return 'Você precisa estar logado para acessar esta página.'
      default:
        return 'Ocorreu um erro desconhecido. Por favor, tente novamente.'
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-red-50 to-orange-100 p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <Link href="/auth/signin" className="inline-flex items-center text-sm text-gray-600 hover:text-gray-900 mb-4">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Voltar para Login
          </Link>
          <div className="mx-auto w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mb-4">
            <AlertTriangle className="w-8 h-8 text-red-600" />
          </div>
          <h1 className="text-2xl font-bold text-gray-900">Erro de Autenticação</h1>
          <p className="text-gray-600 mt-2">Ocorreu um problema durante o login</p>
        </div>

        <Card className="shadow-xl border-0">
          <CardHeader>
            <CardTitle className="text-xl text-center text-red-600">
              Falha na Autenticação
            </CardTitle>
            <CardDescription className="text-center">
              {error && `Código do erro: ${error}`}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <Alert variant="destructive">
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                {getErrorMessage(error)}
              </AlertDescription>
            </Alert>

            <div className="space-y-3">
              <Button asChild className="w-full">
                <Link href="/auth/signin">
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Tentar Novamente
                </Link>
              </Button>
              
              <Button variant="outline" asChild className="w-full">
                <Link href="/">
                  Voltar para Home
                </Link>
              </Button>
            </div>

            <div className="text-center">
              <p className="text-sm text-gray-600">
                Se o problema persistir, entre em contato com nosso{' '}
                <Link href="/help" className="text-blue-600 hover:underline">
                  suporte técnico
                </Link>
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Informações de Debug */}
        {process.env.NODE_ENV === 'development' && (
          <Card className="mt-6 border-yellow-200 bg-yellow-50/50">
            <CardContent className="pt-6">
              <div className="space-y-2">
                <h3 className="font-medium text-yellow-900">🔍 Informações de Debug</h3>
                <p className="text-sm text-yellow-700">
                  <strong>Error:</strong> {error || 'Nenhum erro especificado'}
                </p>
                <p className="text-sm text-yellow-700">
                  <strong>URL:</strong> {typeof window !== 'undefined' ? window.location.href : 'N/A'}
                </p>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}