'use client'

import { useEffect, useState, useRef } from 'react'
import { io, Socket } from 'socket.io-client'

interface NotificationData {
  id: string;
  type: string;
  title: string;
  message: string;
  priority: string;
  read: boolean;
  createdAt: string;
  data?: any;
  timestamp: string;
}

interface UploadProgress {
  uploadId: string;
  filename: string;
  progress: number;
  status: string;
  error?: string;
  timestamp: string;
}

export function useWebSocket(userId?: string) {
  const [socket, setSocket] = useState<Socket | null>(null)
  const [isConnected, setIsConnected] = useState(false)
  const [notifications, setNotifications] = useState<NotificationData[]>([])
  const [uploadProgress, setUploadProgress] = useState<UploadProgress | null>(null)
  const reconnectAttempts = useRef(0)
  const maxReconnectAttempts = 5

  useEffect(() => {
    if (!userId) return

    const socketInstance = io({
      path: '/api/socketio',
      transports: ['websocket', 'polling'],
    })

    socketInstance.on('connect', () => {
      console.log('Connected to WebSocket server')
      setIsConnected(true)
      reconnectAttempts.current = 0
      
      // Authenticate with user ID
      socketInstance.emit('authenticate', userId)
    })

    socketInstance.on('disconnect', () => {
      console.log('Disconnected from WebSocket server')
      setIsConnected(false)
      
      // Attempt to reconnect
      if (reconnectAttempts.current < maxReconnectAttempts) {
        reconnectAttempts.current++
        setTimeout(() => {
          console.log(`Attempting to reconnect... (${reconnectAttempts.current}/${maxReconnectAttempts})`)
          socketInstance.connect()
        }, 1000 * reconnectAttempts.current)
      }
    })

    socketInstance.on('connect_error', (error) => {
      console.error('WebSocket connection error:', error)
      setIsConnected(false)
    })

    // Handle notifications
    socketInstance.on('notification', (notification: NotificationData) => {
      console.log('Received notification:', notification)
      setNotifications(prev => [notification, ...prev])
      
      // Show browser notification if permission granted
      if ('Notification' in window && Notification.permission === 'granted') {
        new Notification(notification.title, {
          body: notification.message,
          icon: '/favicon.ico',
          tag: notification.id,
        })
      }
    })

    // Handle upload progress
    socketInstance.on('upload_progress', (progress: UploadProgress) => {
      console.log('Upload progress:', progress)
      setUploadProgress(progress)
    })

    // Handle transaction updates
    socketInstance.on('transaction_update', (transaction: any) => {
      console.log('Transaction update:', transaction)
      // You can add custom handling here
    })

    // Handle budget alerts
    socketInstance.on('budget_alert', (alert: any) => {
      console.log('Budget alert:', alert)
      // You can add custom handling here
    })

    // Handle goal updates
    socketInstance.on('goal_update', (goal: any) => {
      console.log('Goal update:', goal)
      // You can add custom handling here
    })

    setSocket(socketInstance)

    return () => {
      socketInstance.disconnect()
    }
  }, [userId])

  const markNotificationRead = (notificationId: string) => {
    if (socket && userId) {
      socket.emit('mark_notification_read', { notificationId, userId })
      setNotifications(prev => 
        prev.map(n => n.id === notificationId ? { ...n, read: true } : n)
      )
    }
  }

  const startUploadTracking = (uploadId: string) => {
    if (socket && userId) {
      socket.emit('upload_start', { uploadId, userId })
    }
  }

  const clearNotifications = () => {
    setNotifications([])
  }

  const clearUploadProgress = () => {
    setUploadProgress(null)
  }

  // Request notification permission
  const requestNotificationPermission = async () => {
    if ('Notification' in window && Notification.permission === 'default') {
      const permission = await Notification.requestPermission()
      return permission === 'granted'
    }
    return 'Notification' in window && Notification.permission === 'granted'
  }

  return {
    socket,
    isConnected,
    notifications,
    uploadProgress,
    markNotificationRead,
    startUploadTracking,
    clearNotifications,
    clearUploadProgress,
    requestNotificationPermission,
  }
}