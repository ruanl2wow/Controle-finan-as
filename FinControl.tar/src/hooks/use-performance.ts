'use client'

import { useState, useEffect, useRef, useCallback } from 'react'

interface PerformanceMetrics {
  renderTime: number
  memoryUsage?: number
  componentMountTime: number
}

export function usePerformanceMonitor(componentName: string) {
  const [metrics, setMetrics] = useState<PerformanceMetrics>({
    renderTime: 0,
    componentMountTime: 0
  })
  
  const mountTimeRef = useRef<number>(Date.now())
  const renderStartRef = useRef<number>(0)

  useEffect(() => {
    const mountTime = Date.now() - mountTimeRef.current
    setMetrics(prev => ({ ...prev, componentMountTime: mountTime }))
    
    // Monitorar uso de memória se disponível
    if ('memory' in performance) {
      const memoryUsage = (performance as any).memory.usedJSHeapSize
      setMetrics(prev => ({ ...prev, memoryUsage }))
    }
  }, [])

  const startRender = useCallback(() => {
    renderStartRef.current = performance.now()
  }, [])

  const endRender = useCallback(() => {
    const renderTime = performance.now() - renderStartRef.current
    setMetrics(prev => ({ ...prev, renderTime }))
  }, [])

  return {
    metrics,
    startRender,
    endRender
  }
}

// Hook para detectar quando componente está visível
export function useIntersectionObserver(
  elementRef: React.RefObject<Element>,
  options: IntersectionObserverInit = {}
) {
  const [isIntersecting, setIsIntersecting] = useState(false)
  const [hasIntersected, setHasIntersected] = useState(false)

  useEffect(() => {
    const element = elementRef.current
    if (!element) return

    const observer = new IntersectionObserver(
      ([entry]) => {
        setIsIntersecting(entry.isIntersecting)
        if (entry.isIntersecting && !hasIntersected) {
          setHasIntersected(true)
        }
      },
      { threshold: 0.1, ...options }
    )

    observer.observe(element)

    return () => {
      observer.unobserve(element)
    }
  }, [elementRef, hasIntersected])

  return { isIntersecting, hasIntersected }
}

// Hook para debounce de navegação
export function useNavigationDebounce(delay: number = 300) {
  const [isNavigating, setIsNavigating] = useState(false)
  const timeoutRef = useRef<NodeJS.Timeout>()

  const navigate = useCallback((callback: () => void) => {
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current)
    }

    setIsNavigating(true)
    
    timeoutRef.current = setTimeout(() => {
      callback()
      setIsNavigating(false)
    }, delay)
  }, [delay])

  useEffect(() => {
    return () => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current)
      }
    }
  }, [])

  return { navigate, isNavigating }
}