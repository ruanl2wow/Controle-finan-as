# 💰 FinControl - Sistema de Controle Financeiro

<div align="center">

![FinControl Logo](https://img.shields.io/badge/FinControl--blue?style=for-the-badge&logo=finance&logoColor=white)
![Next.js](https://img.shields.io/badge/Next.js-15-black?style=for-the-badge&logo=next.js&logoColor=white)
![TypeScript](https://img.shields.io/badge/TypeScript-5-blue?style=for-the-badge&logo=typescript&logoColor=white)
![Tailwind CSS](https://img.shields.io/badge/Tailwind-4-38B2AC?style=for-the-badge&logo=tailwind-css&logoColor=white)

**Aplicação web completa para controle financeiro pessoal com dashboard interativo, IA para categorização e múltiplos métodos de autenticação.**

[Demo Live](#) • [Report Bug](../../issues) • [Request Feature](../../issues)

</div>

## 📋 Índice

- [Sobre o Projeto](#-sobre-o-projeto)
- [✨ Funcionalidades](#-funcionalidades)
- [🚀 Tecnologias](#-tecnologias)
- [📦 Instalação](#-instalação)
- [⚙️ Configuração](#️-configuração)
- [🔐 Autenticação](#-autenticação)
- [📱 Uso](#-uso)
- [🤝 Contribuição](#-contribuição)
- [📄 Licença](#-licença)

## 🎯 Sobre o Projeto

FinControl é uma aplicação web moderna e completa para controle financeiro pessoal, desenvolvida com as melhores práticas e tecnologias atuais. Oferece uma interface intuitiva para gerenciar receitas, despesas, metas e análises financeiras.

### 🌟 Principais Diferenciais

- **Dashboard Interativo**: Visualização completa das finanças em tempo real
- **IA Inteligente**: Categorização automática de transações
- **Múltiplas Autenticações**: Email, Google, GitHub
- **Design Responsivo**: Experiência perfeita em todos os dispositivos
- **Segurança Máxima**: Criptografia e proteção de dados
- **Exportação de Dados**: Múltiplos formatos disponíveis

## ✨ Funcionalidades

### 🏠 Dashboard Principal
- [x] Visão geral das finanças
- [x] Gráficos interativos (receitas vs despesas)
- [x] Análise por categorias
- [x] Saldo em tempo real
- [x] Transações recentes
- [x] Metas de economia

### 📤 Upload e Importação
- [x] Upload de arquivos CSV/OFX
- [x] Processamento automático
- [x] Validação de dados
- [x] Histórico de uploads

### 🤖 Inteligência Artificial
- [x] Categorização automática de transações
- [x] Regras personalizáveis
- [x] Aprendizado contínuo
- [x] Sugestões inteligentes

### 📊 Análises Avançadas
- [x] Relatórios detalhados
- [x] Previsões financeiras
- [x] Análise de tendências
- [x] Comparação de períodos

### 🔔 Notificações
- [x] Alertas de orçamento
- [x] Lembretes de metas
- [x] Relatórios periódicos
- [x] Notificações personalizadas

### 🎯 Metas e Orçamentos
- [x] Definição de metas financeiras
- [x] Controle de orçamentos por categoria
- [x] Acompanhamento de progresso
- [x] Alertas de limite

### 📤 Exportação de Dados
- [x] Exportação em CSV
- [x] Relatórios em PDF
- [x] Dados em Excel
- [x] Backup completo

### ⚙️ Configurações
- [x] Perfil do usuário
- [x] Preferências do sistema
- [x] Segurança e privacidade
- [x] Gerenciamento de dados

### 🔐 Autenticação
- [x] Login com email e senha
- [x] Login com Google OAuth
- [x] Login com GitHub OAuth
- [x] Recuperação de senha
- [x] Proteção de rotas

## 🚀 Tecnologias

### Frontend
- **Next.js 15** - Framework React full-stack
- **TypeScript 5** - Tipagem estática
- **Tailwind CSS 4** - Framework CSS utilitário
- **Shadcn/ui** - Componentes UI modernos
- **Framer Motion** - Animações fluidas
- **Recharts** - Gráficos interativos
- **Lucide React** - Ícones modernos

### Backend
- **NextAuth.js v4** - Autenticação completa
- **Prisma ORM** - Banco de dados
- **SQLite** - Banco de dados local
- **Z-AI Web SDK** - Inteligência artificial

### DevOps
- **ESLint** - Qualidade de código
- **TypeScript** - Verificação de tipos
- **Git** - Controle de versão
- **NPM** - Gerenciamento de pacotes

## 📦 Instalação

### Pré-requisitos

- Node.js 18+ 
- NPM ou Yarn
- Git

### Passos

1. **Clone o repositório**
```bash
git clone https://github.com/SEU_USERNAME/fincontrol.git
cd fincontrol
```

2. **Instale as dependências**
```bash
npm install
```

3. **Configure as variáveis de ambiente**
```bash
cp .env.example .env.local
```

4. **Configure o banco de dados**
```bash
npx prisma generate
npx prisma db push
```

5. **Inicie o servidor de desenvolvimento**
```bash
npm run dev
```

6. **Acesse a aplicação**
```
http://localhost:3000
```

## ⚙️ Configuração

### Variáveis de Ambiente

Crie um arquivo `.env.local` na raiz do projeto:

```env
# NextAuth Configuration
NEXTAUTH_URL=http://localhost:3000
NEXTAUTH_SECRET=sua_chave_secreta_aqui

# Google OAuth (Opcional)
GOOGLE_CLIENT_ID=seu_google_client_id
GOOGLE_CLIENT_SECRET=seu_google_client_secret

# GitHub OAuth (Opcional)
GITHUB_ID=seu_github_client_id
GITHUB_SECRET=seu_github_client_secret

# Database
DATABASE_URL="file:./dev.db"
```

### Configurar Google OAuth

1. Acesse [Google Cloud Console](https://console.cloud.google.com/)
2. Crie um novo projeto
3. Ative as APIs necessárias
4. Configure OAuth 2.0
5. Adicione o URI de redirecionamento: `http://localhost:3000/api/auth/callback/google`
6. Copie as credenciais para o `.env.local`

*Para instruções detalhadas, veja [GOOGLE_OAUTH_SETUP.md](./GOOGLE_OAUTH_SETUP.md)*

## 🔐 Autenticação

### Conta Demo

Para testes rápidos, use a conta demo:

- **Email**: `demo@financas.com`
- **Senha**: `demo123`

### Criar Nova Conta

1. Acesse `/auth/signup`
2. Preencha o formulário
3. Ou use login social (Google/GitHub)

### Fluxos de Autenticação

- **Login Email/Senha**: Autenticação tradicional
- **Login Social**: Google e GitHub OAuth
- **Proteção de Rotas**: Middleware automático
- **Sessões Seguras**: JWT com validação

## 📱 Uso

### Navegação Principal

1. **Dashboard (`/`)**: Visão geral das finanças
2. **Upload (`/upload`)**: Importar dados bancários
3. **Análise (`/analytics`)**: Relatórios detalhados
4. **Notificações (`/notifications`)**: Central de alertas
5. **Metas (`/goals-budgets`)**: Definir objetivos
6. **Exportar (`/export`)**: Baixar dados
7. **Configurações (`/settings`)**: Preferências
8. **Ajuda (`/help`)**: Suporte e documentação

### Upload de Dados

1. Vá para aba "Upload"
2. Arraste ou selecione o arquivo CSV/OFX
3. Aguarde o processamento
4. Revise as transações importadas

### Categorização IA

1. Após upload, as transações são categorizadas automaticamente
2. Revise e ajuste as categorias
3. Crie regras personalizadas
4. A IA aprende com suas correções

### Metas Financeiras

1. Acesse "Metas e Orçamentos"
2. Defina metas de economia
3. Configure limites por categoria
4. Acompanhe o progresso

## 🤝 Contribuição

Contribuições são o que fazem a comunidade open source um lugar incrível para aprender, inspirar e criar. Qualquer contribuição que você fizer será **muito apreciada**.

### Como Contribuir

1. **Faça um Fork** do projeto
2. **Crie sua Feature Branch** (`git checkout -b feature/AmazingFeature`)
3. **Faça o Commit** (`git commit -m 'Add some AmazingFeature'`)
4. **Faça o Push** (`git push origin feature/AmazingFeature`)
5. **Abra um Pull Request**

### Diretrizes

- Siga os padrões de código existentes
- Adicione testes para novas funcionalidades
- Atualize a documentação
- Use commits semânticos
- Seja respeitoso e construtivo

### Reportar Issues

- [Bug Reports](../../issues/new?template=bug_report.md)
- [Feature Requests](../../issues/new?template=feature_request.md)
- [Questions](../../issues/new?template=question.md)

## 📄 Licença

Este projeto está licenciado sob a Licença MIT. Veja o arquivo [LICENSE](LICENSE) para mais detalhes.

## 🙏 Agradecimentos

- [Next.js](https://nextjs.org/) - Framework React
- [Tailwind CSS](https://tailwindcss.com/) - Framework CSS
- [Shadcn/ui](https://ui.shadcn.com/) - Componentes UI
- [NextAuth.js](https://next-auth.js.org/) - Autenticação
- [Prisma](https://www.prisma.io/) - ORM
- [Framer Motion](https://www.framer.com/motion/) - Animações

## 📞 Contato

**Seu Nome** - [@seu_twitter](https://twitter.com/seu_twitter) - seu.email@example.com

Link do Projeto: [https://github.com/SEU_USERNAME/fincontrol](https://github.com/SEU_USERNAME/fincontrol)

---

<div align="center">

**⭐ Se este projeto te ajudou, deixe uma estrela!**

Made with ❤️ by [Seu Nome](https://github.com/SEU_USERNAME)

</div>