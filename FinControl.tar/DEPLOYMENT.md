# 🚀 Guia de Deploy

Este guia explica como fazer o deploy da aplicação FinControl em diferentes plataformas.

## 📋 Índice

- [Pré-requisitos](#pré-requisitos)
- [Vercel (Recomendado)](#vercel-recomendado)
- [Netlify](#netlify)
- [Railway](#railway)
- [DigitalOcean](#digitalocean)
- [Docker](#docker)
- [Variáveis de Ambiente](#variáveis-de-ambiente)

## ✅ Pré-requisitos

- Conta no provedor de hosting
- Repositório Git com o código
- Variáveis de ambiente configuradas

## 🌟 Vercel (Recomendado)

Vercel é a plataforma ideal para aplicações Next.js.

### Passos

1. **Crie conta no [Vercel](https://vercel.com)**
2. **Importe seu repositório GitHub**
3. **Configure as variáveis de ambiente**
4. **Clique em Deploy**

### Configuração

```bash
# Instale Vercel CLI
npm i -g vercel

# Faça login
vercel login

# Deploy
vercel --prod
```

### Variáveis de Ambiente no Vercel

1. Vá para Project Settings → Environment Variables
2. Adicione as variáveis do `.env.example`

## 🎯 Netlify

### Passos

1. **Crie conta no [Netlify](https://netlify.com)**
2. **Conecte seu repositório GitHub**
3. **Configure o build:**
   - **Build command:** `npm run build`
   - **Publish directory:** `.next`
4. **Adicione variáveis de ambiente**

### Configuração

```bash
# Instale Netlify CLI
npm install -g netlify-cli

# Login
netlify login

# Deploy
netlify deploy --prod --dir=.next
```

## 🚂 Railway

### Passos

1. **Crie conta no [Railway](https://railway.app)**
2. **New Project → Deploy from GitHub repo**
3. **Configure as variáveis de ambiente**
4. **Railway fará o deploy automaticamente**

### Configuração Adicional

Adicione `railway.toml` na raiz:

```toml
[build]
builder = "NIXPACKS"

[deploy]
healthcheckPath = "/api/health"
healthcheckTimeout = 100
restartPolicyType = "ON_FAILURE"
restartPolicyMaxRetries = 10
```

## 🌊 DigitalOcean App Platform

### Passos

1. **Crie conta no [DigitalOcean](https://digitalocean.com)**
2. **Apps → Create App**
3. **Conecte seu repositório GitHub**
4. **Configure:**
   - **Build Command:** `npm run build`
   - **Run Command:** `npm start`
   - **Source Directory:** `/`
   - **Output Directory:** `.next`

## 🐳 Docker

### Dockerfile

```dockerfile
FROM node:18-alpine AS base

# Install dependencies only when needed
FROM base AS deps
RUN apk add --no-cache libc6-compat
WORKDIR /app

COPY package.json package-lock.json* ./
RUN npm ci

# Rebuild the source code only when needed
FROM base AS builder
WORKDIR /app
COPY --from=deps /app/node_modules ./node_modules
COPY . .

ENV NEXT_TELEMETRY_DISABLED 1

RUN npm run build

# Production image, copy all the files and run next
FROM base AS runner
WORKDIR /app

ENV NODE_ENV production
ENV NEXT_TELEMETRY_DISABLED 1

RUN addgroup --system --gid 1001 nodejs
RUN adduser --system --uid 1001 nextjs

COPY --from=builder /app/public ./public

# Set the correct permission for prerender cache
RUN mkdir .next
RUN chown nextjs:nodejs .next

# Automatically leverage output traces to reduce image size
COPY --from=builder --chown=nextjs:nodejs /app/.next/standalone ./
COPY --from=builder --chown=nextjs:nodejs /app/.next/static ./.next/static

USER nextjs

EXPOSE 3000

ENV PORT 3000
ENV HOSTNAME "0.0.0.0"

CMD ["node", "server.js"]
```

### docker-compose.yml

```yaml
version: '3.8'

services:
  app:
    build: .
    ports:
      - "3000:3000"
    environment:
      - NODE_ENV=production
      - NEXTAUTH_URL=https://yourdomain.com
      - NEXTAUTH_SECRET=your_secret_here
      - DATABASE_URL=file:./production.db
    volumes:
      - ./data:/app/data
```

### Deploy com Docker

```bash
# Build
docker build -t fincontrol .

# Run
docker run -p 3000:3000 fincontrol
```

## 🔧 Variáveis de Ambiente

### Obrigatórias

```env
NEXTAUTH_URL=https://yourdomain.com
NEXTAUTH_SECRET=your_32_character_secret
DATABASE_URL=your_database_url
```

### Opcionais

```env
GOOGLE_CLIENT_ID=your_google_client_id
GOOGLE_CLIENT_SECRET=your_google_client_secret
GITHUB_ID=your_github_client_id
GITHUB_SECRET=your_github_client_secret
```

### Gerar NEXTAUTH_SECRET

```bash
# OpenSSL
openssl rand -base64 32

# Node.js
node -e "console.log(require('crypto').randomBytes(32).toString('base64'))"

# Online
https://generate-secret.vercel.app/32
```

## 🏥 Health Check

A aplicação inclui um endpoint de health check:

```
GET /api/health
```

Resposta:
```json
{
  "status": "ok",
  "timestamp": "2024-01-01T00:00:00.000Z",
  "uptime": 1234
}
```

## 📊 Performance

### Otimizações

- ✅ Build otimizado para produção
- ✅ Imagens otimizadas
- ✅ Code splitting
- ✅ Lazy loading
- ✅ Cache estratégico

### Métricas

- **First Contentful Paint:** < 1.5s
- **Largest Contentful Paint:** < 2.5s
- **Cumulative Layout Shift:** < 0.1
- **First Input Delay:** < 100ms

## 🔍 Debug

### Logs

```bash
# Vercel
vercel logs

# Netlify
netlify functions:logs

# Railway
railway logs

# Docker
docker logs <container_id>
```

### Problemas Comuns

1. **NEXTAUTH_SECRET inválido**
   - Use exatamente 32 caracteres
   - Codifique em Base64

2. **NEXTAUTH_URL incorreto**
   - Use HTTPS em produção
   - Sem barra no final

3. **Database connection failed**
   - Verifique a DATABASE_URL
   - Confirme as permissões

## 🌐 Domínio Personalizado

### Vercel

1. Project Settings → Domains
2. Adicione seu domínio
3. Configure DNS

### Netlify

1. Site settings → Domain management
2. Adicione domínio personalizado
3. Configure DNS

## 📈 Monitoramento

### Ferramentas Recomendadas

- **Vercel Analytics**: Performance e uso
- **Sentry**: Error tracking
- **LogRocket**: Session replay
- **Hotjar**: User behavior

---

## 🆘 Suporte

Se tiver problemas durante o deploy:

1. Verifique os logs de erro
2. Confirme as variáveis de ambiente
3. Teste localmente com `npm run build && npm start`
4. Abra uma issue no GitHub

**Boa sorte com seu deploy! 🚀**