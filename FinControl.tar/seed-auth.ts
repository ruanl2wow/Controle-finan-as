import { PrismaClient } from '@prisma/client'
import bcrypt from 'bcryptjs'

const prisma = new PrismaClient()

async function main() {
  console.log('🌱 Seeding database with auth users...')

  // Create admin user
  const adminPassword = await bcrypt.hash('admin123', 10)
  const admin = await prisma.user.upsert({
    where: { email: 'admin@fincontrol.com' },
    update: {},
    create: {
      email: 'admin@fincontrol.com',
      name: 'Administrador',
      password: adminPassword,
      role: 'admin',
    },
  })
  console.log('✅ Created admin user:', admin.email)

  // Create regular user
  const userPassword = await bcrypt.hash('user123', 10)
  const user = await prisma.user.upsert({
    where: { email: 'user@fincontrol.com' },
    update: {},
    create: {
      email: 'user@fincontrol.com',
      name: 'Usuário Teste',
      password: userPassword,
      role: 'user',
    },
  })
  console.log('✅ Created regular user:', user.email)

  // Create readonly user
  const readonlyPassword = await bcrypt.hash('readonly123', 10)
  const readonlyUser = await prisma.user.upsert({
    where: { email: 'readonly@fincontrol.com' },
    update: {},
    create: {
      email: 'readonly@fincontrol.com',
      name: 'Usuário Somente Leitura',
      password: readonlyPassword,
      role: 'readonly',
    },
  })
  console.log('✅ Created readonly user:', readonlyUser.email)

  // Create sample financial accounts for each user
  const accounts = [
    { name: 'Conta Corrente', type: 'checking', balance: 5000 },
    { name: 'Poupança', type: 'savings', balance: 15000 },
    { name: 'Cartão de Crédito', type: 'credit', balance: -2000 },
    { name: 'Investimento', type: 'investment', balance: 25000 },
  ]

  for (const currentUser of [admin, user, readonlyUser]) {
    for (const account of accounts) {
      await prisma.financialAccount.upsert({
        where: {
          name_userId: {
            name: account.name,
            userId: currentUser.id,
          },
        },
        update: {},
        create: {
          ...account,
          userId: currentUser.id,
        },
      })
    }
    console.log(`✅ Created accounts for user: ${currentUser.email}`)
  }

  // Create sample categories
  const categories = [
    { name: 'Mercado', type: 'expense', color: '#ef4444', icon: '🛒' },
    { name: 'Restaurante', type: 'expense', color: '#f97316', icon: '🍽️' },
    { name: 'Transporte', type: 'expense', color: '#eab308', icon: '🚗' },
    { name: 'Farmácia', type: 'expense', color: '#22c55e', icon: '💊' },
    { name: 'Entretenimento', type: 'expense', color: '#3b82f6', icon: '🎬' },
    { name: 'Moradia', type: 'expense', color: '#8b5cf6', icon: '🏠' },
    { name: 'Salário', type: 'income', color: '#10b981', icon: '💰' },
    { name: 'Freelance', type: 'income', color: '#06b6d4', icon: '💻' },
    { name: 'Investimentos', type: 'income', color: '#6366f1', icon: '📈' },
    { name: 'Outros', type: 'expense', color: '#6b7280', icon: '📌' },
  ]

  for (const currentUser of [admin, user, readonlyUser]) {
    for (const category of categories) {
      await prisma.category.upsert({
        where: {
          name_userId: {
            name: category.name,
            userId: currentUser.id,
          },
        },
        update: {},
        create: {
          ...category,
          userId: currentUser.id,
        },
      })
    }
    console.log(`✅ Created categories for user: ${currentUser.email}`)
  }

  // Create sample transactions for regular user
  const transactions = [
    {
      description: 'Supermercado Extra',
      amount: -250.50,
      type: 'expense' as const,
      date: new Date('2024-06-12'),
      categoryName: 'Mercado',
      accountName: 'Conta Corrente',
    },
    {
      description: 'Salário Mensal',
      amount: 5800.00,
      type: 'income' as const,
      date: new Date('2024-06-10'),
      categoryName: 'Salário',
      accountName: 'Conta Corrente',
    },
    {
      description: 'Uber Viagem',
      amount: -45.30,
      type: 'expense' as const,
      date: new Date('2024-06-09'),
      categoryName: 'Transporte',
      accountName: 'Cartão de Crédito',
    },
    {
      description: 'Restaurante Italiano',
      amount: -180.00,
      type: 'expense' as const,
      date: new Date('2024-06-08'),
      categoryName: 'Restaurante',
      accountName: 'Cartão de Crédito',
    },
    {
      description: 'Farmácia',
      amount: -89.90,
      type: 'expense' as const,
      date: new Date('2024-06-07'),
      categoryName: 'Farmácia',
      accountName: 'Conta Corrente',
    },
    {
      description: 'Netflix',
      amount: -49.90,
      type: 'expense' as const,
      date: new Date('2024-06-05'),
      categoryName: 'Entretenimento',
      accountName: 'Cartão de Crédito',
    },
    {
      description: 'Gasolina',
      amount: -200.00,
      type: 'expense' as const,
      date: new Date('2024-06-03'),
      categoryName: 'Transporte',
      accountName: 'Cartão de Crédito',
    },
    {
      description: 'Aluguel',
      amount: -1500.00,
      type: 'expense' as const,
      date: new Date('2024-06-01'),
      categoryName: 'Moradia',
      accountName: 'Conta Corrente',
    },
    {
      description: 'Projeto Freelance',
      amount: 2500.00,
      type: 'income' as const,
      date: new Date('2024-06-15'),
      categoryName: 'Freelance',
      accountName: 'Conta Corrente',
    },
    {
      description: 'Rendimento Investimento',
      amount: 150.00,
      type: 'income' as const,
      date: new Date('2024-06-20'),
      categoryName: 'Investimentos',
      accountName: 'Investimento',
    },
  ]

  // Get user's accounts and categories
  const userAccounts = await prisma.financialAccount.findMany({
    where: { userId: user.id },
  })
  const userCategories = await prisma.category.findMany({
    where: { userId: user.id },
  })

  for (const transaction of transactions) {
    const account = userAccounts.find(a => a.name === transaction.accountName)
    const category = userCategories.find(c => c.name === transaction.categoryName)

    if (account && category) {
      await prisma.transaction.create({
        data: {
          description: transaction.description,
          amount: transaction.amount,
          type: transaction.type,
          date: transaction.date,
          categoryId: category.id,
          accountId: account.id,
          userId: user.id,
        },
      })
    }
  }
  console.log(`✅ Created sample transactions for user: ${user.email}`)

  console.log('🎉 Database seeding completed!')
  console.log('\n📋 Test Users:')
  console.log('👑 Admin: admin@fincontrol.com / admin123')
  console.log('👤 User: user@fincontrol.com / user123')
  console.log('👁️  Readonly: readonly@fincontrol.com / readonly123')
}

main()
  .catch((e) => {
    console.error('❌ Error seeding database:', e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })