import { db } from '@/lib/db'

async function seed() {
  const userId = 'user-1'

  // Create default user
  await db.user.upsert({
    where: { id: userId },
    update: {},
    create: {
      id: userId,
      email: 'user@example.com',
      name: 'Usuário Teste',
    },
  })

  // Create default accounts
  const accounts = await Promise.all([
    db.account.create({
      data: {
        name: 'Conta Corrente',
        type: 'checking',
        balance: 5000,
        currency: 'BRL',
        userId,
      },
    }),
    db.account.create({
      data: {
        name: 'Cartão Crédito',
        type: 'credit',
        balance: -1500,
        currency: 'BRL',
        userId,
      },
    }),
    db.account.create({
      data: {
        name: 'Poupança',
        type: 'savings',
        balance: 10000,
        currency: 'BRL',
        userId,
      },
    }),
  ])

  // Create default categories
  const categories = await Promise.all([
    db.category.create({
      data: {
        name: 'Mercado',
        description: 'Compras de supermercado e alimentos',
        color: '#F59E0B',
        icon: 'ShoppingCart',
        type: 'expense',
        userId,
      },
    }),
    db.category.create({
      data: {
        name: 'Restaurante',
        description: 'Refeições fora de casa',
        color: '#EF4444',
        icon: 'Utensils',
        type: 'expense',
        userId,
      },
    }),
    db.category.create({
      data: {
        name: 'Transporte',
        description: 'Transporte público, combustível, aplicativos',
        color: '#3B82F6',
        icon: 'Car',
        type: 'expense',
        userId,
      },
    }),
    db.category.create({
      data: {
        name: 'Farmácia',
        description: 'Medicamentos e produtos de saúde',
        color: '#10B981',
        icon: 'Pill',
        type: 'expense',
        userId,
      },
    }),
    db.category.create({
      data: {
        name: 'Moradia',
        description: 'Aluguel, condomínio, contas de casa',
        color: '#8B5CF6',
        icon: 'Home',
        type: 'expense',
        userId,
      },
    }),
    db.category.create({
      data: {
        name: 'Receita',
        description: 'Salário e outras receitas',
        color: '#22C55E',
        icon: 'TrendingUp',
        type: 'income',
        userId,
      },
    }),
  ])

  // Create sample transactions
  const transactions = await Promise.all([
    db.transaction.create({
      data: {
        date: new Date('2024-06-12'),
        description: 'Supermercado Extra',
        amount: -250.50,
        type: 'expense',
        categoryId: categories[0].id, // Mercado
        accountId: accounts[0].id, // Conta Corrente
        userId,
        tags: JSON.stringify(['essencial']),
      },
    }),
    db.transaction.create({
      data: {
        date: new Date('2024-06-10'),
        description: 'Salário Mensal',
        amount: 5800.00,
        type: 'income',
        categoryId: categories[5].id, // Receita
        accountId: accounts[0].id, // Conta Corrente
        userId,
        tags: JSON.stringify(['salario']),
      },
    }),
    db.transaction.create({
      data: {
        date: new Date('2024-06-09'),
        description: 'Uber Viagem',
        amount: -45.30,
        type: 'expense',
        categoryId: categories[2].id, // Transporte
        accountId: accounts[1].id, // Cartão Crédito
        userId,
        tags: JSON.stringify(['trabalho']),
      },
    }),
    db.transaction.create({
      data: {
        date: new Date('2024-06-08'),
        description: 'Restaurante Italiano',
        amount: -180.00,
        type: 'expense',
        categoryId: categories[1].id, // Restaurante
        accountId: accounts[1].id, // Cartão Crédito
        userId,
        tags: JSON.stringify(['lazer']),
      },
    }),
    db.transaction.create({
      data: {
        date: new Date('2024-06-07'),
        description: 'Farmácia',
        amount: -89.90,
        type: 'expense',
        categoryId: categories[3].id, // Farmácia
        accountId: accounts[0].id, // Conta Corrente
        userId,
        tags: JSON.stringify(['saúde']),
      },
    }),
  ])

  // Create sample rules
  await Promise.all([
    db.rule.create({
      data: {
        name: 'Classificar Uber',
        condition: JSON.stringify({
          type: 'keyword',
          keyword: 'uber',
        }),
        action: JSON.stringify({
          categoryId: categories[2].id, // Transporte
        }),
        priority: 1,
        isActive: true,
        userId,
        categoryId: categories[2].id,
      },
    }),
    db.rule.create({
      data: {
        name: 'Classificar Supermercado',
        condition: JSON.stringify({
          type: 'keyword',
          keyword: 'supermercado',
        }),
        action: JSON.stringify({
          categoryId: categories[0].id, // Mercado
        }),
        priority: 1,
        isActive: true,
        userId,
        categoryId: categories[0].id,
      },
    }),
  ])

  console.log('Database seeded successfully!')
  console.log(`Created ${accounts.length} accounts`)
  console.log(`Created ${categories.length} categories`)
  console.log(`Created ${transactions.length} transactions`)
  console.log(`Created 2 rules`)
}

seed()
  .catch(console.error)
  .finally(() => process.exit(0))