# 🚀 Configuração do Google OAuth

Este guia explica como configurar o login com Google para sua aplicação.

## 📋 Pré-requisitos

- Conta Google
- Acesso ao [Google Cloud Console](https://console.cloud.google.com/)

## 🔧 Passos para Configuração

### 1. Criar Projeto no Google Cloud

1. Acesse [Google Cloud Console](https://console.cloud.google.com/)
2. Clique em "Selecionar um projeto" → "NOVO PROJETO"
3. Nome do projeto: `FinControl App` (ou seu preferido)
4. Clique em "Criar"

### 2. Ativar APIs Necessárias

1. No menu lateral, vá para "APIs e Serviços" → "Biblioteca"
2. Procure e ative:
   - **Google+ API** (se disponível)
   - **People API**
   - **Google Identity**

### 3. Configurar OAuth 2.0

1. Vá para "APIs e Serviços" → "Tela de consentimento OAuth"
2. Escolha "Externo" e clique em "Criar"
3. Preencha as informações:
   - **Nome do aplicativo**: FinControl
   - **Email de suporte do usuário**: seu-email@gmail.com
   - **Logo da aplicação**: (opcional)
4. Clique em "Salvar e Continuar"
5. Escopos: Clique em "Adicionar ou Remover Escopos"
   - Procure e adicione: `openid`, `email`, `profile`
6. Usuários de teste: Adicione seu email para testes
7. Clique em "Salvar e Continuar" até finalizar

### 4. Criar Credenciais

1. Vá para "APIs e Serviços" → "Credenciais"
2. Clique em "+ CRIAR CREDENCIAIS" → "ID do cliente OAuth"
3. Selecione:
   - **Tipo de aplicativo**: Aplicativo da Web
   - **Nome**: FinControl Web Client
4. **URIs de redirecionamento autorizados**:
   ```
   http://localhost:3000/api/auth/callback/google
   ```
5. Clique em "Criar"
6. **Copie o ID do cliente e o segredo do cliente**

### 5. Configurar Variáveis de Ambiente

Abra o arquivo `.env.local` na raiz do projeto e atualize:

```env
# NextAuth Configuration
NEXTAUTH_URL=http://localhost:3000
NEXTAUTH_SECRET=bXlfc3VwZXJfc2VjcmV0X2tleV9mb3JfcHJvZHVjdGlvbl91c2VfMzJfY2hhcnNfbG9uZw==

# Google OAuth (Substitua com suas credenciais reais)
GOOGLE_CLIENT_ID=SEU_GOOGLE_CLIENT_ID_AQUI
GOOGLE_CLIENT_SECRET=SEU_GOOGLE_CLIENT_SECRET_AQUI

# GitHub OAuth (Opcional)
GITHUB_ID=seu_github_client_id_aqui
GITHUB_SECRET=seu_github_client_secret_aqui

# Database
DATABASE_URL="file:./dev.db"
```

### 6. Reiniciar o Servidor

```bash
# Pare o servidor (Ctrl+C)
# Reinicie
npm run dev
```

## 🧪 Testar o Login

1. Acesse `http://localhost:3000/auth/signin`
2. Clique em "Continuar com Google"
3. Faça login com sua conta Google
4. Se tudo estiver correto, você será redirecionado para o dashboard

## 🐥 Solução de Problemas

### Erro: "redirect_uri_mismatch"
- Verifique se o URI de redirecionamento no Google Console é exatamente:
  `http://localhost:3000/api/auth/callback/google`

### Erro: "invalid_client"
- Verifique se o CLIENT_ID e CLIENT_SECRET estão corretos no .env.local
- Certifique-se de que não há espaços extras

### Erro: "access_denied"
- Verifique se sua conta está na lista de "Usuários de teste"
- Verifique se os escopos estão configurados corretamente

## 🌱 Para Produção

Quando for para produção:

1. Atualize `NEXTAUTH_URL` para seu domínio real
2. Adicione o domínio de produção aos URIs de redirecionamento:
   ```
   https://seusite.com/api/auth/callback/google
   ```
3. Publique o aplicativo OAuth (remova da fase de teste)
4. Configure HTTPS (obrigatório para produção)

## 📞 Suporte

Se tiver problemas:
1. Verifique o console do navegador para erros
2. Verifique os logs do servidor
3. Confirme as variáveis de ambiente
4. Entre em contato com o suporte técnico

---

**Importante**: Mantenha suas credenciais OAuth seguras e nunca as compartilhe publicamente!